package com.mycompany.cmd;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;
import com.mycompany.a2.GameWorld;

public class FireEMissileCommand extends Command 
{
	private GameWorld gw;
	
	/**
	 * Creates a button command to fire enemy missile
	 * @param gw - Reference to game world to invoke appropriate method
	 */
	public FireEMissileCommand(GameWorld gw)
	{
		super("Fire enemy missile");
		this.gw = gw;
	}
	
	@Override
	public void actionPerformed(ActionEvent e)
	{
		gw.fireEMissile();
		System.out.println("Fire enemy missile");
	}
}
