package com.mycompany.a2;

public interface ICollection {

	public IIterator getIterator();
	
	public int getSize();
	
	public void add(GameObject gameObj);
	
	
}
