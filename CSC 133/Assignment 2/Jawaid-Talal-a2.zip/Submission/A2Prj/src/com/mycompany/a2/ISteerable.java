package com.mycompany.a2;

public interface ISteerable 
{

	public void turn(int amount);
	
}
