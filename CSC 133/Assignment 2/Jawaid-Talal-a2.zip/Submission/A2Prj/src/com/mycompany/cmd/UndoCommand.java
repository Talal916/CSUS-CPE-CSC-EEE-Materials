package com.mycompany.cmd;

import com.codename1.ui.Command;

public class UndoCommand extends Command 
{
	/**
	 * Yeah I got no idea on this one.
	 */
	public UndoCommand() 
	{
		super("Undo");
	}
}
