package com.mycompany.cmd;

import com.codename1.ui.Command;

public class NewGameCmd extends Command 
{
	/**
	 * Creates a side menu command for starting new game. Currently not working.
	 */
	public NewGameCmd() 
	{
		super("New");
	}
}
