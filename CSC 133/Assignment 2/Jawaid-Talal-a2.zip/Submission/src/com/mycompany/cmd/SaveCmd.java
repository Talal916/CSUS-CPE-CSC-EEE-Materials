package com.mycompany.cmd;

import com.codename1.ui.Command;

public class SaveCmd extends Command 
{
	/**
	 * Creates a side menu command to save game. Currently not working.
	 */
	public SaveCmd()
	{
		super("Save");
	}
}
