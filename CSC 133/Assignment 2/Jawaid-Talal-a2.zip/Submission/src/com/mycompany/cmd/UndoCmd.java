package com.mycompany.cmd;

import com.codename1.ui.Command;

public class UndoCmd extends Command 
{
	/**
	 * Yeah I got no idea on this one.
	 */
	public UndoCmd() 
	{
		super("Undo");
	}
}
