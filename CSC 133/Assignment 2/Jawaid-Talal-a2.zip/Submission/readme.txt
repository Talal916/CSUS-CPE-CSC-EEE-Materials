No changes made to assignment specifications.

How to Run:
Use Eclipse to import archive file, run Simulator_A2Prj.launch

Command Line run command is not working for some reason. I have attached failure in CommandLineFail.PNG

Commands are to be in a separate package

Changes from A1:

clock method now uses polymorphically-safe method invocations

Game now distinguishes between PS and NPS missiles

q command now prompts user before quitting.

Missiles are fired in direction of missilelauncher when instantiated

only one PS is allowed at a time

UML redone from scratch

Test cases are now corrected