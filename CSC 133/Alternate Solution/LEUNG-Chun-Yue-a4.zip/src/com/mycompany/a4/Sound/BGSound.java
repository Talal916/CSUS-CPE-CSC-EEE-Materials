package com.mycompany.a4.Sound;

import java.io.InputStream;

import com.codename1.media.Media;
import com.codename1.media.MediaManager;
import com.codename1.ui.Display;

public class BGSound implements Runnable{
	private  Media m;
	private static BGSound mySound;
	
	/**
	 * Initialize the Sound. 
	 * @param fileName sound file name
	 */
	public void init(String fileName) {
		
		try{
			InputStream is = Display.getInstance().getResourceAsStream(getClass(),"/"+fileName);
			m = MediaManager.createMedia(is, "audio/wav", this);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	/**
	 * Return the current Sound.
	 * @return
	 */
	public static BGSound getSound() {
		if (mySound == null)
			mySound = new BGSound();
		return mySound;
	}
	/**
	 * Pause the Sound
	 */
	public void pause(){ m.pause();}
	/**
	 * Continue playing the Sound
	 */
	public void play(){ m.play();} 
	
	/**
	 *  Entered when the sound ends
	 */
	public void run() {
		//start playing from time zero (beginning of the sound file)
		m.setTime(0);
		m.play();
	}
}

