package com.mycompany.a4.Commands.Setting;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;
import com.mycompany.a4.ClosingApp;
/**
 * <h1>ExitCommand</h1>
 * A Command to Contract SpaceShip's door when activated.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class ExitCommand extends Command {
	/**
	 * Constructor
	 */
	public ExitCommand() {
		super("Exit");
	}
	/**
	 * Ask user if he/she want to quit when activated.
	 * @see com.mycompany.a4.a2.misc.ClosingApp.ClosingApp
	 */
	@Override
	public void actionPerformed(ActionEvent ev) {
		new ClosingApp();
	}

}
