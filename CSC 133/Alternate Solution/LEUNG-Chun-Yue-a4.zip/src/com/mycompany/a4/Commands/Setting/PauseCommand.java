package com.mycompany.a4.Commands.Setting;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;
import com.mycompany.a4.BlueButton;
import com.mycompany.a4.Game;
/**
 * <h1>ExpandDoorCommand</h1>
 * A Command to expand SpaceShip's door when activated.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class PauseCommand extends Command{
	private static Game myGame;
	private static BlueButton myButton;
	private static boolean isPause;
	private static PauseCommand myCommand;
	private PauseCommand() {
		super("PAUSE");
	}
	/**
	 * Set target
	 * @param g target Game
	 * @param b target BlueButton
	 */
	public static void setTarget(Game g, BlueButton b) {
		myGame = g;
		myButton = b;
	}
	/**
	 * Return the current command, create one if not created yet.
	 * @return command
	 */
	public static PauseCommand getCommand() {
		if (myCommand == null)
			myCommand = new PauseCommand();
		return myCommand;
	}

	/**
	 * Calls GameWorld's play() and Pause().
	 * Change the Button's text accordingly.
	 * @see com.mycompany.a4.Game
	 */
	@Override
	public void actionPerformed(ActionEvent ev) {
		if (isPause) {
			myGame.play();
			isPause = false;
			myButton.setText("PAUSE");
			
		}else {
			myGame.pause();
			isPause = true;
			myButton.setText("PLAY");
		}
	}
}
