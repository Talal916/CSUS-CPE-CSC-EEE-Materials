package com.mycompany.a4.Commands.Setting;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Label;
/**
 * <h1>HelpCommand</h1>
 * Label with blue text align in the middle.
 * <<<<<In case someone does read this. >>>>>
 * This is not related to Johnny Walker.
 * Stay away from alcohol!!!
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class BlueLabel extends Label{
	/**
	 * Constructor
	 * @param text
	 */
	public BlueLabel(String text) {
		super(text);
		this.getAllStyles().setAlignment(CENTER);
		this.getAllStyles().setFgColor(ColorUtil.BLUE);
		this.getAllStyles().setPadding(0, 0, 5, 5);
	}
}
