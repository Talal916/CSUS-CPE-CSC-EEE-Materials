package com.mycompany.a4.Commands.GameControl;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;
import com.mycompany.a4.GameWorld;
/**
 * <h1>MoveToAlienCommand</h1>
 * A Command to move the Spaceship to random Alien when activated.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class MoveToAlienCommand extends Command{
	private static GameWorld gw;
	private static MoveToAlienCommand myCommand;

	private MoveToAlienCommand() {
		super("MoveToAlien");
	}
	/**
	 * Set target.
	 * @param g Target 	 
	 */
	public static void setTarget(GameWorld g) {
		gw = g;
	}
	/**
	 * Return the current command, create one if not created yet.
	 * @return command
	 */
	public static MoveToAlienCommand getCommand() {
		if (myCommand == null)
			myCommand = new MoveToAlienCommand();
		return myCommand;
	}
	/**
	 * Calls GameWorld's method when activated.
	 * @see com.mycompany.a4.GameWorld
	 */
	@Override
	public void actionPerformed(ActionEvent ev) {
		gw.moveSpaceShipToAlien();	
	}

}
