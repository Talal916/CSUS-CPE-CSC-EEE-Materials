package com.mycompany.a4.Commands.GameControl;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;
import com.mycompany.a4.GameWorld;
/**
 * <h1>MoveDownCommand</h1>
 * A Command move the SpaceShip down when activated.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class MoveDownCommand extends Command{
	private static GameWorld gw;
	private static MoveDownCommand myCommand;

	private MoveDownCommand() {
		super("Down");
	}
	/**
	 * Set target.
	 * @param g Target 	 
	 */
	public static void setTarget(GameWorld g) {
		gw = g;
	}
	/**
	 * Return the current command, create one if not created yet.
	 * @return command
	 */
	public static MoveDownCommand getCommand() {
		if (myCommand == null)
			myCommand = new MoveDownCommand();
		return myCommand;
	}
	/**
	 * Calls GameWorld's method when activated.
	 * @see com.mycompany.a4.GameWorld
	 */
	@Override
	public void actionPerformed(ActionEvent ev) {
		gw.moveSpaceShipDown();
	}

}
