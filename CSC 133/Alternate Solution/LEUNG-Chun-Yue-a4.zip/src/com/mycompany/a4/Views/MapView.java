package com.mycompany.a4.Views;

import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Container;
import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;
import com.codename1.ui.Transform.NotInvertibleException;
import com.codename1.ui.plaf.Border;
import com.mycompany.a4.GameWorld;
import com.mycompany.a4.GameObjects.GameObject;
import com.mycompany.a4.GameObjects.ISelectable;
import com.mycompany.a4.GameObjects.Point;
import com.mycompany.a4.GameObjects.ShockWave;

/**
 * <h1>MapView</h1>
 * Implements Observer Pattern which get updates when there is any change in the game objects.
 * Shows the game Objects' status (currently show on Console)
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class MapView extends Container implements Observer{
	
	private GameWorld gw;
	private boolean isSelectedSth;
	private Transform worldToND, ndToDisplay, theVTM ;
	private float winLeft, winBottom, winRight, winTop, winWidth, winHeight;
	
	/**
	 * Constructor
	 */
	public MapView(GameWorld gw) {
		this.getAllStyles().setBgTransparency(255);
		getAllStyles().setBorder(Border.createLineBorder(2, ColorUtil.BLACK));
		this.gw = gw;
	}
	
	/**
	 * Initialize the World Window.
	 */
	public void initWorldWindow() {
		this.winLeft = 0;
		this.winRight = gw.getWorldWidth();
		this.winTop = gw.getWorldHeight();
		this.winBottom = 0;
		this.winWidth = this.winRight - this.winLeft;
		this.winHeight = this.winTop - this.winBottom;
	}
	
	
	/**
	 * Paint the map when the GameWorld's time tick.
	 */
	public void update(Observable observable, Object data) {
		((GameWorld)observable).showMap();
		this.repaint();
	}
	/**
	 * Call the draw method of every GameObject in the map.
	 */
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		worldToND = buildWorldToNDXform(winWidth, winHeight, winLeft, winBottom);
		ndToDisplay = buildNDToDisplayXform(this.getWidth(), this.getHeight());
		theVTM = ndToDisplay.copy();
		theVTM.concatenate(worldToND);
		//concatenate the VTM onto the g�s current transformation (do not forget to apply �local
		//origin� transformation)
		Transform gXform = Transform.makeIdentity();
		g.getTransform(gXform);
		gXform.translate(getAbsoluteX(),getAbsoluteY()); //local origin xform (part 2)
		gXform.concatenate(theVTM); //VTM xform
		gXform.translate(-getAbsoluteX(),-getAbsoluteY()); //local origin xform (part 1)
		g.setTransform(gXform);
		Point pCmpRelPrnt = new Point(this.getX(), this.getY());
		Point pCmpRelScrn = new Point(getAbsoluteX(),getAbsoluteY());
		Iterator<GameObject> it = gw.getGameObjectIterator();
		while (it.hasNext()) {
			GameObject o = it.next();
			o.draw(g, pCmpRelPrnt, pCmpRelScrn);
			if (!gw.isPause() && isSelectedSth) {
					if (o instanceof ISelectable && ((ISelectable)o).isSelected()) {
						((ISelectable)o).setSelected(false);
						isSelectedSth = false;
					}
			}
			else if (o instanceof ShockWave) {
				if (!gw.isPause())
					((ShockWave)o).setLifeTime( ((ShockWave)o).getLifeTime() - 1);
				if (((ShockWave)o).isEndOfLife())
						it.remove();
			}
		}
		g.resetAffine();
	}
	/**
	 * Select the Astronaut if the user click the Astronaut.
	 */
	@Override
	public void pointerPressed(int x, int y){
		//(x, y) is the pointer location relative to screen origin
		//make it relative to display origin
		if (gw.isPause()) {
			float [] fPtr = new float [] {x - getAbsoluteX(), y - getAbsoluteY()};
			Transform inverseVTM = Transform.makeIdentity();
			try {
				theVTM.getInverse(inverseVTM);
			} catch (NotInvertibleException e) {
				System.out.println("Non invertible xform!");
				}
				//calculate the location of fPtr the in world space
				inverseVTM.transformPoint(fPtr, fPtr);
				Iterator<GameObject>it = gw.getGameObjectIterator();
				while (it.hasNext()) {
					GameObject o = it.next();
					if (o instanceof ISelectable) {
						if (((ISelectable)o).contains(fPtr)) {
							((ISelectable)o).setSelected(true);
							isSelectedSth = true;
						}
						else
							((ISelectable)o).setSelected(false);
					}	
				}
				repaint();
		}
	}

	//Transform local world into standard unit world.
	private Transform buildWorldToNDXform(float winWidth, float winHeight, float
			winLeft, float winBottom){
			Transform tmpXfrom = Transform.makeIdentity();
			tmpXfrom.scale( (1/winWidth) , (1/winHeight) );
			tmpXfrom.translate(-winLeft,-winBottom);
			return tmpXfrom;
	}
	// Transform standard unit world into display windows.
	private Transform buildNDToDisplayXform (float displayWidth, float displayHeight){
		Transform tmpXfrom = Transform.makeIdentity();
		tmpXfrom.translate(0, displayHeight);
		tmpXfrom.scale(displayWidth, -displayHeight);
		return tmpXfrom;
	}
	/**
	 * Zoom 
	 * @param factor
	 */
	private void zoom(float factor) {
		//positive factor would zoom in (make the worldWin smaller), suggested value is 0.05f
		//negative factor would zoom out (make the worldWin larger), suggested value is -0.05f
		//...[calculate winWidth and winHeight]
		float newWinLeft = winLeft + winWidth*factor;
		float newWinRight = winRight - winWidth*factor;
		float newWinTop = winTop - winHeight*factor;
		float newWinBottom = winBottom + winHeight*factor;
		float newWinHeight = newWinTop - newWinBottom;
		float newWinWidth = newWinRight - newWinLeft;
		//in CN1 do not use world window dimensions greater than 1000!!!
		if (newWinWidth <= 1000 && newWinHeight <= 1000 && newWinWidth > 0 && newWinHeight > 0 ){
			winLeft = newWinLeft;
			winRight = newWinRight;
			winTop = newWinTop;
			winBottom = newWinBottom;
			winWidth = newWinWidth;
			winHeight = newWinHeight;
			System.out.println("winLeft:" + winLeft + " winRight:" +winRight +" winTop:"+winTop + " winBottom" + winBottom + " winWidth:" +winWidth +" winHeight:"+winHeight);
		}
		else if(newWinWidth >= 1000 && newWinHeight >= 1000)
			System.out.println("Exceed size!");
		else
			System.out.println("Beneath size!");	
		this.repaint();
	}
	/**
	 * 	positive delta would pan right (image would shift left), suggested value is 5.
	 *  negative delta would pan left (image would shift right), suggested value is -5.
	 * @param delta
	 */
	private void panHorizontal(double delta) {
		winLeft += delta;
		winRight += delta;
		this.repaint();
	}
	/**
	 * positive delta would pan up (image would shift down), suggested value is 5.
	 * negative delta would pan down (image would shift up), suggested value is -5.
	 * @param delta
	 */
	private void panVertical(double delta) {
		
		winBottom += delta;
		winTop += delta;
		this.repaint();
	}
	
	/**
	 *  Zooming Out: two fingers come closer together (on actual device), right mouse
	 *	click + drag towards the top left corner of screen (on simulator).
	 *	Zooming In: two fingers go away from each other (on actual device), right mouse
	 *	click + drag away from the top left corner of screen (on simulator).
	 */
	@Override
	public boolean pinch(float scale){
		if(scale < 1.0){
		//Zooming Out: two fingers come closer together (on actual device), right mouse
		//click + drag towards the top left corner of screen (on simulator)
		zoom(-0.01f);
		}else if(scale>1.0){
		
		zoom(0.01f);
		}
		return true;
	}
	private Point pPrevDragLoc = new Point(-1, -1);
	
	/**
	 * Drag will call pan the display windows.
	 */
	@Override
	public void pointerDragged(int x, int y)
	{
		if (pPrevDragLoc.getX() != -1)
		{
			if (pPrevDragLoc.getX() < x)
				panHorizontal(5);
			else if (pPrevDragLoc.getX() > x)
				panHorizontal(-5);
			if (pPrevDragLoc.getY() < y)
				panVertical(-5);
			else if (pPrevDragLoc.getY() > y)
				panVertical(5);
		}
		pPrevDragLoc.setX(x);
		pPrevDragLoc.setY(y);
	}
}
