package com.mycompany.a4;

import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import java.util.Random;
import java.util.Vector;

import com.codename1.charts.util.ColorUtil;
import com.mycompany.a4.GameObjects.*;
import com.mycompany.a4.GameObjects.Alien.Alien;
import com.mycompany.a4.Sound.BGSound;
import com.mycompany.a4.Sound.GetHitSound;
import com.mycompany.a4.Sound.NewAlienSound;
import com.mycompany.a4.Sound.ShipDoorSound;

/**
 * <h1>GameWorld</h1>
 * Implements Observer Pattern which will updates the Views when there is any change in the game objects.
 * Holds a collection of game objects and other state variables such as score and how many different Opponents removed and left.
 * @author Chun Yue LEUNG
 * @version 4.0
 */

public class GameWorld extends Observable{
	private GameObjectCollection go;
	private SpaceShip mainRole;
	private Integer numOfAlienIn;
	private Integer numOfAlienLeft; 
	private Integer numOfAstronautIn; 
	private Integer numOfAstronautLeft;
	private Integer score;
	private boolean soundOn;
	private boolean isPause;
	private boolean isGamOver;
	private BGSound bgSound;
	private GetHitSound getHitSound;
	private NewAlienSound newAlienSound;
	private ShipDoorSound shipDoorSound;
	
	private float worldHeight, worldWidth;
	public static final int OPPENENT_MIN_SIZE = 8;
	public static final int OPPENENT_MAX_SIZE = 12;
	public static final int OPPENENT_SPEED_RATIO = 10;
	
	public static final int ASTRONAUT_INITIAL_HEALTH = 5;
	public static final int ASTRONAUT_INITIAL_COLOR = ColorUtil.rgb(255, 0, 0);
	public static final int ASTRONAUT_INITIAL_NUM = 4;
	public static final int ASTRONAUT_MAX_SCORE = 10;

	public static final int ALIEN_INITIAL_COLOR = ColorUtil.BLUE;
	public static final int ALIEN_SPEED_MULTIPLIER = 5;
	public static final int ALIEN_INITIAL_NUM = 3;
	public static final int ALIEN_MAX_NUM = 30;
	public static final int NEW_ALIEN_THERSHOLD_FRAME = 80;
	public static final int ALIEN_PENALTY = 10;
	
	public static final int RESCUER_MOVE_INCREMENT = 10;
	
	public static final int SPACESHIP_INITIAL_SIZE = 50;
	public static final float SPACESHIP_MIN_SIZE_RATIO = 0.5f;
	public static final float SPACESHIP_MAX_SIZE_RATIO = 3f;
	public static final float SPACESHIP_SIZE_INCREMENT_RATIO = 0.1f;
	public static final int SPACESHIP_INITIAL_COLOR = ColorUtil.BLACK;
	
	public static final int SHOCKWAVE_LIFETIME = 120;
	public static final int SHOCKWAVE_SIZE = 80;
	public static final int SHOCKWAVE_SPEED_RATIO = 100;
	
	public static final int ELAPSEDTIME = 20;
	
	public static float LOCAL_SCALING_FACTOR;
	
	
	/**
	 * Set the maximum width of the Local World.
	 * @param xMax maximum width of the world.
	 */
	public void SetWorldWidth(float xMax) {
		this.worldWidth = xMax;
	}
	
	/**
	 * Set the maximum height of Local World.
	 * @param yMax maximum height of the world.
	 */
	public void SetWorldHeight(float yMax) {
		this.worldHeight = yMax;
	}
	
	/**
	 * Initialize this GameWorld. SpaceShip, Aliens, Astronauts will be placed randomly within the fixed size game world.
	 */
	public void init() {
		LOCAL_SCALING_FACTOR = (worldWidth +worldHeight)/2/300;
		go = new GameObjectCollection();
		mainRole = SpaceShip.getSpaceship();
		mainRole.init(worldWidth, worldHeight, SPACESHIP_INITIAL_COLOR);
		go.add(mainRole);
		for (int i = 0; i< ALIEN_INITIAL_NUM; i++) 
			go.add(new Alien(worldWidth, worldHeight, ALIEN_INITIAL_COLOR , ALIEN_SPEED_MULTIPLIER * OPPENENT_SPEED_RATIO));	
		for (int i = 0; i< ASTRONAUT_INITIAL_NUM; i++)
			go.add(new Astronaut(worldWidth, worldHeight, ASTRONAUT_INITIAL_COLOR , ASTRONAUT_INITIAL_HEALTH, OPPENENT_SPEED_RATIO));
		go.add(new VirtualWindow(worldWidth, worldHeight, ColorUtil.LTGRAY));
		
		numOfAlienIn = 0;
		numOfAlienLeft = ALIEN_INITIAL_NUM;
		numOfAstronautIn = 0;
		numOfAstronautLeft = ASTRONAUT_INITIAL_NUM;
		score = 0;
		soundOn = false;
		bgSound = BGSound.getSound();
		bgSound.init("bg2.wav");
		getHitSound = GetHitSound.getSound();
		getHitSound.init("getHit2.mp3");
		newAlienSound = NewAlienSound.getSound();
		newAlienSound.init("newAlien.wav");
		shipDoorSound = ShipDoorSound.getSound();
		shipDoorSound.init("openDoor.wav");
		System.out.println(worldHeight);
		System.out.println(worldWidth);
	}
	
	/**
	 * Overriding the addObserver method so that the ScoreView object will show the game status before users' actions.
	 * @param observer Observer to be registered. 
	 */
	@ Override
	public void addObserver(Observer observer) {
		super.addObserver(observer);
		this.setChanged();
		this.notifyObservers();
	}
	
	/**
	 * return the current SpaceShip.
	 * @return
	 */
	public SpaceShip getSpaceShip(){
		return mainRole;
	}
	
	/**
	 * Return the GameObject Collection.
	 * @return
	 */
	public Iterator<GameObject> getGameObjectIterator(){
		return go.iterator();
	}
		
	/**
	 * Get the number of alien sneaked in.
	 * @return number of alien sneaked in.
	 */
	public Integer getNumOfAlienIn() {
		return numOfAlienIn;
	}
	
	/**
	 * Set the number of alien sneaked in.
	 * @param numOfAlienIn number of alien sneaked in.
	 */
	public void setNumOfAlienIn(int numOfAlienIn) {
		this.numOfAlienIn = numOfAlienIn;
	}
	
	/**
	 * Get the number of alien left on the map.
	 * @return number of alien left on the map.
	 */
	public Integer getNumOfAlienLeft() {
		return numOfAlienLeft;
	}
	
	/**
	 * Set the number of alien left on the map.
	 * @param numOfAlienLeft number of alien left on the map.
	 */
	public void setNumOfAlienLeft(int numOfAlienLeft) {
		this.numOfAlienLeft = numOfAlienLeft;
	}
	
	/**
	 * Get the number of astronauts rescued.
	 * @return the number of astronauts rescued.
	 */
	public Integer getNumOfAstronautIn() {
		return numOfAstronautIn;
	}
	
	/**
	 * Set the number of astronauts rescued.
	 * @param numOfAstronautIn number of astronauts rescued.
	 */
	public void setNumOfAstronautIn(int numOfAstronautIn) {
		this.numOfAstronautIn = numOfAstronautIn;
	}
	
	/**
	 * Get the number of astronauts left on the map.
	 * @return number of astronauts left on the map.
	 */
	public Integer getNumOfAstronautLeft() {
		return numOfAstronautLeft;
	}
	
	/**
	 * Set the number of astronauts left on the map.
	 * @param numOfAstronautLeft number of astronauts left on the map.
	 */
	public void setNumOfAstronautLeft(int numOfAstronautLeft) {
		this.numOfAstronautLeft = numOfAstronautLeft;
	}
	
	/**
	 * Get the current score.
	 * @return the current score.
	 */
	public Integer getScore() {
		return score;
	}
	
	/**
	 * Set the current score.
	 * @param score current score.
	 */
	public void setScore(int score) {
		this.score = score;
	}
	
	/**
	 * Transfer the Spaceship to an random alien, print error message if there is no alien.
	 */
	public void moveSpaceShipToAlien() {
		if (numOfAlienLeft > 0) {
			Vector<GameObject> randomList = new Vector<GameObject>();
			Iterator<GameObject> it = go.iterator();
			while (it.hasNext()) {
				GameObject x = it.next();
				if (x instanceof Alien)
					randomList.add(x);
			}
			Random r = new Random();
			mainRole.JumpToLocation(randomList.get(r.nextInt(randomList.size())));
			System.out.print("<< MoveToAlien >>\n");
			this.setChanged();
			this.notifyObservers();
		}
		else
			System.out.print("Error, no alien left!\n");
		
	} // moveSpaceShipToAlien
	
	/**
	 * Transfer the spaceship to a location of a randomly selected astronaut.
	 */
	public void moveSpaceShipToAstronaut() {
		if (numOfAstronautLeft > 0) {
			Vector<GameObject> randomList = new Vector<GameObject>();
			Iterator<GameObject> it = go.iterator();
			while (it.hasNext()) {
				GameObject x = it.next();
				if (x instanceof Astronaut)
					randomList.add(x);
			}
			Random r = new Random();
			mainRole.JumpToLocation(randomList.get(r.nextInt(randomList.size())));
			System.out.print("<< MoveToAstronaut >>\n");
			this.setChanged();
			this.notifyObservers();
		} // if
		else {
			System.out.print("Error, no astronaut left!\n");
		} //else
	} //moveSpaceShipToAstronaut
	
	/**
	 * Move the spaceship to the right.
	 */
	public void moveSpaceShipRight() {
		mainRole.moveRight((int) (RESCUER_MOVE_INCREMENT * LOCAL_SCALING_FACTOR));
		System.out.print("<< Right >>\n");
		this.setChanged();
		this.notifyObservers();
	} //spaceShipToRight
	
	/**
	 * Move the spaceship to the left.
	 */
	public void moveSpaceShipLeft() {
		mainRole.moveLeft((int) (RESCUER_MOVE_INCREMENT * LOCAL_SCALING_FACTOR));
		System.out.print("<< Left >>\n");
		this.setChanged();
		this.notifyObservers();
	} // spaceShipToLeft
	
	/**
	 * Move the spaceship up.
	 */
	public void moveSpaceShipUp() {
		mainRole.moveUp((int) (RESCUER_MOVE_INCREMENT * LOCAL_SCALING_FACTOR));
		System.out.print("<< Up >>\n");
		this.setChanged();
		this.notifyObservers();
	} //spaceShipToUp
	
	/**
	 * Move the spaceship down.
	 */
	public void moveSpaceShipDown() {
		mainRole.moveDown((int) (RESCUER_MOVE_INCREMENT * LOCAL_SCALING_FACTOR));
		System.out.print("<< Down >>\n");
		this.setChanged();
		this.notifyObservers();
	} //spaceShipToDown
	
	/**
	 * Expand the size of the spaceship door
	 */
	public void expandSpaceShipDoor() {
		if (mainRole.getMyScale().getScaleX() < SPACESHIP_MAX_SIZE_RATIO*LOCAL_SCALING_FACTOR) {
			mainRole.expandDoor(1 + SPACESHIP_SIZE_INCREMENT_RATIO*LOCAL_SCALING_FACTOR, SPACESHIP_MAX_SIZE_RATIO*LOCAL_SCALING_FACTOR);
			System.out.print("<< Expand >>\n");
			this.setChanged();
			this.notifyObservers();
		}
		else
			System.out.print("	Door size is at max.\n");
	} //expandSpaceShipDoor
	
	/**
	 * Contract the size of the spaceship door
	 */
	public void contractSpaceShipDoor() {
		if (mainRole.getMyScale().getScaleX() > SPACESHIP_MIN_SIZE_RATIO*LOCAL_SCALING_FACTOR) {
			mainRole.contractDoor(1-SPACESHIP_SIZE_INCREMENT_RATIO*LOCAL_SCALING_FACTOR, SPACESHIP_MIN_SIZE_RATIO*LOCAL_SCALING_FACTOR);
			System.out.print("<< Contract >>\n");
			this.setChanged();
			this.notifyObservers();
		}
		else
			System.out.print("	Door size is at min.\n");
	} //contractSpaceShipDoor
	
	/**
	 * Tell the game world that the �game clock� has ticked. All moving objects are told to update their positions according to their current direction and speed.
	 * Also detecting if there is collisions.
	 */
	public void tickTime() {
		// move the GameOjects.
		Iterator<GameObject> iter = go.iterator();
		while (iter.hasNext()) {
			GameObject m = iter.next();
			if (m instanceof IMove)
				((IMove)m).move(0, worldWidth, worldHeight, 0, GameWorld.ELAPSEDTIME);
		}
		
		// check for collision.
		Iterator<GameObject> iter1 = go.iterator();
		while (iter1.hasNext()) {
			GameObject x = iter1.next();
			if (x instanceof ICollider) {
				Iterator<GameObject> iter2 = go.iterator();
				while (iter2.hasNext()) {
					GameObject y = iter2.next();
					if (y instanceof ICollider && y != x) {
						ICollider xx = (ICollider) x;
						ICollider yy = (ICollider) y;
						if (xx.collidesWith(yy)) {
							if (!xx.containInList(yy) && !(yy.containInList(xx)))
								xx.handleCollision(yy, this);
						}
						else {
							if (xx.containInList(yy)) {
								xx.removeFromList(yy);
								yy.removeFromList(xx);
							}
						}
					}
				}
			}
		}
		
		//check for game over.
		if (numOfAstronautLeft == 0) {
			this.setGamOver(true);
		}
		this.setChanged();
		this.notifyObservers();
	} // tickTime

	/**
	 * Astronaut get hit if his health > 0.
	 * @param x
	 */
	public void fight(Astronaut x) {
		if (x.getHealth() > 0) 
			x.getHit();
		if (soundOn)
			getHitSound.play();
	}
	
	
	
	// helper's function to check if the Opponents in the SpaceShip's door.
	private static boolean withinDoor(GameObject o, double top, double bottom, double right, double left) {
		return o.getY() <= top && o.getY()>= bottom && o.getX()>= left && o.getX() <= right;
	} 
	
	/**
	 * Open the door and update the score according to the types and conditions of 
	 * opponents that are let in to the spaceship as described above in rules of play. This 
	 * causes all of the opponents whose centers are within the boundaries of the bounding 
	 * square of the door to be removed from the game world.
	 */
	public void openSpaceShipDoor() {

		float doorSize = mainRole.getSize() * mainRole.getMyScale().getScaleX();
		float topBound = mainRole.getY() + doorSize/2;
		float bottomBound = mainRole.getY()- doorSize/2;
		float rightBound = mainRole.getX() + doorSize/2;
		float leftBound = mainRole.getX() - doorSize/2;
		
		if(this.isSoundOn())
			shipDoorSound.play();
		Iterator<GameObject> it = go.iterator();
		while (it.hasNext()) {
			Object cur = it.next();
			if (cur instanceof Alien) {
				if (withinDoor((GameObject)cur, topBound, bottomBound, rightBound, leftBound)) {
					score -= ALIEN_PENALTY;
					this.numOfAlienIn++;
					this.numOfAlienLeft--;
					it.remove();
				}
			} 
			else if (cur instanceof Astronaut) {
				if (withinDoor((GameObject)cur, topBound, bottomBound, rightBound, leftBound)) {
					int scoreGained = ASTRONAUT_MAX_SCORE - (ASTRONAUT_INITIAL_HEALTH - ((Astronaut)cur).getHealth());
					score += scoreGained;
					this.numOfAstronautIn ++;
					this.numOfAstronautLeft --;
					it.remove();
				} //if
			}
		}
		go.add(new ShockWave(worldWidth, worldHeight, mainRole.getX(), mainRole.getY(),SHOCKWAVE_SPEED_RATIO, SHOCKWAVE_LIFETIME));
		System.out.print("<< Score >>\n");
		this.setChanged();
		this.notifyObservers();
	} //method openSpaceShipdoor
	
	/**
	 * Create a new Alien when two Aliens Collide. The location of the new Alien is randomly placed around the colliding Aliens.
	 */
	public void makeNewAlien(Alien a, Alien b) {
		if (this.numOfAlienLeft >= GameWorld.ALIEN_MAX_NUM)
			return;
		if (a.isNew() || b.isNew()) // new Alien cannot reproduce.
			return;
		if (isSoundOn())
			newAlienSound.play();
		Random r = new Random();
		Alien oldGuy = (r.nextInt(2)==1)?a:b;
		Alien newGuy = new Alien(this.worldWidth, this.worldHeight, ALIEN_INITIAL_COLOR , ALIEN_SPEED_MULTIPLIER * OPPENENT_SPEED_RATIO);
		float x = oldGuy.getX();
		float y = oldGuy.getY();
		int s = newGuy.getSize();
		if (x-s < 0)
			x += 2*s;
		if (y-s < 0)
			y += 2*s;
		if (x+s > worldWidth)
			x -= 2*s;
		if (x+s > worldHeight)
			y -= 2*s;
		newGuy.resetTranslate();
		newGuy.translate(x, y);
		go.add(newGuy);
		numOfAlienLeft ++;
		a.addToList(newGuy);
		newGuy.addToList(a);
		b.addToList(newGuy);
		newGuy.addToList(b);
		
		this.setChanged();
		this.notifyObservers();
	} // makeNewAlien
	
	/**
	 * print a �map� showing the current world state.
	 * All the attributes of the GameObject will be shown.
	 */
	public void showMap() {
		System.out.println("<< Show Map >>");
		Iterator<GameObject> it = go.iterator();
		while (it.hasNext())
			System.out.println(it.next());
	} // showMap
	
	/**
	 * set the sound on/off status of all sound.
	 * @param soundOn
	 */
	public void setSoundOn(boolean soundOn) {
		this.soundOn = soundOn;
		setBGSoundStatus();
		this.setChanged();
		this.notifyObservers();
	}

	/**
	 * Return true if the Sound is on.
	 * @return
	 */
	public boolean isSoundOn() {
		return soundOn;
	}

	/**
	 * Return true if the Game is pause.
	 * @return
	 */
	public boolean isPause() {
		return isPause;
	}

	/**
	 * Set to be true if the Game is Pause.
	 * @param isPause
	 */
	public void setPause(boolean isPause) {
		this.isPause = isPause;
	}

	/**
	 * Heal the selected Astronaut.
	 */
	public void heal() {
		if (this.isPause()) {
			Iterator<GameObject> it = go.iterator();
			while (it.hasNext()) {
				GameObject o = it.next();
				if (o instanceof Astronaut && ((Astronaut) o).isSelected()) {
					((Astronaut) o).heal();
				}
			}
			this.setChanged();
			this.notifyObservers();
		}	
	}

	/**
	 * Return true if the Game is over.
	 * @return
	 */
	public boolean isGamOver() {
		return isGamOver;
	}

	/**
	 * Set to be true if Game is over.
	 * @param isGamOver
	 */
	public void setGamOver(boolean isGamOver) {
		this.isGamOver = isGamOver;
	}
	
	/**
	 * play the background sound only if game's status is soundOn and Play.
	 */
	public void setBGSoundStatus() {
		if(this.soundOn && !this.isPause)
			bgSound.play();
		else
			bgSound.pause();
	}

	/**
	 * Return width of Local World.
	 * @return 
	 */
	public float getWorldWidth() {
		return worldWidth;
	}
	
	/**
	 * Return height of Local World.
	 * @return
	 */
	public float getWorldHeight() {
		return worldHeight;
	}
	

	
	
} // class GameWorld
