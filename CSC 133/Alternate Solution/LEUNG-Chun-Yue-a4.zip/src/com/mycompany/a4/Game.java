package com.mycompany.a4;

import java.util.Vector;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.CheckBox;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.Form;
import com.codename1.ui.Toolbar;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.plaf.Border;
import com.codename1.ui.util.UITimer;
import com.mycompany.a4.Commands.GameControl.*;
import com.mycompany.a4.Commands.Setting.*;
import com.mycompany.a4.Views.*;

/**
 * <h1>Game</h1>
 * Space Fight Game. In this game, the human player controls the location of a
 * spaceship. The Game object has:
 * 1) GameWorld which holds a collection of game objects and other state variables.
 * 2) Some GUI objects which accept and execute user commands as an controller.
 * 3) Show the game statistics.
 * 4) Show the game Objects' status (currently show on Console)
 * @author Chun Yue LEUNG
 * @version 4.0
 */
public class Game extends Form implements Runnable{

	private GameWorld gw;
	private MapView mv;
	private ScoreView sv;
	private UITimer timer;
	private Container leftMenu;
	private Vector<BlueButton> playbuttonList;
	private Vector<BlueButton> pausebuttonList;
	private BlueButton buttonPause;
	
	/**
	 * Initialize an GameWorld and Create GUI objects.
	 * And then wait for the player to play.
	 */
	public Game() {
		this.setLayout(new BorderLayout());
		gw = new GameWorld();
		mv = new MapView(gw);
		sv = new ScoreView();

		playbuttonList = new Vector<BlueButton>();
		pausebuttonList = new Vector<BlueButton>();
		
		
		// ***** Start of Right Menu *****
		
			// Contract Button
		BlueButton buttonContract = new BlueButton();
		ContractDoorCommand.setTarget(gw);
		buttonContract.setCommand(ContractDoorCommand.getCommand());
		
		playbuttonList.add(buttonContract);
		 	// Down Button
		BlueButton buttonDown = new BlueButton();
		MoveDownCommand.setTarget(gw);
		buttonDown.setCommand(MoveDownCommand.getCommand());
		playbuttonList.add(buttonDown);
		
		
			// Right Button
		BlueButton buttonRight = new BlueButton();
		MoveRightCommand.setTarget(gw);
		buttonRight.setCommand(MoveRightCommand.getCommand());
		playbuttonList.add(buttonRight);
		
		
			// MoveToAlien Button
		BlueButton buttonMoveToAlien = new BlueButton();
		MoveToAlienCommand.setTarget(gw);
		playbuttonList.add(buttonMoveToAlien);
		buttonMoveToAlien.setCommand(MoveToAlienCommand.getCommand());
		
		
			// Score Button
		BlueButton buttonScore = new BlueButton();
		ScoreCommand.setTarget(gw);
		buttonScore.setCommand(ScoreCommand.getCommand());
		playbuttonList.add(buttonScore);
		
		
			// Create a Container and add above Components
		Container rightMenu = new Container(new BoxLayout(BoxLayout.Y_AXIS));
		rightMenu.getAllStyles().setPaddingTop(50);
		rightMenu.getAllStyles().setBgColor(ColorUtil.WHITE);
		rightMenu.getAllStyles().setBgTransparency(255);
		rightMenu.getAllStyles().setBorder(Border.createLineBorder(1, ColorUtil.BLACK));
		rightMenu.add(buttonContract).add(buttonDown).add(buttonRight).add(buttonMoveToAlien).add(buttonScore);
		this.add(BorderLayout.EAST, rightMenu);
		// End of Right Menu
		
		// ***** Start of Left Menu *****
		
			// Expand Button
		BlueButton buttonExpand = new BlueButton();
		ExpandDoorCommand.setTarget(gw);
		buttonExpand.setCommand(ExpandDoorCommand.getCommand());
		playbuttonList.add(buttonExpand);
		
		
			// Up Button
		BlueButton buttonUp = new BlueButton();
		MoveUpCommand.setTarget(gw);
		buttonUp.setCommand(MoveUpCommand.getCommand());
		playbuttonList.add(buttonUp);
		
		
			// Left Button
		BlueButton buttonLeft = new BlueButton();
		MoveLeftCommand.setTarget(gw);
		buttonLeft.setCommand(MoveLeftCommand.getCommand());
		playbuttonList.add(buttonLeft);
		
		
			// MoveToAstronaut Button
		BlueButton buttonMoveToAstronaut = new BlueButton();
		MoveToAstronautCommand.setTarget(gw);
		buttonMoveToAstronaut.setCommand(MoveToAstronautCommand.getCommand());
		playbuttonList.add(buttonMoveToAstronaut);
		
		
			// Create a Container and add above Components
		leftMenu = new Container(new BoxLayout(BoxLayout.Y_AXIS));
		leftMenu.getAllStyles().setPaddingTop(50);
		leftMenu.getAllStyles().setBgColor(ColorUtil.WHITE);
		leftMenu.getAllStyles().setBgTransparency(255);
		leftMenu.getAllStyles().setBorder(Border.createLineBorder(1, ColorUtil.BLACK));
		leftMenu.add(buttonExpand).add(buttonUp).add(buttonLeft).add(buttonMoveToAstronaut);
		this.add(BorderLayout.WEST, leftMenu);
		
		// End of Left Menu
		
		// ***** Start of Bottom Menu *****
		
		
			// Heal Button
		BlueButton buttonHeal = new BlueButton();
		HealCommand.setTarget(gw);
		buttonHeal.setCommand(HealCommand.getCommand());
		pausebuttonList.add(buttonHeal);
		
			// Pause Button
		buttonPause = new BlueButton();
		PauseCommand.setTarget(this, buttonPause);
		buttonPause.setCommand(PauseCommand.getCommand());
		
			// Create a Container and add above Components
		Container bottomMenu = new Container(new FlowLayout(Component.CENTER));
		bottomMenu.getAllStyles().setBgColor(ColorUtil.WHITE);
		bottomMenu.getAllStyles().setBgTransparency(255);
		bottomMenu.getAllStyles().setBorder(Border.createLineBorder(1, ColorUtil.BLACK));
		bottomMenu.add(buttonHeal).add(buttonPause);
		this.add(BorderLayout.SOUTH, bottomMenu);
		
		// End of Bottom Menu
		
		// ***** Start of ToolBar *****
		
			//Sound CheckBox
		CheckBox checkBoxSound = new CheckBox();
		checkBoxSound.getAllStyles().setBgTransparency(255);
		checkBoxSound.getAllStyles().setBgColor(ColorUtil.LTGRAY);
		SoundCommand commandSound = new SoundCommand(gw);
		checkBoxSound.setSelected(gw.isSoundOn());
		checkBoxSound.setCommand(commandSound);
		
			
			//Exit
		ExitCommand commandExit = new ExitCommand();
		this.addKeyListener('x', commandExit);
		
			//About
		AboutCommand commandAbout = new AboutCommand();
		
			// help
		HelpCommand commandHelp = new HelpCommand();
		
			// Create ToolBar and add above Components
		Toolbar myToolbar = new Toolbar();
		this.setToolbar(myToolbar);
		myToolbar.setTitle("SpaceFightGame");
		myToolbar.addCommandToSideMenu(ScoreCommand.getCommand());
		myToolbar.addCommandToSideMenu(commandAbout);
		myToolbar.addCommandToSideMenu(commandExit);
		myToolbar.addComponentToSideMenu(checkBoxSound);
		myToolbar.addCommandToRightBar(commandHelp);
		
		// End of ToolBar
		
		this.add(BorderLayout.CENTER, mv);
		this.add(BorderLayout.NORTH, sv);
		this.show();
		
		System.out.println("width:"+mv.getWidth()+"\theight:"+mv.getHeight());
		gw.SetWorldWidth(mv.getWidth()/2);
		gw.SetWorldHeight(mv.getHeight()/2);
		gw.init();
		gw.addObserver(mv);
		gw.addObserver(sv);
		mv.initWorldWindow();
		
		timer = new UITimer (this);
		timer.schedule(GameWorld.ELAPSEDTIME, true, this);
		
		play();
	}
	
	/***
	 * Call the GameWorld's time to click.
	 */
	public void run() {
		// If GameOver, disabled All the buttons and keyListeners
		// except exit, about, help, sound on/off checkbox
		if (gw.isGamOver()) {
			timer.cancel();
			new GameOver(gw.getScore());
			pause();
			for (BlueButton x: pausebuttonList) 
				x.setEnabled(false);
			buttonPause.setEnabled(false);
			ScoreCommand.setAble(false);
		}
		else
			gw.tickTime();
	}
	/**
	 * Pause the Game, Buttons in the playbuttonlist will be disabled while
	 * Buttons in the pauseButtonlist will be enabled.
	 * KeyListensers except "x" will be disabled.
	 * Score Command will be disabled.
	 */
	public void pause() {
		gw.setPause(true);
		timer.cancel();
		for (BlueButton x: playbuttonList)
			x.setEnabled(false);
		for (BlueButton x: pausebuttonList) 
			x.setEnabled(true);
		this.removeKeyListener('c', ContractDoorCommand.getCommand());
		this.removeKeyListener('e', ExpandDoorCommand.getCommand());
		this.removeKeyListener('d', MoveDownCommand.getCommand());
		this.removeKeyListener('r', MoveRightCommand.getCommand());
		this.removeKeyListener('u', MoveUpCommand.getCommand());
		this.removeKeyListener('l', MoveLeftCommand.getCommand());
		this.removeKeyListener('a', MoveToAlienCommand.getCommand());
		this.removeKeyListener('o', MoveToAstronautCommand.getCommand());
		this.removeKeyListener('s', ScoreCommand.getCommand());
		
		ScoreCommand.setAble(false);
		
		gw.setBGSoundStatus();
	}
	/**
	 * Continue the game, Buttons in the pausebuttonlist will be disabled while
	 * Buttons in the playbuttonlist will be enabled.
	 * All KeyListensers except will be enabled.
	 * ScoreCommand will be enabled.
	 */
	public void play() {
		timer.schedule(GameWorld.ELAPSEDTIME, true, this);
		gw.setPause(false);
		for (BlueButton x: playbuttonList) 
			x.setEnabled(true);
		for (BlueButton x: pausebuttonList) 
			x.setEnabled(false);
		
		this.addKeyListener('c', ContractDoorCommand.getCommand());
		this.addKeyListener('e', ExpandDoorCommand.getCommand());
		this.addKeyListener('d', MoveDownCommand.getCommand());
		this.addKeyListener('r', MoveRightCommand.getCommand());
		this.addKeyListener('u', MoveUpCommand.getCommand());
		this.addKeyListener('l', MoveLeftCommand.getCommand());
		this.addKeyListener('a', MoveToAlienCommand.getCommand());
		this.addKeyListener('o', MoveToAstronautCommand.getCommand());
		this.addKeyListener('s', ScoreCommand.getCommand());
		
		ScoreCommand.setAble(true);
		
		gw.setBGSoundStatus();
	}

}
