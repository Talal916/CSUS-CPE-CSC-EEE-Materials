package com.mycompany.a4.GameObjects.Alien;

import java.util.Random;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;
import com.mycompany.a4.GameWorld;
import com.mycompany.a4.GameObjects.Opponent;
import com.mycompany.a4.GameObjects.Point;

/**
 * <h1>Alien</h1>
 * An Game Character with fixed color, fixed size and fixed speed after initialized.
 * @author Chun Yue LEUNG
 * @version 4.0
 */
public class Alien extends Opponent{
	
	private int counter;
	Point lowerLeftInLocalSpace;
	private Limb [] arms;
	private Limb [] legs;
	private Head head;
	private int armOffset; 
	private int armMovement; 
	private int maxArmOffset;
	private float legOffset; 
	private float legMovement; 
	private float maxLegOffset; 
	/**
	 * Initialize an Alien to random location, random size.
	 * Color and speed are also needed to be set.
	 * @param maxX maximum possible x
	 * @param maxY maximum possible y
	 * @param minSize minimum possible size
	 * @param maxSzie maximum possible size
	 * @param color RGB int value
	 * @param speed speed
	 */
	public Alien(float maxX, float maxY, int color, float speedRatio) {
		super.setColor(color);
		Random r = new Random();
		super.setRandomSize(GameWorld.OPPENENT_MIN_SIZE, GameWorld.OPPENENT_MAX_SIZE);
		float x = (maxX-this.getSize()) * r.nextFloat() + this.getSize();
		float y = (maxY-this.getSize()) * r.nextFloat() + this.getSize();
		initTransform();
		this.translate((float)x, (float)y);
		this.scale(GameWorld.LOCAL_SCALING_FACTOR, GameWorld.LOCAL_SCALING_FACTOR);
		this.scale(0.8f, 1.2f);
		this.setDirection(r.nextInt(360));
		this.rotate(-this.getDirection());
		super.setSpeed((int) (speedRatio*GameWorld.LOCAL_SCALING_FACTOR));
		initCollisionList();
		this.setCounter(GameWorld.NEW_ALIEN_THERSHOLD_FRAME);
		lowerLeftInLocalSpace = new Point(-this.getSize()/2, -this.getSize()/2);
		
		// 4 limbs
		arms = new Limb [2]; 
		int s = this.getSize();
		Limb f0 = new Limb(s, ColorUtil.GRAY); f0.translate(0, s*0.6f);f0.rotate(-45);f0.scale(0.5f, 0.2f);
		arms[0] = f0 ; 
		Limb f1 = new Limb(s,ColorUtil.GRAY); f1.translate(0, s*0.6f);f1.rotate(40);f1.scale(0.5f, 0.2f);
		arms[1] = f1 ;
		
		legs = new Limb [2]; 
		Limb f2 = new Limb(s,ColorUtil.GREEN); f2.translate(0, s*0.7f);f2.rotate(205);f2.scale(0.2f, 0.4f);
		legs[0] = f2 ; 
		Limb f3 = new Limb(s,ColorUtil.GREEN); f3.translate(0, s*0.7f);f3.rotate(155);f3.scale(0.2f, 0.4f);
		legs[1] = f3;
		
		armOffset = 0;
		maxArmOffset = 28;
		armMovement = 3;
		
		legOffset = 0;
		legMovement = 0.15f * GameWorld.LOCAL_SCALING_FACTOR;
		maxLegOffset = 0.45f * GameWorld.LOCAL_SCALING_FACTOR;
		
		// head
		head = new Head(s, ColorUtil.rgb(255,69,0));head.translate(0, s*00.6f);head.rotate(0);head.scale(0.5f, -0.25f);
	}
	
	/**
	 * The color of an Alien cannot be changed after initialized
	 */
	@Override // Alien's color cannot be changed after initialized
	public void setColor(int x) {}
	
	/**
	 * The color of an Alien cannot be changed after initialized
	 */
	@Override // Alien's color cannot be changed after initialized
	public void setColor(int r, int g, int b) {}
	
	/**
	 * The speed of an Alien cannot be changed after initialized
	 */
	@Override
	public void setSpeed(int s) {}
	
	/**
	 * The size of an Alien cannot be changed after initialized
	 */
	@Override
	public void setSize(int s) {}
	
	/**
	 * The size of an Alien cannot be changed after initialized
	 */
	@Override
	public void setRandomSize(int min, int max) {}
	
	/**
	 * return a String with the Game Object's stats.
	 */
	@Override
	public String toString(){
		String parentDesc = super.toString();
		String myDesc1 = "Alien: ";
		return myDesc1 + parentDesc;
	}
	
	/**
	 * Draw this object.
	 */
	public void draw(Graphics g, Point pCmpRelPrnt, Point pCmpRelScrn) {
	//	if (this.isNew())
	//		g.setColor(GameWorld.ALIEN_INITIAL_COLOR);
	//	else
		g.setColor(this.getColor());
		Transform gXform = Transform.makeIdentity();
		g.getTransform(gXform);
		Transform oriGxform = gXform.copy();
		this.LocalTransfrom(gXform, pCmpRelScrn);
	
		g.setTransform(gXform);
		int s = this.getSize();
		g.fillArc((int)(pCmpRelPrnt.getX() + lowerLeftInLocalSpace.getX()),
				(int)(pCmpRelPrnt.getY() + lowerLeftInLocalSpace.getY()),
				s, s, 0, 360);
		for (Limb x : arms)
			x.draw(g, pCmpRelPrnt, pCmpRelScrn);
		for (Limb x : legs)
			x.draw(g, pCmpRelPrnt, pCmpRelScrn);
		
		head.draw(g, pCmpRelPrnt, pCmpRelScrn);
	//	updateLTs();
		g.setTransform(oriGxform);
		
		if (counter > 0)
			counter--;
	}
	
	/**
	 * create dynamic movements of the limbs
	 */
	public void updateLTs () {
		for (Limb x:arms) {
			x.rotate(armMovement);
		}
		
		
		for (Limb x:legs) {
			x.translate(0,legMovement);
			x.rotate(-armMovement);
		}
		
		armOffset += armMovement ;
		if (Math.abs(armOffset) >= maxArmOffset) 
			armMovement *= -1 ;
		legOffset += legMovement ;
		if (Math.abs(legOffset) >= maxLegOffset) 
			legMovement *= -1 ;
	}
	
	/**
	 * Return true if the Alien is newly created.
	 * @return 
	 */
	public boolean isNew() {
		return counter > 0;
	}
	/**
	 * See the Counter of "new" status of the Alien.
	 * @param n
	 */
	public void setCounter(int n) {
		counter = n;
	}
	
	@Override
	/**
	 * In addition to original move, also move the limbs.
	 */
	public void move(float winLeft, float winRight, float winTop, float winBottom, int elapsedTime) {
		super.move(winLeft, winRight, winTop, winBottom, elapsedTime);
		this.updateLTs();
	}
}
