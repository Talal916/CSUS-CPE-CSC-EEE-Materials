package com.mycompany.a4.GameObjects;
import com.mycompany.a4.GameWorld;

/**
 * <h1>IMove</h1>
 * Interface for collision behavior.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public interface ICollider {
	/**
	 * Return true if this object collide with otherObject
	 * @param otherObject
	 * @return 
	 */
	public boolean collidesWith(ICollider otherObject);
	
	/**
	 * Define what to do when there is a collision. 
	 * @param otherObject
	 */
	public void handleCollision(ICollider otherObject, GameWorld gw);
	
	/**
	 * Add the otherObject into the Collision List.
	 * @param otherObject
	 */
	public void addToList(ICollider otherObject);
	
	/**
	 * Remove the otherObject from the Collision List.
	 * @param otherObject
	 */
	public void removeFromList(ICollider otherObject);
	
	/**
	 * Return if the otherObject in the Collision List.
	 * @param otherObject
	 */
	public boolean containInList(ICollider otherObject);
	

}

