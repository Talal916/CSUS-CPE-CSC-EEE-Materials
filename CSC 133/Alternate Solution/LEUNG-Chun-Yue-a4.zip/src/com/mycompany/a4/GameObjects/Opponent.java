package com.mycompany.a4.GameObjects;

import java.util.Random;
import java.util.Vector;
import com.mycompany.a4.GameWorld;
import com.mycompany.a4.GameObjects.Alien.Alien;

/**
 * <h1>Opponent</h1>
 * In addition to contain GameObject's attributes, it also contains speed and direction.
 * Direction is the heading direction of an Opponent. 
 * Moreover, it has an move's behavior.
 * @see com.mycompany.a4.GameObjects.a2.GameObject.GameObject
 * @author Chun Yue LEUNG
 * @version 4.0
 */
public abstract class Opponent extends GameObject implements IMove, ICollider{

	private int speed;
	private int direction;
	private Vector<ICollider> CollisionList;
	
	/**
	 * Set random size of this Opponent between minimum and maximum size (inclusive)
	 * @param min minimum size of this Opponent
	 * @param max maximum size of this Opponent
	 */
	public void setRandomSize(int min, int max) { 
		if (getSize() == 0) {
			Random r = new Random();
			super.setSize(min + r.nextInt(max-min+1));
		}
	} 
	
	/**
	 * get this Opponent's speed
	 * @return speed
	 */
	public int getSpeed() {
		return speed;
	} 
	
	/**
	 * get this Opponent's direction
	 * @return direction
	 */
	public int getDirection() {
		return direction;
	} 

	
	/**
	 * set this Opponent's direction in degree with range between 0 to 359, adjust back to the range if the value out of range 
	 * @param d
	 */
	public void setDirection(int d) {
		if (d < 0)
			d += 360;
		if (d >= 360)
			d -= 360;
		direction = d;
	} 
	
	/**
	 * set this Opponent's speed
	 * @param s
	 */
	public void setSpeed(int s) {
		speed = s;
	} 
	
	/**
	 * return a String with the Game Object's stats.
	 */
	@Override
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " speed=" + speed + " dir=" + direction;
		return parentDesc + myDesc;
	} //toString
	
	/**
	 * @see com.mycompany.a4.GameObjects.GameObject.IMove#move()
	 * Move this Opponent subject to its speed and direction. If it hit the boundary, 
	 * its direction will be changed according to the reflection angle. After each move, the direction
	 * will be sightly changed random so that this Opponent does not move as a straight line.
	 */
	public void move(float winLeft, float winRight, float winTop, float winBottom, int elapsedTime) {
		double theta = Math.toRadians(this.getDirection());
		float deltaX = (float)(Math.sin(theta) * getSpeed() * (float)elapsedTime/1000);
		float deltaY = (float)(Math.cos(theta) * getSpeed() * (float)elapsedTime/1000);
		this.translate(deltaX, deltaY);
		this.resetRotate();
		this.rotate(-this.getDirection());

		// rebound to direction based  when hit the boundary
			int s = this.getSize();
			float x = this.getX();
			float y = this.getY();
			int reboundOffset = s/8;
			if (x-s/2 <= winLeft) {
				this.setDirection(-getDirection());
				this.resetRotate();
				this.rotate(this.getDirection());
				this.translate(reboundOffset, 0);
			}
			else if (x+s/2 >= winRight) {
				this.setDirection(-getDirection());
				this.resetRotate();
				this.rotate(this.getDirection());
				this.translate(-reboundOffset, 0);
			}
			else if (y-s/2 <= winBottom) {
				this.setDirection(180 - getDirection());
				this.resetRotate();
				this.rotate(this.getDirection());
				this.translate(0, reboundOffset);
			}
			else if (y+s/2 >= winTop) {
				this.setDirection(180 - getDirection());
				this.resetRotate();
				this.rotate(this.getDirection());
				this.translate(0, -reboundOffset);
			}
			else {
				Random r = new Random();
				int randomAngle = -3 + r.nextInt(7);
				this.setDirection(getDirection() +randomAngle);
			//	this.resetRotate();
				this.rotate(-randomAngle);
			}

	} //move
	
	/**
	 * Return true if:
	 * Two Aliens collides or 
	 * An Alien and a Astronaut collides
	 */
	public boolean collidesWith(ICollider that) {
		
		float thisX = this.getX();
		float thisY = this.getY();
		float thisS = this.getSize()/2 * (this.getMyScale().getScaleX() + this.getMyScale().getScaleY())/2;
		Opponent o = (Opponent)that;
		float thatX = o.getX();
		float thatY = o.getY();
		float thatS = o.getSize()/2 * (o.getMyScale().getScaleX() + o.getMyScale().getScaleY())/2;
		return (thisX - thatX)*(thisX - thatX) + (thisY - thatY)*(thisY - thatY) <
				thisS*thisS + 2*thisS*thatS + thatS* thatS;
	}
	/**
	 * Add the two ICollider to each other's Collider's list.
	 */
	public void handleCollision(ICollider that, GameWorld gw) {
		this.addToList(that);
		that.addToList(this);
		if (this instanceof Alien && that instanceof Alien && gw.getNumOfAlienLeft() < GameWorld.ALIEN_MAX_NUM) {
			gw.makeNewAlien((Alien)this, (Alien)that);
		}
		else if (this instanceof Astronaut && that instanceof Astronaut) {
			// do nothing now
		}
		else if(this instanceof Astronaut)
			gw.fight((Astronaut)this);
		else if(that instanceof Astronaut)
			gw.fight((Astronaut)that);
	}
	/**
	 * Add the otherObject to the Collision List.
	 */
	public void addToList(ICollider otherObject) {
		CollisionList.add(otherObject);
	}
	/**
	 * remove the otherObject from the Collision List.
	 */
	public void removeFromList(ICollider otherObject) {
		CollisionList.remove(otherObject);
	}
	/**
	 * Return true if the otherObject is in the Collision List.
	 */
	public boolean containInList(ICollider otherObject) {
		return CollisionList.contains(otherObject);
	}
	/**
	 * Initialize the Collision List.
	 */
	public void initCollisionList() {
		CollisionList = new Vector<ICollider>();
	}

} // class Opponent
