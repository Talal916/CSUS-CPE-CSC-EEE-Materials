package com.mycompany.a4.GameObjects;

/**
 * <h1>ISelectable</h1>
 * Interface for select behavior.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public interface ISelectable {
	public void setSelected(boolean yesNo);
	public boolean isSelected();
	
	/**
	 * Return true if the Pointer within the boundary of this object.
	 * @param pPtrRelPrnt pointer position relative to the parent origin
	 * @param pCmpRelPrnt the component position relative to the parent origin
	 * @return
	 */
	public boolean contains(float[] fPtr);
}
