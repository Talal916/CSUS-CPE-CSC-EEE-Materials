package com.mycompany.a4.GameObjects.Alien;

import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;
import com.mycompany.a4.GameObjects.GameObject;
import com.mycompany.a4.GameObjects.Point;

/**
 * <h1>Alien</h1>
 * Alien's Head.
 * @author Chun Yue LEUNG
 * @version 4.0
 */
public class Head extends GameObject{
	
	public Head (int size, int color){
		this.setSize(size);
		this.setColor(color);
		this.initTransform();
}

/**
 * draw an traingle. 
 */
public void draw (Graphics g, Point pCmpRelPrnt, Point pCmpRelScrn) {

	g.setColor(this.getColor());
	Transform gXform = Transform.makeIdentity();
	g.getTransform(gXform);
	Transform gOrigXform = gXform.copy(); //save the original xform
	gXform.translate((float)(pCmpRelScrn.getX()),(float)(pCmpRelScrn.getY()));
	gXform.concatenate(getMyRotation());
	gXform.translate(getMyTranslation().getTranslateX(), getMyTranslation().getTranslateY());
	gXform.scale(getMyScale().getScaleX(), getMyScale().getScaleY());
	gXform.translate((float)(-pCmpRelScrn.getX()),(float)(-pCmpRelScrn.getY()));
	g.setTransform(gXform);
	int s = this.getSize();
	int [] traingleX = {(int) (pCmpRelPrnt.getX() + -s/2),
			+(int) (pCmpRelPrnt.getX() + s/2),
			(int) (pCmpRelPrnt.getX())};
	int [] traingleY = {(int) (pCmpRelPrnt.getY() -s/2), 
			(int) (pCmpRelPrnt.getY() -s/2), 
			+(int) (pCmpRelPrnt.getY() +s/2)};
	g.fillPolygon(traingleX, traingleY, 3);
	g.setTransform(gOrigXform); //restore the original xform (remove LTs)
}
}

