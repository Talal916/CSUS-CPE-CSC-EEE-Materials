package com.mycompany.a4.GameObjects;

import java.util.Random;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;
import com.mycompany.a4.GameWorld;

/**
 * <h1>ShockWave</h1>
 * An GameObject implements IMove, which is a beizer curves generating
 * by the center of SpaceShip and 3 other random points.
 * This object will be created when the SpaceShip opens door,
 * after created, it will live for several time frames, and it will move
 * to random direction with constant speed.
 * @author Chun Yue LEUNG
 * @version 4.0
 */
public class ShockWave extends GameObject implements IMove{
	private int lifeTime;
	private Point[] initialQ;
	float epsilon = 0.01f;
	int direction;
	int speed;
	Point lowerLeftInLocalSpace;
	
	/**
	 * Constructor
	 * @param maxX width of local world.
	 * @param maxY height of local world.
	 * @param q0x x location of spaceship.
	 * @param q0y y location of spaceship
	 * @param speedConstant
	 * @param lifeTime number of time frame to live.
	 */
	public ShockWave(float maxX, float maxY, float q0x, float q0y, float speedRatio, int lifeTime) {
		initTransform();
		this.translate(q0x, q0y);
		Random r = new Random();
		direction = r.nextInt(360);
		this.setColor(ColorUtil.rgb(r.nextInt(256), r.nextInt(256), r.nextInt(256)));
		this.lifeTime = lifeTime;
		initialQ = new Point[4];
		initialQ[0] = new Point(q0x, q0y);
		lowerLeftInLocalSpace = new Point(q0x, q0y);
		this.speed = (int) (speedRatio * GameWorld.LOCAL_SCALING_FACTOR);
		int s = GameWorld.SHOCKWAVE_SIZE;
		for (int i = 1; i < 4; i++)
			initialQ[i] = new Point(q0x + (-s/2 + (s+1)*r.nextFloat())* GameWorld.LOCAL_SCALING_FACTOR,
					q0y+(-s/2 + (s+1)*r.nextFloat())* GameWorld.LOCAL_SCALING_FACTOR);
	}
	
	// Recursive algorithm to draw the bezier curve 
	private void drawBezierCurve (Point[] Q, Point pCmpRelPrnt, Graphics g) {
		if (straightEnough(Q))
			drawLine(g, pCmpRelPrnt, Q); 
		else {
			Point[] R = new Point[4];
			Point[] S = new Point[4];
			subdivideCurve (Q, R, S) ;
			drawBezierCurve (R, pCmpRelPrnt, g) ;
			drawBezierCurve (S, pCmpRelPrnt, g) ;
		}
	}
	
	// Check if the points in the array is straight enough or not
	private boolean straightEnough (Point[] Q) {
		// find length around control polygon
		float d1 = lengthOf(Q[0],Q[1]) + lengthOf(Q[1],Q[2]) + lengthOf(Q[2],Q[3]);
		// find distance directly between first and last control point
		float d2 = lengthOf(Q[0],Q[3]) ;
		if ( Math.abs(d1-d2) < epsilon ) // epsilon (�tolerance�) = (e.g.) .001
			return true ;
		else
			return false ;
	}
	
	// return the length of Point X and Y.
	private float lengthOf(Point X, Point Y) {
		return (float) Math.sqrt((X.getX()-Y.getX()) * (X.getX()-Y.getX()) 
				+ (X.getY()-Y.getY()) * (X.getY()-Y.getY()) );
	}
	
	// Draw the 
	private void drawLine(Graphics g, Point pCmpRelPrnt, Point[]Q) {
		g.drawLine((int)(Q[0].getX() + pCmpRelPrnt.getX()- lowerLeftInLocalSpace.getX()), 
				(int)(Q[0].getY() + pCmpRelPrnt.getY() - lowerLeftInLocalSpace.getY()), 
				(int)(Q[3].getX() + pCmpRelPrnt.getX() - lowerLeftInLocalSpace.getX()), 
				(int)(Q[3].getY() + pCmpRelPrnt.getY() - lowerLeftInLocalSpace.getY()));
	}
	
	// Helper function of the recursive bezier curve algorithm.
	private void subdivideCurve (Point[] Q, Point[] R, Point[] S) {
	//	R(0) = Q(0) ;
	//	R(1) = (Q(0)+Q(1)) / 2.0 ;
	//	R(2) = (R(1)/2.0) + (Q(1)+Q(2))/4.0 ;
	//	S(3) = Q(3) ;
	//	S(2) = (Q(2)+Q(3)) / 2.0 ;
	//	S(1) = (Q(1)+Q(2))/4.0 + S(2)/2.0 ;
	//	R(3) = (R(2)+S(1)) / 2.0 ;
	//	S(0) = R(3) ;
		
		R[0] = new Point( Q[0].getX(), Q[0].getY() );
		R[1] = new Point( (Q[0].getX() + Q[1].getX())/2, (Q[0].getY() + Q[1].getY())/2);
		R[2] = new Point( R[1].getX()/2 + (Q[1].getX() + Q[2].getX())/4,  R[1].getY()/2 + (Q[1].getY() + Q[2].getY())/4);
		S[3] = new Point( Q[3].getX(), Q[3].getY() );
		S[2] = new Point( (Q[2].getX() + Q[3].getX())/2, (Q[2].getY() + Q[3].getY())/2);
		S[1] = new Point( S[2].getX()/2 + (Q[2].getX() + Q[1].getX())/4,  S[2].getY()/2 + (Q[2].getY() + Q[1].getY())/4);
		R[3] = new Point( (R[2].getX() + S[1].getX())/2, (R[2].getY() + S[1].getY())/2);
		S[0] = new Point( R[3].getX(), R[3].getY() );
	}
	
	/**
	 * return true if the Shockwave has to die.
	 * @return
	 */
	public boolean isEndOfLife() {
		return lifeTime <= 0;
	}
	
	/**
	 * Draw method, draw a bezier curve.
	 */
	public void draw(Graphics g, Point pCmpRelPrnt, Point pCmpRelScrn) {
		g.setColor(this.getColor());
		Transform gXform = Transform.makeIdentity();
		g.getTransform(gXform);
		Transform oriGxform = gXform.copy();
		this.LocalTransfrom(gXform, pCmpRelScrn);
	
		g.setTransform(gXform);
		
		drawBezierCurve(initialQ, pCmpRelPrnt, g);
		
		g.setTransform(oriGxform);
		
	}

	/**
	 * Shockwave will move in random direction with constant speed.
	 */
	public void move(float winLeft, float winRight, float winTop, float winBottom, int elapsedTime) {
		double theta = Math.toRadians(this.getDirection());
		float deltaX = (float)(Math.sin(theta) * getSpeed() * (float)elapsedTime/1000);
		float deltaY = (float)(Math.cos(theta) * getSpeed() * (float)elapsedTime/1000);
		this.translate(deltaX, deltaY);
	}

	/**
	 * return the speed.
	 * @return
	 */
	private double getSpeed() {
		return speed;
	}

	/**
	 * return the direction.
	 * @return
	 */
	private int getDirection() {
		return direction;
	}
	
	/**
	 * Override the ToString() Method.
	 */
	@Override
	public String toString() {
		String parentDesc = super.toString();
		String myDesc1 = "Shockwave: ";
		String myDesc2 = " speed=" + speed + " dir=" + direction;
		return myDesc1 + parentDesc + myDesc2;
	} //toString
	
	/**
	 * return the current life time of shockwave.
	 * @return
	 */
	public int getLifeTime() {
		return lifeTime;
	}
	/**
	 * Set the life time of shockwave.
	 * @param lifeTime
	 */
	public void setLifeTime(int lifeTime) {
		this.lifeTime = lifeTime;
	}

}
