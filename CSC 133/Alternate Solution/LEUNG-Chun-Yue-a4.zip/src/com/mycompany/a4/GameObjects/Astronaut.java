package com.mycompany.a4.GameObjects;

import java.util.Random;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;
import com.codename1.ui.Transform.NotInvertibleException;
import com.mycompany.a4.GameWorld;

/**
 * <h1>Astronaut</h1>
 * An Game Character with additional attributes such as health and speedConstant.
 * The speed of an Astronaut is equal to health * speedConstant.
 * If an Astronaut got attacked, it health value will be minus by one
 * and its color will be faded.
 * @author Chun Yue LEUNG
 * @version 2.0
 */
public class Astronaut extends Opponent implements ISelectable{

	private int health;
	private int speedConstant;
	private boolean isSelected;
	Point lowerLeftInLocalSpace;
	
	/**
	 * Get this Astronaut's health
	 * @return health
	 */
	public int getHealth() {
		return health;
	}
	
	/**
	 * Set this Astronaut's health
	 * @param h health
	 */
	public void setHealth(int h) {
		health = h;
	}
	
	/**
	 * Get the this Astronaut's speed constant
	 * @return speedConstant
	 */
	public int getSpeedConstant() {
		return speedConstant;
	}
	
	/**
	 * the size of an Astronaut cannot be changed after initialized
	 */
	@Override 
	public void setSize(int x) {} 
	
	/**
	 * the size of an Astronaut cannot be changed after initialized
	 */
	@Override
	public void setRandomSize(int min, int max) {}
	
	/**
	 * return a String with the Game Object's stats.
	 */
	@Override
	public String toString() {
		String parentDesc = super.toString();
		String myDesc1 = "Astronaut: ";
		String myDesc2 = " health=" + health;
		return myDesc1 + parentDesc + myDesc2;
		
	}
	
	/**
	 * Initialize an Astronaut to random location, random size, random direction.
	 * Health, color and speed constant are also needed to be set
	 * @param maxX maximum possible x
	 * @param maxY maximum possible y
	 * @param minSize minimum possible size
	 * @param maxSzie maximum possible size
	 * @param color RGB int value
	 * @param health 
	 * @param speedConstant
	 */
	public Astronaut(float maxX, float maxY, int color, int health, float speedRatio) {
		Random r = new Random();
		super.setRandomSize(GameWorld.OPPENENT_MIN_SIZE, GameWorld.OPPENENT_MAX_SIZE);
		float x = (maxX-this.getSize()) * r.nextFloat() + this.getSize();
		float y = (maxY-this.getSize()) * r.nextFloat() + this.getSize();
		initTransform();
		this.translate((float)x, (float)y);
		this.scale(GameWorld.LOCAL_SCALING_FACTOR, GameWorld.LOCAL_SCALING_FACTOR);
		setHealth(health);
		setColor(color);
		this.setDirection(r.nextInt(360));
		this.rotate(-this.getDirection());
		this.speedConstant = (int) (speedRatio * GameWorld.LOCAL_SCALING_FACTOR);
		this.setSpeed(health * speedConstant);
		initCollisionList();
		lowerLeftInLocalSpace = new Point(-this.getSize()/2, -this.getSize()/2);
		
	}

	/**
	 * This Astronaut's got hit, if its health is greater than zero, it will minus by one and its color
	 * will be faded by one gradient. no change if this Astronaut's's health is zero.
	 */
	public void getHit() {
		if (health > 0) {
			health--;
			int c = this.getColor();
			this.setColor(ColorUtil.red(c), ColorUtil.green(c)+40, ColorUtil.blue(c)+40);
			this.setSpeed(health * speedConstant);
		}
	}
	/**
	 * Heal the Astronaut to full health.
	 */
	public void heal() {
		this.setHealth(GameWorld.ASTRONAUT_INITIAL_HEALTH);
		this.setSpeed(health * speedConstant);
		this.setColor(GameWorld.ASTRONAUT_INITIAL_COLOR);
	}

	/**
	 *  Draw the Game Object.
	 */
	public void draw(Graphics g, Point pCmpRelPrnt, Point pCmpRelScrn) {
		g.setColor(this.getColor());
		
		Transform gXform = Transform.makeIdentity();
		g.getTransform(gXform);
		Transform oriGxform = gXform.copy();
		this.LocalTransfrom(gXform, pCmpRelScrn);
		g.setTransform(gXform);
		
		int s = this.getSize();
		int [] traingleX = {(int) (pCmpRelPrnt.getX() + lowerLeftInLocalSpace.getX()),
				+(int) (pCmpRelPrnt.getX() + lowerLeftInLocalSpace.getX() + s),
				(int) (pCmpRelPrnt.getX() + lowerLeftInLocalSpace.getX() + s/2)};
		int [] traingleY = {(int) (pCmpRelPrnt.getY() + lowerLeftInLocalSpace.getY()), 
				(int) (pCmpRelPrnt.getY() + lowerLeftInLocalSpace.getY()), 
				+(int) (pCmpRelPrnt.getY() + lowerLeftInLocalSpace.getY() + s)};
		if(isSelected()) {
			g.drawPolygon(traingleX, traingleY, 3);
		}
		else {
			g.fillPolygon(traingleX, traingleY, 3);
		}
		g.setTransform(oriGxform);
	}

	/**
	 * Set the Astronaut to be selected.
	 */
	public void setSelected(boolean yesNo) {
		isSelected = yesNo;
	}

	/**
	 * Return true if the Astronaut is selected.
	 */
	public boolean isSelected() {
		return isSelected;
	}
	
	/**
	 * Return true if the pointer within the Astronaut's boundary.
	 */
	public boolean contains(float[] fPtr) {
		Transform concatLTs = Transform.makeIdentity();
		concatLTs.translate(this.getMyTranslation().getTranslateX(), this.getMyTranslation().getTranslateY());
		concatLTs.concatenate(this.getMyRotation());
		concatLTs.scale(this.getMyScale().getScaleX(), this.getMyScale().getScaleY());
		//calculate inverse of concatLTs
		Transform inverseConcatLTs = Transform.makeIdentity();
		try {
			concatLTs.getInverse(inverseConcatLTs);
		} catch (NotInvertibleException e) {
			System.out.println("Non invertible xform!");}
		//make sure that the point is not already transformed with previous sub-object�s inverse concatLTs
		float[] fPtrCopy = new float[] {fPtr[0], fPtr[1]};
		//fPtr is in the world space, calculate the corresponding point in the local space of HierObj
		inverseConcatLTs.transformPoint(fPtrCopy, fPtrCopy);


		int px = (int)fPtrCopy[0]; //pointer location relative to
		int py = (int)fPtrCopy[1]; //local origin
		int s = this.getSize();
		if ( (px >= -s/2) && (px <= + s/2) && (py >= -s/2) && (py <= +s/2))
		return true; else return false;
	}
	
	/**
	 * Call the original move if health > 0.
	 */
	@Override
	public void move(float winLeft, float winRight, float winTop, float winBottom, int elapsedTime) {
		if (this.health > 0)
			super.move(winLeft, winRight, winTop, winBottom, elapsedTime);
	}

}
