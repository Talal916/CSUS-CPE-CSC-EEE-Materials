package com.mycompany.a4.GameObjects;

import java.util.Random;

import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;
import com.mycompany.a4.GameWorld;

/**
 * <h1> SpaceShip </h1>
 * Main Role Character with color cannot be changed after initialized.
 * The character size can be changed by user thru expandDoor() and contractDoor().
 * Implements Singleton Pattern 
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class SpaceShip extends Rescuer {
	
	private static SpaceShip theSpaceShip;
	Point lowerLeftInLocalSpace;
	private SpaceShip() {};
	
	/**
	 * Get the current spaceship
	 * @return SpaceShip
	 */
	public static SpaceShip getSpaceship() {
		if (theSpaceShip == null)
			theSpaceShip = new SpaceShip();
		return theSpaceShip;
	}
	
	/**
	 * Initialize the SpaceShip
	 * @param maxX maximum width of the map
	 * @param maxY maximum height of the map
	 * @param size 
	 * @param color
	 */
	public void init(float maxX, float maxY, int color){
		Random r = new Random();
		this.setSize(GameWorld.SPACESHIP_INITIAL_SIZE);
		initTransform();
		int s = this.getSize();
		float ratio = GameWorld.LOCAL_SCALING_FACTOR;
		this.translate((maxX-2*s*ratio) * r.nextFloat() + s*ratio, (maxY-2*s*ratio) * r.nextFloat() + s*ratio);
		this.scale(GameWorld.LOCAL_SCALING_FACTOR, GameWorld.LOCAL_SCALING_FACTOR);
		lowerLeftInLocalSpace = new Point(-this.getSize()/2, -this.getSize()/2);
		super.setColor(color);
		
	} // SpaceShip
	
	/**
	 * Expand door size
	 * @param increment size increased each time
	 * @param maxSize limit of size
	 */
	public void expandDoor(float increment, float maxRatio) {
		if (this.getMyScale().getScaleX() < maxRatio)
			this.scale(increment, increment);
		else {
			this.setMyScale(Transform.IDENTITY());
			this.scale(maxRatio, maxRatio);
		}
	} // expandDoor
	
	/**
	 * Contract door size
	 * @param increment size decreased each time
	 * @param maxSize limit of size
	 */
	public void contractDoor(float decrement, float minRatio) {
		if (this.getMyScale().getScaleX() > minRatio)
			this.scale(decrement, decrement);
		else {
			this.setMyScale(Transform.IDENTITY());
			this.scale(minRatio, minRatio);
		}
	} // contractDoor
	
	@Override // Spaceship color cannot be changed after initialized
	public void setColor(int x) {}
	@Override // Spaceship color cannot be changed after initialized
	public void setColor(int r, int g, int b) {}
	
	/**
	 * return a String with the Game Object's stats.
	 */
	@Override
	public String toString() {
		String parentDesc = super.toString();
		String myDesc1 = "SpaceShip: ";
		return myDesc1 + parentDesc;
	} //toString

	/**
	 *  Draw the Game Object.
	 */
	public void draw(Graphics g, Point pCmpRelPrnt, Point pCmpRelScrn) {
		g.setColor(this.getColor());
		Transform gXform = Transform.makeIdentity();
		g.getTransform(gXform);
		Transform oriGxform = gXform.copy();
		this.LocalTransfrom(gXform, pCmpRelScrn);
		g.setTransform(gXform);
		int s = this.getSize();
		g.fillRect((int)(pCmpRelPrnt.getX() + lowerLeftInLocalSpace.getX()), (int)(pCmpRelPrnt.getY() + lowerLeftInLocalSpace.getY()), s, s);
		g.setTransform(oriGxform);
	}

} //class SpaceShip
