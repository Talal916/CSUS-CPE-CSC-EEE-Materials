package com.mycompany.a4.GameObjects;

import com.codename1.ui.Graphics;
import com.codename1.ui.Transform;

/**
 * <h1>VirtualWindow</h1>
 * Virtual boundary of the local world.
 * @author Chun Yue LEUNG
 * @version 4.0
 */
public class VirtualWindow extends GameObject{
	
	float maxX;
	float maxY;
	
	public VirtualWindow(float maxX, float maxY, int color) {
		initTransform();
		this.setColor(color);
		this.maxX = maxX;
		this.maxY = maxY;

	}
	
	public void draw(Graphics g, Point pCmpRelPrnt, Point pCmpRelScrn) {
		g.setColor(this.getColor());
		Transform gXform = Transform.makeIdentity();
		g.getTransform(gXform);
		Transform oriGxform = gXform.copy();
		this.LocalTransfrom(gXform, pCmpRelScrn);
		g.setTransform(gXform);
		g.drawRect((int)(pCmpRelPrnt.getX()), (int)(pCmpRelPrnt.getY()), (int)maxX, (int)maxY, 1);
		g.setTransform(oriGxform);
	}
	
	@Override
	public String toString() {
		String parentDesc = super.toString();
		String myDesc1 = "Virtual Windows: ";
		return myDesc1 + parentDesc;
	} //toString

}
