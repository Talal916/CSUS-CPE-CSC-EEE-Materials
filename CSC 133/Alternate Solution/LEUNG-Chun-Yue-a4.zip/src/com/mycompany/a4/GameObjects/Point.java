package com.mycompany.a4.GameObjects;

/**
 * <h1>Point</h1>
 * cartesian point with x and y value.
 * @see com.mycompany.a4.GameObjects.a1.GameObject.GameObject
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class Point {
	private float x;
	private float y;
	
	/**
	 * get this Point's x-coordinate
	 * @return x-coordinate
	 */
	public float getX() {
		return x;
	}
	/**
	 * get this Point's y-coordinate
	 * @return y-coordinate
	 */
	public float getY() {
		return y;
	}
	/**
	 * Set this point's x-coordinate
	 * @param x x-coordinate
	 */
	public void setX(float x) {
		this.x = x;
	}
	/**
	 * Set this point's y-coordinate
	 * @param y y-coordinate
	 */
	public void setY(float y) {
		this.y = y;
	}
	/**
	 * Constructor of Point
	 * @param x 
	 * @param y y-coordinate
	 */
	public Point(float x, float y) {
		setX(x);
		setY(y);
	}
	
	/**
	 * Set this point's x and y-coordinate
	 * @param x x-coordinate
	 * @param y y-coordinate
	 */
	public void setXY(float x, float y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * return this Point's x and y values with 1 decimal place
	 */
	@Override
	public String toString() {
		return "loc=" + Math.round(x*10.0)/10.0 + "," + Math.round(y*10.0)/10.0;
	} 
} // class Point
