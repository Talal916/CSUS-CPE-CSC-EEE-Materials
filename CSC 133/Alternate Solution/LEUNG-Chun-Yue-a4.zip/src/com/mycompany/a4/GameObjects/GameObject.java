package com.mycompany.a4.GameObjects;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Transform;

/**
 * <h1>GameObject</h1>
 * abstract class which contains the charater's attributes such as 
 * size, color and location.
 * @author Chun Yue LEUNG
 * @version 2.0
 */
public abstract class GameObject implements IDrawable{

	private int size;
	private int color;
	private Transform myRotation, myTranslation, myScale ;
	
	/**
	 * Get this GameObject's Size
	 * @return size
	 */
	public int getSize() {
		return size;
	}

	/**
	 * return local map x position of current object
	 * @return local map x position of current object
	 */
	public float getX() {
		return getMyTranslation().getTranslateX();
	}
	
	/**
	 * return local map y position of current object
	 * @return local map y position of current object
	 */
	public float getY()
	{
		return getMyTranslation().getTranslateY();
	}

	/**
	 *  Get this GameObject's color in RGB int value
	 * @return color
	 */
	public int getColor() {
		return color;
	}
	
	/**
	 * Set this GameObject's Size
	 * @param s	the Game Object's new size.
	 */
	public void setSize(int s) {
		size = s;
	}

	/**
	 * Set this GameObject's Color by Red, Green, Blue seperate value
	 * @param r red value of RGB
	 * @param g green value of RGB
	 * @param b blue value of RGB
	 */
	public void setColor(int r, int g, int b) {
		color = ColorUtil.rgb(r, g, b);
	}

	/**
	 * Set this GameObject's Color by RGB value
	 * @param c RGB int value
	 */
	public void setColor(int c) {
		color = c;
	}



	/**
	 * return a String with the Game Object's stats.
	 */
	@Override
	public String toString() {
		return "loc=" + (int)this.getX() +"," + (int)this.getY() + " color:[" + ColorUtil.red(color) + "," + ColorUtil.green(color) + ","
				+ ColorUtil.blue(color) + "]" + " size=" + this.getSize();
	}
	
	/**
	 * rotate the current object.
	 * @param degrees
	 */
	public void rotate (float degrees) {
		//pivot point (rotation origin) is (0,0), this means the rotation will be applied about
		//the screen origin
		getMyRotation().rotate ((float)Math.toRadians(degrees),0,0);
	}
	/**
	 * Translate the current object.
	 * @param tx
	 * @param ty
	 */
	public void translate (float tx, float ty) {
		getMyTranslation().translate (tx, ty);
	}
	
	/**
	 * Scale the current object.
	 * @param sx Scale of X.
	 * @param sy Scale of y.
	 */
	public void scale (float sx, float sy) {
		getMyScale().scale (sx, sy);
	}
	
	/**
	 * Reset myScale, myTranslation and myRotation to Identity.
	 */
	public void resetTransform() {
		getMyRotation().setIdentity();
		getMyTranslation().setIdentity();
		getMyScale().setIdentity();
	}
	
	/**
	 * Reset myRotation to Identity.
	 */
	public void resetRotate() {
		getMyRotation().setIdentity();
	}
	
	/**
	 * Reset myTranslation to Identity.
	 */
	public void resetTranslate() {
		getMyTranslation().setIdentity();
	}
	
	/**
	 * Instantiate myScale, myTranslation and myRotation. 
	 */
	public void initTransform() {
		setMyRotation(Transform.makeIdentity());
		setMyTranslation(Transform.makeIdentity());
		setMyScale(Transform.makeIdentity());
	}
	
	/**
	 * Update the Transform object gXfrom in the order of:
	 * Translate -> Rotate -> Scale.
	 * @param gXform 
	 * @param pCmpRelScrn
	 */
	public void LocalTransfrom(Transform gXform, Point pCmpRelScrn) {
		gXform.translate((float)(pCmpRelScrn.getX()),(float)(pCmpRelScrn.getY()));
		gXform.translate(getMyTranslation().getTranslateX(), getMyTranslation().getTranslateY());
		gXform.concatenate(getMyRotation());
		gXform.scale(getMyScale().getScaleX(), getMyScale().getScaleY());
		gXform.translate((float)(-pCmpRelScrn.getX()),(float)(-pCmpRelScrn.getY()));
	}

	/**
	 * 
	 * @return
	 */
	public Transform getMyTranslation() {
		return myTranslation;
	}

	/**
	 * 
	 * @param myTranslation
	 */
	public void setMyTranslation(Transform myTranslation) {
		this.myTranslation = myTranslation;
	}

	/**
	 * 
	 * @return
	 */
	public Transform getMyRotation() {
		return myRotation;
	}

	/**
	 * 
	 * @param myRotation
	 */
	public void setMyRotation(Transform myRotation) {
		this.myRotation = myRotation;
	}


	/**
	 * 
	 * @return
	 */
	public Transform getMyScale() {
		return myScale;
	}
	
	
	/**
	 * 
	 * @param myScale
	 */
	public void setMyScale(Transform myScale) {
		this.myScale = myScale;
	}
	
	
}
