package com.mycompany.a4;

import com.codename1.ui.Dialog;
import com.codename1.ui.Display;
import com.codename1.ui.Form;

/**
 * <h1>ClosingApp</h1>
 * Shows a Dialog to ask user if he/she want to quit the game.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class ClosingApp extends Form{
	/**
	 * Constructor
	 */
	public ClosingApp() {
		Boolean bOk = Dialog.show("Confirm quit", "Are you sure you want to quit?","Ok", "Cancel");
		if (bOk){
			Display.getInstance().exitApplication();
		}
	}
}
