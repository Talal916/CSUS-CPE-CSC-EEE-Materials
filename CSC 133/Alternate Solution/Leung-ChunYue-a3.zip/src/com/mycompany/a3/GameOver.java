package com.mycompany.a3;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Command;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import com.codename1.ui.Form;
import com.codename1.ui.Label;
import com.codename1.ui.layouts.BoxLayout;
/**
 * <h1>GameOver</h1>
 * Show a Dialog Box to notify user Game Over and his/her score.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class GameOver extends Form{
	public GameOver(Integer score) {
		Container infoBox = new Container(new BoxLayout(BoxLayout.Y_AXIS));
		
		Label t = new Label(">       Total Score      <");
		t.getAllStyles().setAlignment(CENTER);
		t.getAllStyles().setFgColor(ColorUtil.BLUE);
		t.getAllStyles().setPadding(0, 0, 5, 5);
		t.getAllStyles().setTextDecoration(BASELINE);
	
		Label s = new Label(score.toString());
		s.getAllStyles().setAlignment(CENTER);
		s.getAllStyles().setFgColor(ColorUtil.BLACK);
		s.getAllStyles().setPadding(5, 5, 5, 5);
		
		infoBox.add(t).add(s);
		Dialog.show("GAME OVER", infoBox ,new Command("OK") {});
	}
}
