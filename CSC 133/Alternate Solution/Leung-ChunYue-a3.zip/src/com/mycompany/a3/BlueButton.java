package com.mycompany.a3;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Button;
/**
 * <h1>BlueButton</h1>
 * Button with blue background and whit fonts.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class BlueButton extends Button {
	/**
	 * Constructor
	 */
	public BlueButton() {
		this.getAllStyles().setBgColor(ColorUtil.BLUE);
		this.getAllStyles().setFgColor(ColorUtil.WHITE);
		this.getPressedStyle().setBgColor(ColorUtil.WHITE);
		this.getPressedStyle().setFgColor(ColorUtil.BLUE);
		this.getAllStyles().setPadding(5, 5, 3, 3);
		this.getAllStyles().setMargin(1, 1, 1, 1);	
		this.getAllStyles().setBgTransparency(255);
		this.getDisabledStyle().setBgColor(ColorUtil.GRAY);
		this.getDisabledStyle().setFgColor(ColorUtil.LTGRAY);
	}
	
}
