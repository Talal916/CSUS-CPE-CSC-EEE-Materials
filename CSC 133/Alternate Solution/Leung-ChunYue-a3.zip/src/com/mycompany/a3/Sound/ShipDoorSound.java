package com.mycompany.a3.Sound;

import java.io.InputStream;

import com.codename1.media.Media;
import com.codename1.media.MediaManager;
import com.codename1.ui.Display;

public class ShipDoorSound {
	private static ShipDoorSound mySound;
	private static Media m;
	private ShipDoorSound() {}
	/**
	 * Initialize the Sound. 
	 * @param fileName sound file name
	 */
	public void init(String fileName) {
		
		try{
		InputStream is = Display.getInstance().getResourceAsStream(getClass(),"/"+fileName);
		m = MediaManager.createMedia(is, "audio/wav");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	/**
	 * Return the current created Sound.
	 * @return
	 */
	public static ShipDoorSound getSound() {
		if (mySound == null)
			mySound = new ShipDoorSound();
		return mySound;
	}
	
	/**
	 * Play the Sound.
	 */
	public void play() {
		if (m == null)
			return;
		m.setTime(0);
		m.play();
	}
}
