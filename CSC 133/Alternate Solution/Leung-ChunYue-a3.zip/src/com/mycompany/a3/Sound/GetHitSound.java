package com.mycompany.a3.Sound;

import java.io.InputStream;

import com.codename1.media.Media;
import com.codename1.media.MediaManager;
import com.codename1.ui.Display;

public class GetHitSound {
	private static GetHitSound mySound;
	private static Media m;
	private GetHitSound() {}
	/**
	 * Initialize the Sound. 
	 * @param fileName sound file name
	 */
	public void init(String fileName) {
		
		try{
		InputStream is = Display.getInstance().getResourceAsStream(getClass(),"/"+fileName);
		m = MediaManager.createMedia(is, "audio/wav");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	/**
	 * Return the current Sound.
	 * @return
	 */
	public static GetHitSound getSound() {
		if (mySound == null)
			mySound = new GetHitSound();
		return mySound;
	}
	/**
	 * Play the sound.
	 */
	public void play() {
		if (m == null)
			return;
		m.setTime(0);
		m.play();
	}
}
