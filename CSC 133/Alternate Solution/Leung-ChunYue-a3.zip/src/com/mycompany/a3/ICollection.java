package com.mycompany.a3;

import java.util.Iterator;

import com.mycompany.a3.GameObjects.GameObject;

public interface ICollection {
	/**
	 * Add GameObject into the Collection.
	 * @param object
	 * @return
	 */
	public boolean add(GameObject object);
	/**
	 * get size of the collection.
	 */
	public int size();
	/**
	 * Get GameObject at position t.
	 * @param t
	 * @return the GameObject at position t.
	 */
	public GameObject elementAt(int t);
	/**
	 * return if the Collection is empty.
	 */
	public boolean isEmpty();
	/**
	 *  Get GameObject Collection Iterator.
	 */
	public Iterator<GameObject> iterator();
}
