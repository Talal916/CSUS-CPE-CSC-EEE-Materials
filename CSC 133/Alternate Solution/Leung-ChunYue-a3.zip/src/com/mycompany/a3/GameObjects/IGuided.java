package com.mycompany.a3.GameObjects;
/**
 * <h1>IGuided</h1>
 * Interface for movement's behavior controlled by player.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public interface IGuided {
	/**
	 * Move left.
	 * @param distance
	 */
	public void moveLeft(int distance);
	/**
	 * Move right.
	 * @param distance
	 */
	public void moveRight(int distance);
	/**
	 * Move Up.
	 * @param distance
	 */
	public void moveUp(int distance);
	/**
	 * Move down.
	 * @param distance
	 */
	public void moveDown(int distance);
	/**
	 * Jump to another GameObject's location.
	 * @param target
	 */
	public void JumpToLocation(GameObject target);
}

