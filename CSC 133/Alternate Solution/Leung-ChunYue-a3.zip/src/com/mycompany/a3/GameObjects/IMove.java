package com.mycompany.a3.GameObjects;

/**
 * <h1>IMove</h1>
 * Interface for move behavior.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public interface IMove {
	/**
	 * Define the move behavior of an object. 
	 * @param xMax width of the container
	 * @param yMax height of the container
	 * @param elapsedTime 
	 */
	public void move(double xMax, double yMax, int elapsedTime);
}
