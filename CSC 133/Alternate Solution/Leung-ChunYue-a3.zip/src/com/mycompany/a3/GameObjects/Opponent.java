package com.mycompany.a3.GameObjects;

import java.util.Random;
import java.util.Vector;

import com.mycompany.a3.GameWorld;

/**
 * <h1>Opponent</h1>
 * In addition to contain GameObject's attributes, it also contains speed and direction.
 * Direction is the heading direction of an Opponent. 
 * Moreover, it has an move's behavior.
 * @see com.mycompany.a2.GameObject.GameObject
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public abstract class Opponent extends GameObject implements IMove, ICollider{

	private int speed;
	private int direction;
	private Vector<ICollider> CollisionList;
	
	/**
	 * Set random size of this Opponent between minimum and maximum size (inclusive)
	 * @param min minimum size of this Opponent
	 * @param max maximum size of this Opponent
	 */
	public void setRandomSize(int min, int max) { 
		if (getSize() == 0) {
			Random r = new Random();
			super.setSize(min + r.nextInt(max-min+1));
		}
	} 
	
	/**
	 * get this Opponent's speed
	 * @return speed
	 */
	public int getSpeed() {
		return speed;
	} 
	
	/**
	 * get this Opponent's direction
	 * @return direction
	 */
	public int getDirection() {
		return direction;
	} 
	
	/**
	 * set this Opponent's direction in degree with range between 0 to 359, adjust back to the range if the value out of range 
	 * @param d
	 */
	public void setDirection(int d) {
		if (d < 0)
			d += 360;
		if (d >= 360)
			d -= 360;
		direction = d;
	} 
	
	/**
	 * set this Opponent's speed
	 * @param s
	 */
	public void setSpeed(int s) {
		speed = s;
	} 
	
	/**
	 * return a String with the Game Object's stats.
	 */
	@Override
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " speed=" + speed + " dir=" + direction;
		return parentDesc + myDesc;
	} //toString
	
	/**
	 * @see com.mycompany.a3.GameObject.IMove#move()
	 * Move this Opponent subject to its speed and direction. If it hit the boundary, 
	 * its direction will be changed according to the reflection angle. After each move, the direction
	 * will be sightly changed random so that this Opponent does not move as a straight line.
	 */
	public void move(double maxX, double maxY, int elapsedTime) {
		double theta = Math.toRadians(this.getDirection());
		double newX = Math.sin(theta) * getSpeed() * (double)elapsedTime/1000 + getLocation().getX();
		double newY = Math.cos(theta) * getSpeed() * (double)elapsedTime/1000 + getLocation().getY();
		setLocation(newX, newY);

		// rebound to direction based  when hit the boundary
			int s = this.getSize();
			double x = this.getLocation().getX();
			double y = this.getLocation().getY();
			int reboundOffset = s/8;
			if (x-s/2 <= 0) {
				this.setDirection(-getDirection());
				this.setLocation(x+reboundOffset, y);
			}
			else if (x+s/2 >= maxX) {
				this.setDirection(-getDirection());
				this.setLocation(x-reboundOffset, y);
			}
			else if (y-s/2 <= 0) {
				this.setDirection(180 - getDirection());
				this.setLocation(x, y+reboundOffset);
			}
			else if (y+s/2 >= maxY) {
				this.setDirection(180 - getDirection());
				this.setLocation(x, y-reboundOffset);
			}
			else {
				Random r = new Random();
				this.setDirection(getDirection() -5 + r.nextInt(11));
			}

	} //move
	
	/**
	 * Return true if:
	 * Two Aliens collides or 
	 * An Alien and a Astronaut collides
	 */
	public boolean collidesWith(ICollider that) {
	//	if (this instanceof Astronaut && otherObject instanceof Astronaut)
	//		return false;
		double thisX = this.getLocation().getX();
		double thisY = this.getLocation().getY();
		int thisS = this.getSize()/2;
		double thatX = that.getLocation().getX();
		double thatY = that.getLocation().getY();
		int thatS = that.getSize()/2;
		if (thisX+thisS < thatX-thatS || thisX-thisS > thatX+thatS ||
			thisY+thisS < thatY-thatS || thisY-thisS > thatY+thatS)
			return false;
		else return true;
				
	}
	/**
	 * Add the two ICollider to each other's Collider's list.
	 */
	public void handleCollision(ICollider that, GameWorld gw) {
	//	System.out.println(this.getClass() + " " +otherObject.getClass());
		this.addToList(that);
		that.addToList(this);
		if (this instanceof Alien && that instanceof Alien && gw.getNumOfAlienLeft() < GameWorld.ALIEN_MAX_NUM) {
			gw.makeNewAlien((Alien)this, (Alien)that);
		//	((Alien)this).setCounter(GameWorld.NEW_ALIEN_THERSHOLD_FRAME);
		//	((Alien)that).setCounter(GameWorld.NEW_ALIEN_THERSHOLD_FRAME);
		}
		else if (this instanceof Astronaut && that instanceof Astronaut) {
			// do nothing now
		}
		else if(this instanceof Astronaut)
			gw.fight((Astronaut)this);
		else if(that instanceof Astronaut)
			gw.fight((Astronaut)that);
	}
	/**
	 * Add the otherObject to the Collision List.
	 */
	public void addToList(ICollider otherObject) {
		CollisionList.add(otherObject);
	}
	/**
	 * remove the otherObject from the Collision List.
	 */
	public void removeFromList(ICollider otherObject) {
		CollisionList.remove(otherObject);
	}
	/**
	 * Return true if the otherObject is in the Collision List.
	 */
	public boolean containInList(ICollider otherObject) {
		return CollisionList.contains(otherObject);
	}
	/**
	 * Initialize the Collision List.
	 */
	public void initCollisionList() {
		CollisionList = new Vector<ICollider>();
	}

} // class Opponent
