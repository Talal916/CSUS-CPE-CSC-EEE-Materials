package com.mycompany.a3.GameObjects;

import com.codename1.charts.util.ColorUtil;

/**
 * <h1>GameObject</h1>
 * abstract class which contains the charater's attributes such as 
 * size, color and location.
 * @author Chun Yue LEUNG
 * @version 2.0
 */
public abstract class GameObject implements IDrawable{

	private int size;
	private Point location;
	private int color;
	
	/**
	 * Get this GameObject's Size
	 * @return size
	 */
	public int getSize() {
		return size;
	}

	/**
	 *  Get this GameObject's location
	 * @return Point
	 */
	public Point getLocation() {
		return location;
	}

	/**
	 *  Get this GameObject's color in RGB int value
	 * @return color
	 */
	public int getColor() {
		return color;
	}
	
	/**
	 * Set this GameObject's Size
	 * @param s	the Game Object's new size.
	 */
	public void setSize(int s) {
		size = s;
	}

	/**
	 * Set this GameObject's Color by Red, Green, Blue seperate value
	 * @param r red value of RGB
	 * @param g green value of RGB
	 * @param b blue value of RGB
	 */
	public void setColor(int r, int g, int b) {
		color = ColorUtil.rgb(r, g, b);
	}

	/**
	 * Set this GameObject's Color by RGB value
	 * @param c RGB int value
	 */
	public void setColor(int c) {
		color = c;
	}

	/**
	 * Set this GameObject's coordinate, note that left-bottom is (0.0, 0.0) 
	 * @param x x-coordinate
	 * @param y y-coordinate
	 */
	public void setLocation(double x, double y) {
		if (location == null)
			location = new Point(x, y);
		else location.setXY(x, y);
	}

	/**
	 * return a String with the Game Object's stats.
	 */
	@Override
	public String toString() {
		return this.getLocation() + " color:[" + ColorUtil.red(color) + "," + ColorUtil.green(color) + ","
				+ ColorUtil.blue(color) + "]" + " size=" + this.getSize();
	}
}
