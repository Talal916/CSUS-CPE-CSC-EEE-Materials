package com.mycompany.a3.GameObjects;

import com.codename1.ui.Graphics;
/**
 * <h1>IMove</h1>
 * Interface for move behavior.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public interface IDrawable {
	/**
	 * Draw this object.
	 * @param g
	 * @param pCmpRelPrnt Point relative 
	 */
	public void draw(Graphics g, Point pCmpRelPrnt);
}
