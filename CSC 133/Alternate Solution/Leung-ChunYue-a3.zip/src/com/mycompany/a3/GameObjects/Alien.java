package com.mycompany.a3.GameObjects;

import java.util.Random;

import com.codename1.ui.Graphics;
import com.mycompany.a3.GameWorld;

/**
 * <h1>Alien</h1>
 * An Game Character with fixed color, fixed size and fixed speed after initialized.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class Alien extends Opponent{
	
	private int counter;

	/**
	 * Initialize an Alien to random location, random size.
	 * Color and speed are also needed to be set.
	 * @param maxX maximum possible x
	 * @param maxY maximum possible y
	 * @param minSize minimum possible size
	 * @param maxSzie maximum possible size
	 * @param color RGB int value
	 * @param speed speed
	 */
	public Alien(double maxX, double maxY, int minSize, int maxSzie, int color, int speed) {
		super.setColor(color);
		Random r = new Random();
		super.setRandomSize(minSize, maxSzie);
		double x = (maxX-this.getSize()) * r.nextDouble() + this.getSize();
		double y = (maxY-this.getSize()) * r.nextDouble() + this.getSize();
		this.setLocation(x, y);
		this.setDirection(r.nextInt(360));
		super.setSpeed(speed);
		initCollisionList();
		this.setCounter(GameWorld.NEW_ALIEN_THERSHOLD_FRAME);
	}
	
	/**
	 * The color of an Alien cannot be changed after initialized
	 */
	@Override // Alien's color cannot be changed after initialized
	public void setColor(int x) {}
	
	/**
	 * The color of an Alien cannot be changed after initialized
	 */
	@Override // Alien's color cannot be changed after initialized
	public void setColor(int r, int g, int b) {}
	
	/**
	 * The speed of an Alien cannot be changed after initialized
	 */
	@Override
	public void setSpeed(int s) {}
	
	/**
	 * The size of an Alien cannot be changed after initialized
	 */
	@Override
	public void setSize(int s) {}
	
	/**
	 * The size of an Alien cannot be changed after initialized
	 */
	@Override
	public void setRandomSize(int min, int max) {}
	
	/**
	 * return a String with the Game Object's stats.
	 */
	@Override
	public String toString(){
		String parentDesc = super.toString();
		String myDesc1 = "Alien: ";
		return myDesc1 + parentDesc;
	}
	
	/**
	 * Draw this object.
	 */
	public void draw(Graphics g, Point pCmpRelPrnt) {
	//	if (this.isNew())
	//		g.setColor(GameWorld.ALIEN_INITIAL_COLOR);
	//	else
			g.setColor(this.getColor());
		int xLoc = (int) (pCmpRelPrnt.getX()+ this.getLocation().getX());// shape location relative
		int yLoc = (int) (pCmpRelPrnt.getY()+ this.getLocation().getY());// to parent�s origin
		int s = this.getSize();
		g.fillArc(xLoc-s/2, yLoc-s/2, s, s, 0, 360);
		if (counter > 0)
			counter--;
	}
	
	/**
	 * Return true if the Alien is newly created.
	 * @return
	 */
	public boolean isNew() {
		return counter != 0;
	}
	/**
	 * See the Counter of "new" status of the Alien.
	 * @param n
	 */
	public void setCounter(int n) {
		counter = n;
	}
	
}
