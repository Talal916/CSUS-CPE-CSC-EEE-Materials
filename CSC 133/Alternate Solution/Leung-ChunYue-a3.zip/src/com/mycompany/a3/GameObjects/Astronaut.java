package com.mycompany.a3.GameObjects;

import java.util.Random;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Graphics;
import com.mycompany.a3.GameWorld;

/**
 * <h1>Astronaut</h1>
 * An Game Character with additional attributes such as health and speedConstant.
 * The speed of an Astronaut is equal to health * speedConstant.
 * If an Astronaut got attacked, it health value will be minus by one
 * and its color will be faded.
 * @author Chun Yue LEUNG
 * @version 2.0
 */
public class Astronaut extends Opponent implements ISelectable{

	private int health;
	private int speedConstant;
	private boolean isSelected;
	
	/**
	 * Get this Astronaut's health
	 * @return health
	 */
	public int getHealth() {
		return health;
	}
	
	/**
	 * Set this Astronaut's health
	 * @param h health
	 */
	public void setHealth(int h) {
		health = h;
	}
	
	/**
	 * Get the this Astronaut's speed constant
	 * @return speedConstant
	 */
	public int getSpeedConstant() {
		return speedConstant;
	}
	
	/**
	 * the size of an Astronaut cannot be changed after initialized
	 */
	@Override 
	public void setSize(int x) {} 
	
	/**
	 * the size of an Astronaut cannot be changed after initialized
	 */
	@Override
	public void setRandomSize(int min, int max) {}
	
	/**
	 * return a String with the Game Object's stats.
	 */
	@Override
	public String toString() {
		String parentDesc = super.toString();
		String myDesc1 = "Astronaut: ";
		String myDesc2 = " health=" + health;
		return myDesc1 + parentDesc + myDesc2;
		
	}
	
	/**
	 * Initialize an Astronaut to random location, random size, random direction.
	 * Health, color and speed constant are also needed to be set
	 * @param maxX maximum possible x
	 * @param maxY maximum possible y
	 * @param minSize minimum possible size
	 * @param maxSzie maximum possible size
	 * @param color RGB int value
	 * @param health 
	 * @param speedConstant
	 */
	public Astronaut(double maxX, double maxY, int minSize, int maxSzie, int color, int health, int speedConstant) {
		Random r = new Random();
		super.setRandomSize(minSize, maxSzie);
		double x = (maxX-this.getSize()) * r.nextDouble() + this.getSize();
		double y = (maxY-this.getSize()) * r.nextDouble() + this.getSize();
		this.setLocation(x, y);
		setHealth(health);
		setColor(color);
		this.setDirection(r.nextInt(360));
		this.speedConstant = speedConstant;
		this.setSpeed(health * speedConstant);
		initCollisionList();
	}

	/**
	 * This Astronaut's got hit, if its health is greater than zero, it will minus by one and its color
	 * will be faded by one gradient. no change if this Astronaut's's health is zero.
	 */
	public void getHit() {
		if (health > 0) {
			health--;
			int c = this.getColor();
			this.setColor(ColorUtil.red(c), ColorUtil.green(c)+40, ColorUtil.blue(c)+40);
			this.setSpeed(health * speedConstant);
		}
	}
	/**
	 * Heal the Astronaut to full health.
	 */
	public void heal() {
		this.setHealth(GameWorld.ASTRONAUT_INITIAL_HEALTH);
		this.setSpeed(health * speedConstant);
		this.setColor(GameWorld.ASTRONAUT_INITIAL_COLOR);
	}

	/**
	 *  Draw the Game Object.
	 */
	public void draw(Graphics g, Point pCmpRelPrnt) {
		g.setColor(this.getColor());
		int xLoc = (int) (pCmpRelPrnt.getX()+ this.getLocation().getX());// shape location relative
		int yLoc = (int) (pCmpRelPrnt.getY()+ this.getLocation().getY());// to parent�s origin
		int s = this.getSize();
		int [] traingleX = {xLoc-s/2, xLoc+s/2, xLoc};
		int [] traingleY = {yLoc-s/2, yLoc-s/2, yLoc+s/2};
		if(isSelected()) {
			g.drawPolygon(traingleX, traingleY, 3);
		}
		else
			g.fillPolygon(traingleX, traingleY, 3);
	}

	/**
	 * Set the Astronaut to be selected.
	 */
	public void setSelected(boolean yesNo) {
		isSelected = yesNo;
	}

	/**
	 * Return true if the Astronaut is selected.
	 */
	public boolean isSelected() {
		return isSelected;
	}
	
	/**
	 * Return true if the pointer within the Astronaut's boundary.
	 */
	public boolean contains(Point pPtrRelPrnt, Point pCmpRelPrnt) {
		int px = (int) pPtrRelPrnt.getX(); // pointer location relative to
		int py = (int) pPtrRelPrnt.getY(); // parent�s origin
		int xLoc = (int) (pCmpRelPrnt.getX()+ this.getLocation().getX());// shape location relative
		int yLoc = (int) (pCmpRelPrnt.getY()+ this.getLocation().getY());// to parent�s origin
		int s = this.getSize();
		if ( (px >= xLoc-s/2) && (px <= xLoc+ s/2) && (py >= yLoc-s/2) && (py <= yLoc+s/2))
		return true; else return false;
	}

}
