package com.mycompany.a3.GameObjects;

import java.util.Random;

import com.codename1.ui.Graphics;

/**
 * <h1> SpaceShip </h1>
 * Main Role Character with color cannot be changed after initialized.
 * The character size can be changed by user thru expandDoor() and contractDoor().
 * Implements Singleton Pattern 
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class SpaceShip extends Rescuer {
	
	private static SpaceShip theSpaceShip;
	private SpaceShip() {};
	
	/**
	 * Get the current spaceship
	 * @return SpaceShip
	 */
	public static SpaceShip getSpaceship() {
		if (theSpaceShip == null)
			theSpaceShip = new SpaceShip();
		return theSpaceShip;
	}
	
	/**
	 * Initialize the SpaceShip
	 * @param maxX maximum width of the map
	 * @param maxY maximum height of the map
	 * @param size 
	 * @param color
	 */
	public void init(double maxX, double maxY, int size, int color){
		Random r = new Random();
		this.setSize(size);
		this.setLocation((maxX-size) * r.nextDouble() + size, (maxY-size) * r.nextDouble() + size);
		super.setColor(color);
	} // SpaceShip
	
	/**
	 * Expand door size
	 * @param increment size increased each time
	 * @param maxSize limit of size
	 */
	public void expandDoor(int increment, int maxSize) {
		this.setSize(this.getSize() + increment);
		if (this.getSize() > maxSize)
			this.setSize(maxSize);
	} // expandDoor
	
	/**
	 * Contract door size
	 * @param increment size decreased each time
	 * @param maxSize limit of size
	 */
	public void contractDoor(int decrementint, int minSize) {
		this.setSize(this.getSize() - decrementint);
		if (this.getSize() < minSize)
			this.setSize(minSize);
	} // contractDoor
	
	@Override // Spaceship color cannot be changed after initialized
	public void setColor(int x) {}
	@Override // Spaceship color cannot be changed after initialized
	public void setColor(int r, int g, int b) {}
	
	/**
	 * return a String with the Game Object's stats.
	 */
	@Override
	public String toString() {
		String parentDesc = super.toString();
		String myDesc1 = "SpaceShip: ";
		return myDesc1 + parentDesc;
	} //toString

	/**
	 *  Draw the Game Object.
	 */
	public void draw(Graphics g, Point pCmpRelPrnt) {
		g.setColor(this.getColor());
		int xLoc = (int) (pCmpRelPrnt.getX()+ this.getLocation().getX());// shape location relative
		int yLoc = (int) (pCmpRelPrnt.getY()+ this.getLocation().getY());// to parent�s origin
		int s = this.getSize();
		g.fillRect(xLoc-s/2, yLoc-s/2, this.getSize(), this.getSize());
	}

} //class SpaceShip
