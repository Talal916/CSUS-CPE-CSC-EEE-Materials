package com.mycompany.a3.Views;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Label;
/**
 * <h1>BlueLabel</h1>
 * Label with blue fonts.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class BlueLabel extends Label{
	/**
	 * Constructor
	 * @param x words show on button
	 */
	public BlueLabel(String x) {
		super(x);
		this.getAllStyles().setFgColor(ColorUtil.BLUE);
		this.getAllStyles().setMargin(0, 0, 5, 5);
	}

	/**
	 * Constructor
	 */
	public BlueLabel() {
		this.getAllStyles().setFgColor(ColorUtil.BLUE);
	}
}
