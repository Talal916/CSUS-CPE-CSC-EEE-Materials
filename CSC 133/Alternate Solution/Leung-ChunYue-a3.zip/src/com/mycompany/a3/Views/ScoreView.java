package com.mycompany.a3.Views;

import java.util.Observable;
import java.util.Observer;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Component;
import com.codename1.ui.Container;
import com.codename1.ui.layouts.FlowLayout;
import com.codename1.ui.plaf.Border;
import com.mycompany.a3.GameWorld;

/**
 * <h1>ScoreView</h1>
 * Implements Observer Pattern which get updates when there is any change in the game objects.
 * Show the game statistics.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class ScoreView extends Container implements Observer{

	private BlueLabel score;
	private BlueLabel astronautRescused;
	private BlueLabel alienSneakedIn;
	private BlueLabel astronautLeft;
	private BlueLabel alienLeft;
	private BlueLabel sound;
	
	/**
	 * Constructor
	 */
	public ScoreView() {
		this.setLayout(new FlowLayout(Component.CENTER));
		this.getAllStyles().setBgColor(ColorUtil.WHITE);
		this.getAllStyles().setBgTransparency(255);
		getAllStyles().setBorder(Border.createLineBorder(1, ColorUtil.BLACK));
		score = new BlueLabel();
		astronautRescused = new BlueLabel();
		alienSneakedIn = new BlueLabel();
		astronautLeft = new BlueLabel();
		alienLeft = new BlueLabel();
		sound = new BlueLabel();
		this.add(new BlueLabel("Total Score:")).add(score);
		this.add(new BlueLabel("   Astronaut Rescued:")).add(astronautRescused);
		this.add(new BlueLabel(" Alien Sneaked In:")).add(alienSneakedIn);
		this.add(new BlueLabel(" Astronaut Remaining:")).add(astronautLeft);
		this.add(new BlueLabel(" Alien Remaining:")).add(alienLeft);
		this.add(new BlueLabel(" Sound:")).add(sound);
	}
	
	/**
	 *  Show the updated Game Statistics 
	 */
	public void update(Observable observable, Object data) {
		score.setText(((GameWorld)observable).getScore().toString());
		astronautRescused.setText(((GameWorld)observable).getNumOfAstronautIn().toString());
		alienSneakedIn.setText(((GameWorld)observable).getNumOfAlienIn().toString());
		astronautLeft.setText(((GameWorld)observable).getNumOfAstronautLeft().toString());
		alienLeft.setText(((GameWorld)observable).getNumOfAlienLeft().toString());
		setSoundOnOffText(((GameWorld)observable).isSoundOn());
		repaint();
	}
	
	/**
	 * Set the display of the Sound Status (On/Off)
	 * @param on
	 */
	private void setSoundOnOffText(boolean on){
		if (on)
			sound.setText("ON");
		else
			sound.setText("OFF");
	}
}
