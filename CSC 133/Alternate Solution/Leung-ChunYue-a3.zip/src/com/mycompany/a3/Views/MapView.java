package com.mycompany.a3.Views;

import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;

import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.Container;
import com.codename1.ui.Graphics;
import com.codename1.ui.plaf.Border;
import com.mycompany.a3.GameWorld;
import com.mycompany.a3.GameObjects.GameObject;
import com.mycompany.a3.GameObjects.ISelectable;
import com.mycompany.a3.GameObjects.Point;

/**
 * <h1>MapView</h1>
 * Implements Observer Pattern which get updates when there is any change in the game objects.
 * Shows the game Objects' status (currently show on Console)
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class MapView extends Container implements Observer{
	
	private GameWorld gw;
	private boolean isSelectedSth; 
	
	/**
	 * Constructor
	 */
	public MapView(GameWorld gw) {
		this.getAllStyles().setBgTransparency(255);
		getAllStyles().setBorder(Border.createLineBorder(2, ColorUtil.BLACK));
		this.gw = gw;
	}
	
	/**
	 * Paint the map when the GameWorld's time tick.
	 */
	public void update(Observable observable, Object data) {
		((GameWorld)observable).showMap();
		this.repaint();
	}
	/**
	 * Call the draw method of every GameObject in the map.
	 */
	@Override
	public void paint(Graphics g) {
		super.paint(g);
		Point pCmpRelPrnt = new Point(getX(), getY());
	//	mainRole.draw(g, pCmpRelPrnt);
		Iterator<GameObject> it = gw.getGameObjectIterator();
		while (it.hasNext()) {
			GameObject o = it.next();
			o.draw(g, pCmpRelPrnt);
			if (!gw.isPause() && isSelectedSth) {
					if (o instanceof ISelectable && ((ISelectable)o).isSelected()) {
						((ISelectable)o).setSelected(false);
						isSelectedSth = false;
					}
			}
		}
	}
	/**
	 * Select the Astronaut if the user click the Astronaut.
	 */
	@Override
	public void pointerPressed(int x, int y) {
		if (gw.isPause()) {
			x = x - getParent().getAbsoluteX();
			y = y - getParent().getAbsoluteY();
			Point pPtrRelPrnt = new Point(x, y);
			Point pCmpRelPrnt = new Point(getX(), getY());
			Iterator<GameObject>it = gw.getGameObjectIterator();
			while (it.hasNext()) {
				GameObject o = it.next();
				if (o instanceof ISelectable) {
					if (((ISelectable)o).contains(pPtrRelPrnt, pCmpRelPrnt)) {
						((ISelectable)o).setSelected(true);
						isSelectedSth = true;
					}
					else
						((ISelectable)o).setSelected(false);
				}	
			}
			this.repaint();
		}
	}
}
