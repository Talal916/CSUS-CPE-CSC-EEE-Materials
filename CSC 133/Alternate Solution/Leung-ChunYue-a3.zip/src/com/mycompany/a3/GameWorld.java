package com.mycompany.a3;

import java.util.Iterator;
import java.util.Observable;
import java.util.Observer;
import java.util.Random;
import java.util.Vector;

import com.codename1.charts.util.ColorUtil;
import com.mycompany.a3.GameObjects.*;
import com.mycompany.a3.Sound.BGSound;
import com.mycompany.a3.Sound.GetHitSound;
import com.mycompany.a3.Sound.NewAlienSound;
import com.mycompany.a3.Sound.ShipDoorSound;

/**
 * <h1>GameWorld</h1>
 * Implements Observer Pattern which will updates the Views when there is any change in the game objects.
 * Holds a collection of game objects and other state variables such as score and how many different Opponents removed and left.
 * @author Chun Yue LEUNG
 * @version 3.0
 */

public class GameWorld extends Observable{
	private GameObjectCollection go;
	private SpaceShip mainRole;
	private Integer numOfAlienIn;
	private Integer numOfAlienLeft; 
	private Integer numOfAstronautIn; 
	private Integer numOfAstronautLeft;
	private Integer score;
	private boolean soundOn;
	private boolean isPause;
	private boolean isGamOver;
	private BGSound bgSound;
	private GetHitSound getHitSound;
	private NewAlienSound newAlienSound;
	private ShipDoorSound shipDoorSound;
	
	private double xMax = 0;
	private double yMax = 0;
	public static final int OPPENENT_MIN_SIZE = 40;
	public static final int OPPENENT_MAX_SIZE = 60;
	public static final int OPPENENT_SPEED_CONSTANT = 50;
	
	public static final int ASTRONAUT_INITIAL_HEALTH = 5;
	public static final int ASTRONAUT_INITIAL_COLOR = ColorUtil.rgb(255, 0, 0);
	public static final int ASTRONAUT_INITIAL_NUM = 4;
	public static final int ASTRONAUT_MAX_SCORE = 10;

	public static final int ALIEN_INITIAL_COLOR = ColorUtil.BLUE;
	public static final int ALIEN_SPEED_MULTIPLIER = 5;
	public static final int ALIEN_INITIAL_NUM = 3;
	public static final int ALIEN_MAX_NUM = 30;
	public static final int NEW_ALIEN_THERSHOLD_FRAME = 50;
	public static final int ALIEN_PENALTY = 10;
	
	public static final int RESCUER_MOVE_INCREMENT = 20;
	
	public static final int SPACESHIP_INITIAL_SIZE = 100;
	public static final int SPACESHIP_MIN_SIZE = 50;
	public static final int SPACESHIP_MAX_SIZE = 1024;
	public static final int SPACESHIP_SIZE_INCREMENT = 50;
	public static final int SPACESHIP_INITIAL_COLOR = ColorUtil.BLACK;	
	public static final int ELAPSEDTIME = 20;
	
	/**
	 * Initialize this GameWorld. SpaceShip, Aliens, Astronauts will be placed randomly within the fixed size game world.
	 */
	public void init() {
		Random r = new Random();
		go = new GameObjectCollection();
		mainRole = SpaceShip.getSpaceship();
		mainRole.init(xMax*r.nextDouble(), yMax*r.nextDouble(), SPACESHIP_INITIAL_SIZE, SPACESHIP_INITIAL_COLOR);
		go.add(mainRole);
		for (int i = 0; i< ALIEN_INITIAL_NUM; i++) 
			go.add(new Alien(xMax*r.nextDouble(), yMax*r.nextDouble(), OPPENENT_MIN_SIZE, OPPENENT_MAX_SIZE, ALIEN_INITIAL_COLOR , ALIEN_SPEED_MULTIPLIER * OPPENENT_SPEED_CONSTANT));	
		for (int i = 0; i< ASTRONAUT_INITIAL_NUM; i++)
			go.add(new Astronaut(xMax*r.nextDouble(), yMax*r.nextDouble(), OPPENENT_MIN_SIZE, OPPENENT_MAX_SIZE, ASTRONAUT_INITIAL_COLOR , ASTRONAUT_INITIAL_HEALTH, OPPENENT_SPEED_CONSTANT));
		numOfAlienIn = 0;
		numOfAlienLeft = ALIEN_INITIAL_NUM;
		numOfAstronautIn = 0;
		numOfAstronautLeft = ASTRONAUT_INITIAL_NUM;
		score = 0;
		soundOn = false;
//		System.out.println("maxX:" + xMax + "maxY:" + yMax);
		bgSound = BGSound.getSound();
		bgSound.init("bg2.wav");
		getHitSound = GetHitSound.getSound();
		getHitSound.init("getHit2.mp3");
		newAlienSound = NewAlienSound.getSound();
		newAlienSound.init("newAlien.wav");
		shipDoorSound = ShipDoorSound.getSound();
		shipDoorSound.init("openDoor.wav");
	}
	
	/**
	 * Overriding the addObserver method so that the ScoreView object will show the game status before users' actions.
	 * @param observer Observer to be registered. 
	 */
	@ Override
	public void addObserver(Observer observer) {
		super.addObserver(observer);
		this.setChanged();
		this.notifyObservers();
	}
	
	public SpaceShip getSpaceShip(){
		return mainRole;
	}
	
	
	public Iterator<GameObject> getGameObjectIterator(){
		return go.iterator();
	}
	
	/**
	 * Set the maximum width of the map.
	 * @param xMax maximum width of the map.
	 */
	public void SetxMax(int xMax) {
		this.xMax = xMax;
	}
	
	/**
	 * Set the maximum height of the map.
	 * @param yMax maximum height of the map.
	 */
	public void SetyMax(int yMax) {
		this.yMax = yMax;
	}
		
	/**
	 * Get the number of alien sneaked in.
	 * @return number of alien sneaked in.
	 */
	public Integer getNumOfAlienIn() {
		return numOfAlienIn;
	}
	
	/**
	 * Set the number of alien sneaked in.
	 * @param numOfAlienIn number of alien sneaked in.
	 */
	public void setNumOfAlienIn(int numOfAlienIn) {
		this.numOfAlienIn = numOfAlienIn;
	}
	
	/**
	 * Get the number of alien left on the map.
	 * @return number of alien left on the map.
	 */
	public Integer getNumOfAlienLeft() {
		return numOfAlienLeft;
	}
	
	/**
	 * Set the number of alien left on the map.
	 * @param numOfAlienLeft number of alien left on the map.
	 */
	public void setNumOfAlienLeft(int numOfAlienLeft) {
		this.numOfAlienLeft = numOfAlienLeft;
	}
	
	/**
	 * Get the number of astronauts rescued.
	 * @return the number of astronauts rescued.
	 */
	public Integer getNumOfAstronautIn() {
		return numOfAstronautIn;
	}
	
	/**
	 * Set the number of astronauts rescued.
	 * @param numOfAstronautIn number of astronauts rescued.
	 */
	public void setNumOfAstronautIn(int numOfAstronautIn) {
		this.numOfAstronautIn = numOfAstronautIn;
	}
	
	/**
	 * Get the number of astronauts left on the map.
	 * @return number of astronauts left on the map.
	 */
	public Integer getNumOfAstronautLeft() {
		return numOfAstronautLeft;
	}
	
	/**
	 * Set the number of astronauts left on the map.
	 * @param numOfAstronautLeft number of astronauts left on the map.
	 */
	public void setNumOfAstronautLeft(int numOfAstronautLeft) {
		this.numOfAstronautLeft = numOfAstronautLeft;
	}
	
	/**
	 * Get the current score.
	 * @return the current score.
	 */
	public Integer getScore() {
		return score;
	}
	
	/**
	 * Set the current score.
	 * @param score current score.
	 */
	public void setScore(int score) {
		this.score = score;
	}
	
	/**
	 * Transfer the Spaceship to an random alien, print error message if there is no alien.
	 */
	public void moveSpaceShipToAlien() {
		if (numOfAlienLeft > 0) {
			Vector<GameObject> randomList = new Vector<GameObject>();
			Iterator<GameObject> it = go.iterator();
			while (it.hasNext()) {
				GameObject x = it.next();
				if (x instanceof Alien)
					randomList.add(x);
			}
			Random r = new Random();
			mainRole.JumpToLocation(randomList.get(r.nextInt(randomList.size())));
			System.out.print("<< MoveToAlien >>\n");
			this.setChanged();
			this.notifyObservers();
		}
		else
			System.out.print("Error, no alien left!\n");
		
	} // moveSpaceShipToAlien
	
	/**
	 * Transfer the spaceship to a location of a randomly selected astronaut.
	 */
	public void moveSpaceShipToAstronaut() {
		if (numOfAstronautLeft > 0) {
			Vector<GameObject> randomList = new Vector<GameObject>();
			Iterator<GameObject> it = go.iterator();
			while (it.hasNext()) {
				GameObject x = it.next();
				if (x instanceof Astronaut)
					randomList.add(x);
			}
			Random r = new Random();
			mainRole.JumpToLocation(randomList.get(r.nextInt(randomList.size())));
			System.out.print("<< MoveToAstronaut >>\n");
			this.setChanged();
			this.notifyObservers();
		} // if
		else {
			System.out.print("Error, no astronaut left!\n");
		} //else
	} //moveSpaceShipToAstronaut
	
	/**
	 * Move the spaceship to the right.
	 */
	public void moveSpaceShipRight() {
		mainRole.moveRight(RESCUER_MOVE_INCREMENT);
		System.out.print("<< Right >>\n");
		this.setChanged();
		this.notifyObservers();
	} //spaceShipToRight
	
	/**
	 * Move the spaceship to the left.
	 */
	public void moveSpaceShipLeft() {
		mainRole.moveLeft(RESCUER_MOVE_INCREMENT);
		System.out.print("<< Left >>\n");
		this.setChanged();
		this.notifyObservers();
	} // spaceShipToLeft
	
	/**
	 * Move the spaceship up.
	 */
	public void moveSpaceShipUp() {
		mainRole.moveUp(RESCUER_MOVE_INCREMENT);
		System.out.print("<< Up >>\n");
		this.setChanged();
		this.notifyObservers();
	} //spaceShipToUp
	
	/**
	 * Move the spaceship down.
	 */
	public void moveSpaceShipDown() {
		mainRole.moveDown(RESCUER_MOVE_INCREMENT);
		System.out.print("<< Down >>\n");
		this.setChanged();
		this.notifyObservers();
	} //spaceShipToDown
	
	/**
	 * Expand the size of the spaceship door
	 */
	public void expandSpaceShipDoor() {
		if (mainRole.getSize() < SPACESHIP_MAX_SIZE) {
			mainRole.expandDoor(SPACESHIP_SIZE_INCREMENT, SPACESHIP_MAX_SIZE);
			System.out.print("<< Expand >>\n");
			this.setChanged();
			this.notifyObservers();
		}
		else
			System.out.print("	Door size is at max.\n");
	} //expandSpaceShipDoor
	
	/**
	 * Contract the size of the spaceship door
	 */
	public void contractSpaceShipDoor() {
		if (mainRole.getSize() > SPACESHIP_MIN_SIZE) {
			mainRole.contractDoor(SPACESHIP_SIZE_INCREMENT, SPACESHIP_MIN_SIZE);
			System.out.print("<< Contract >>\n");
			this.setChanged();
			this.notifyObservers();
		}
		else
			System.out.print("	Door size is at min.\n");
	} //contractSpaceShipDoor
	
	/**
	 * Tell the game world that the �game clock� has ticked. All moving objects are told to update their positions according to their current direction and speed.
	 * Also detecting if there is collisions.
	 */
	public void tickTime() {
		// move the GameOjects.
		Iterator<GameObject> iter = go.iterator();
		while (iter.hasNext()) {
			GameObject m = iter.next();
			if (m instanceof IMove)
				((IMove)m).move(xMax, yMax, GameWorld.ELAPSEDTIME);
		}
		
		// check for collision.
		Iterator<GameObject> iter1 = go.iterator();
		while (iter1.hasNext()) {
			GameObject x = iter1.next();
			if (x instanceof ICollider) {
				Iterator<GameObject> iter2 = go.iterator();
				while (iter2.hasNext()) {
					GameObject y = iter2.next();
					if (y instanceof ICollider && y != x) {
						ICollider xx = (ICollider) x;
						ICollider yy = (ICollider) y;
						if (xx.collidesWith(yy)) {
							if (!xx.containInList(yy) && !(yy.containInList(xx)))
								xx.handleCollision(yy, this);
						}
						else {
							if (xx.containInList(yy)) {
								xx.removeFromList(yy);
								yy.removeFromList(xx);
							}
						}
					}
				}
			}
		}
		
		//check for game over.
		if (numOfAstronautLeft == 0) {
			this.setGamOver(true);
		}
		this.setChanged();
		this.notifyObservers();
	} // tickTime

	// helper's function to check if the Opponents in the SpaceShip's door.
	private static boolean withinDoor(GameObject o, double top, double bottom, double right, double left) {
		Point oMidPt = new Point(o.getLocation().getX(), o.getLocation().getY());
		return oMidPt.getY() <= top && oMidPt.getY()>= bottom && oMidPt.getX()>= left && oMidPt.getX() <= right;
	} 

	/**
	 * Astronaut get hit if his health > 0.
	 * @param x
	 */
	public void fight(Astronaut x) {
		if (x.getHealth() > 0) 
			x.getHit();
		if (soundOn)
			getHitSound.play();
	}
	
	/**
	 * Open the door and update the score according to the types and conditions of 
	 * opponents that are let in to the spaceship as described above in rules of play. This 
	 * causes all of the opponents whose centers are within the boundaries of the bounding 
	 * square of the door to be removed from the game world.
	 */
	public void openSpaceShipDoor() {

		double doorSize = mainRole.getSize();
		double topBound = mainRole.getLocation().getY() + doorSize/2;
		double bottomBound = mainRole.getLocation().getY() - doorSize/2;
		double rightBound = mainRole.getLocation().getX() + doorSize/2;
		double leftBound = mainRole.getLocation().getX() - doorSize/2;
		
		if(this.isSoundOn())
			shipDoorSound.play();
		Iterator<GameObject> it = go.iterator();
		while (it.hasNext()) {
			Object cur = it.next();
			if (cur instanceof Alien) {
				if (withinDoor((GameObject)cur, topBound, bottomBound, rightBound, leftBound)) {
					score -= ALIEN_PENALTY;
					this.numOfAlienIn++;
					this.numOfAlienLeft--;
					it.remove();
				}
			} 
			else if (cur instanceof Astronaut) {
				if (withinDoor((GameObject)cur, topBound, bottomBound, rightBound, leftBound)) {
					int scoreGained = ASTRONAUT_MAX_SCORE - (ASTRONAUT_INITIAL_HEALTH - ((Astronaut)cur).getHealth());
					score += scoreGained;
					this.numOfAstronautIn ++;
					this.numOfAstronautLeft --;
					it.remove();
				} //if
			}
		}
		System.out.print("<< Score >>\n");
		this.setChanged();
		this.notifyObservers();
	} //method openSpaceShipdoor
	
	/**
	 * Create a new Alien when two Aliens Collide. The location of the new Alien is randomly placed around the colliding Aliens.
	 */
	public void makeNewAlien(Alien a, Alien b) {
		if (this.numOfAlienLeft >= GameWorld.ALIEN_MAX_NUM)
			return;
		if (a.isNew() || b.isNew()) // new Alien cannot reproduce.
			return;
		if (isSoundOn())
			newAlienSound.play();
		Random r = new Random();
		Alien oldGuy = (r.nextInt(2)==1)?a:b;
		Alien newGuy = new Alien(xMax*r.nextDouble(), yMax*r.nextDouble(), OPPENENT_MIN_SIZE, OPPENENT_MAX_SIZE, ALIEN_INITIAL_COLOR , ALIEN_SPEED_MULTIPLIER * OPPENENT_SPEED_CONSTANT);
		double x = oldGuy.getLocation().getX() + r.nextInt(4) - 2;
		double y = oldGuy.getLocation().getY() + r.nextInt(4) - 2;
		int s = newGuy.getSize();
		if (x-s < 0)
			x += 2*s;
		if (y-s < 0)
			y += 2*s;
		if (x+s > xMax)
			x -= 2*s;
		if (x+s > yMax)
			y -= 2*s;
		newGuy.setLocation(x, y);
		go.add(newGuy);
		numOfAlienLeft ++;
		a.addToList(newGuy);
		newGuy.addToList(a);
		b.addToList(newGuy);
		newGuy.addToList(b);
		
		this.setChanged();
		this.notifyObservers();
	} // makeNewAlien
	
	/**
	 * print a �map� showing the current world state.
	 * All the attributes of the GameObject will be shown.
	 */
	public void showMap() {
		System.out.println("<< Show Map >>");
		Iterator<GameObject> it = go.iterator();
		while (it.hasNext())
			System.out.println(it.next());
	} // showMap
	
	/**
	 * set the sound on/off status of all sound.
	 * @param soundOn
	 */
	public void setSoundOn(boolean soundOn) {
		this.soundOn = soundOn;
		setBGSoundStatus();
		this.setChanged();
		this.notifyObservers();
	}

	/**
	 * Return true if the Sound is on.
	 * @return
	 */
	public boolean isSoundOn() {
		return soundOn;
	}

	/**
	 * Return true if the Game is pause.
	 * @return
	 */
	public boolean isPause() {
		return isPause;
	}

	/**
	 * Set to be true if the Game is Pause.
	 * @param isPause
	 */
	public void setPause(boolean isPause) {
		this.isPause = isPause;
	}

	/**
	 * Heal the selected Astronaut.
	 */
	public void heal() {
		if (this.isPause()) {
			Iterator<GameObject> it = go.iterator();
			while (it.hasNext()) {
				GameObject o = it.next();
				if (o instanceof Astronaut && ((Astronaut) o).isSelected()) {
					((Astronaut) o).heal();
				}
			}
			this.setChanged();
			this.notifyObservers();
		}	
	}

	/**
	 * Return true if the Game is over.
	 * @return
	 */
	public boolean isGamOver() {
		return isGamOver;
	}

	/**
	 * Set to be true if Game is over.
	 * @param isGamOver
	 */
	public void setGamOver(boolean isGamOver) {
		this.isGamOver = isGamOver;
	}
	
	/**
	 * play the background sound only if game's status is soundOn and Play.
	 */
	public void setBGSoundStatus() {
		if(this.soundOn && !this.isPause)
			bgSound.play();
		else
			bgSound.pause();
	}
	
	
} // class GameWorld
