package com.mycompany.a3.Commands.Setting;

import com.codename1.ui.CheckBox;
import com.codename1.ui.Command;
import com.codename1.ui.SideMenuBar;
import com.codename1.ui.events.ActionEvent;
import com.mycompany.a3.GameWorld;
/**
 * <h1>AboutCommand</h1>
 * A Command enable or disable all Game's Sound.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class SoundCommand extends Command {
	private GameWorld gw;
	/**
	 * Constructor
	 * @param gw target GameWorld
	 */
	public SoundCommand(GameWorld gw) {
		super("Sound");
		this.gw = gw;
	}
	/**
	 * Calls GameWorld's method when activated.
	 * Activate when attached CheckBox is selected.
	 * @see com.mycompany.a2.GameWorld
	 */
	@Override
	public void actionPerformed(ActionEvent evt) {
		if (((CheckBox)evt.getComponent()).isSelected())
			gw.setSoundOn(true);
		else
			gw.setSoundOn(false);
		SideMenuBar.closeCurrentMenu(); 
	}
}

