package com.mycompany.a3.Commands.GameControl;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;
import com.mycompany.a3.GameWorld;
/**
 * <h1>MoveLeftCommand</h1>
 * A Command to move the SpaceShip left when activated.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class MoveLeftCommand extends Command{
	private static GameWorld gw;
	private static MoveLeftCommand myCommand;

	private MoveLeftCommand() {
		super("Left");
	}
	/**
	 * Set target.
	 * @param g Target 	 
	 */
	public static void setTarget(GameWorld g) {
		gw = g;
	}
	/**
	 * Return the current command, create one if not created yet.
	 * @return command
	 */
	public static MoveLeftCommand getCommand() {
		if (myCommand == null)
			myCommand = new MoveLeftCommand();
		return myCommand;
	}
	/**
	 * Calls GameWorld's method when activated.
	 * @see com.mycompany.a3.GameWorld
	 */
	@Override
	public void actionPerformed(ActionEvent ev) {
		gw.moveSpaceShipLeft();
	}

}
