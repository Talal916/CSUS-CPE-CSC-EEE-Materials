package com.mycompany.a3.Commands.GameControl;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;
import com.mycompany.a3.GameWorld;
/**
 * <h1>ScoreCommand</h1>
 * A Command to open the SpaceShip Door and let the GameObjects come in when activated.
 * The game statistics will then be updated.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class ScoreCommand extends Command{
	private static GameWorld gw;
	private static ScoreCommand myCommand;
	private static boolean isAble;

	private ScoreCommand() {
		super("Score");
	}
	/**
	 * Set target.
	 * @param g Target 	 
	 */
	public static void setTarget(GameWorld g) {
		gw = g;
	}
	/**
	 * Return the current command, create one if not created yet.
	 * @return command
	 */
	public static ScoreCommand getCommand() {
		if (myCommand == null)
			myCommand = new ScoreCommand();
		return myCommand;
	}
	/**
	 * Return if the current Command enable or not
	 * @return isAble
	 */
	public static boolean isAble() {
		return isAble;
	}
	/**
	 * Set the current Command to enable or not.
	 * @param isAble
	 */
	public static void setAble(boolean isAble) {
		ScoreCommand.isAble = isAble;
	}
	
	/**
	 * Calls GameWorld's method when activated.
	 * @see com.mycompany.a3.GameWorld
	 */
	@Override
	public void actionPerformed(ActionEvent ev) {
		if(isAble())
			gw.openSpaceShipDoor();
	}

}
