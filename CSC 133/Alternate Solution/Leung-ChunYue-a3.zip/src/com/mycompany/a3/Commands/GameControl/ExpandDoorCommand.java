package com.mycompany.a3.Commands.GameControl;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;
import com.mycompany.a3.GameWorld;
/**
 * <h1>ExpandDoorCommand</h1>
 * A Command to expand SpaceShip's door when activated.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class ExpandDoorCommand extends Command{
	private static ExpandDoorCommand myCommand;
	private static GameWorld gw;

	private ExpandDoorCommand() {
		super("Expand");
	}
	/**
	 * Set target.
	 * @param g Target  
	 */
	public static void setTarget(GameWorld g) {
		gw = g;
	}
	/**
	 * Return the current command, create one if not created yet.
	 * @return command
	 */
	public static ExpandDoorCommand getCommand() {
		if (myCommand == null)
			myCommand = new ExpandDoorCommand();
		return myCommand;
	}
	/**
	 * Calls GameWorld's method when activated.
	 * @see com.mycompany.a3.GameWorld
	 */
	@Override
	public void actionPerformed(ActionEvent ev) {
		gw.expandSpaceShipDoor();
	}

}
