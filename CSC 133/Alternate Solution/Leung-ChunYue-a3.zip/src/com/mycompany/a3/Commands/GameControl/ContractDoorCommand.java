package com.mycompany.a3.Commands.GameControl;

import com.codename1.ui.Command;
import com.codename1.ui.events.ActionEvent;
import com.mycompany.a3.GameWorld;
/**
 * <h1>ContractDoorCommand</h1>
 * A Command to Contract SpaceShip's door when activated.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class ContractDoorCommand extends Command{
	private static ContractDoorCommand myCommand;
	private static GameWorld gw;
	
	private ContractDoorCommand() {
		super("Contract");
	}
	/**
	 * Set target.
	 * @param g Target  
	 */
	public static void setTarget(GameWorld g) {
		gw = g;
	}
	/**
	 * Return the current command, create one if not created yet.
	 * @return command
	 */
	public static ContractDoorCommand getCommand() {
		if (myCommand == null)
			myCommand = new ContractDoorCommand();
		return myCommand;
	}
	/**
	 * Calls GameWorld's method when activated.
	 * @see com.mycompany.a3.GameWorld
	 */
	@Override
	public void actionPerformed(ActionEvent ev) {
		gw.contractSpaceShipDoor();
	}

}


