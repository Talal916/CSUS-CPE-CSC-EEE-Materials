package com.mycompany.a3.Commands.Setting;

import com.codename1.ui.Command;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.layouts.BoxLayout;
/**
 * <h1>AboutCommand</h1>
 * A Command to Show 'about' information in Dialog when activated.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class AboutCommand extends Command {
	/**
	 *  Constructor
	 */
	public AboutCommand() {
		super("About");
	}
	/**
	 *  Show 'About' information in Dialog
	 */
	@Override
	public void actionPerformed(ActionEvent ev) {
		Container infoBox = new Container(new BoxLayout(BoxLayout.Y_AXIS));
		infoBox.add(new BlueLabel("Chun Yue LEUNG")).add(new BlueLabel("CSC133 Assignment 3"));
		infoBox.add(new BlueLabel("              "));
		
		infoBox.getAllStyles().setPadding(5, 5, 40, 40);
		Dialog.show("About", infoBox, new Command("OK") {});
	}

}
