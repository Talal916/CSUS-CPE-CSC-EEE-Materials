package com.mycompany.a3.Commands.Setting;

import com.codename1.ui.Command;
import com.codename1.ui.Container;
import com.codename1.ui.Dialog;
import com.codename1.ui.events.ActionEvent;
import com.codename1.ui.layouts.BoxLayout;
/**
 * <h1>HelpCommand</h1>
 * A Command to Show 'Help' information in Dialog when activated.
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class HelpCommand extends Command{
	/**
	 * Constructor
	 */
	public HelpCommand() {
		super("Help");
	}
	/**
	 * Show the "Help" information.
	 */
	@Override
	public void actionPerformed(ActionEvent ev) {
		Container infoBox = new Container(new BoxLayout(BoxLayout.Y_AXIS));
		infoBox.add(new BlueLabel("Move To Alien (Key A)")).add(new BlueLabel("Move To Astronaut (Key O)"));
		infoBox.add(new BlueLabel("Move Right (Key R)")).add(new BlueLabel("Move Left (Key L)"));
		infoBox.add(new BlueLabel("Move Up (Key U)")).add(new BlueLabel("Move Down (Key D)"));
		infoBox.add(new BlueLabel("Expand Door (Key E)")).add(new BlueLabel("Contract Door (Key C)"));
		infoBox.add(new BlueLabel("Open Door and Update Score (Key S)"));
		infoBox.add(new BlueLabel("Exit (Key X)"));
		infoBox.add(new BlueLabel("              "));
		
		infoBox.getAllStyles().setPadding(5, 5, 40, 40);
	
		Dialog.show("Help", infoBox, new Command("OK") {});
	}

}