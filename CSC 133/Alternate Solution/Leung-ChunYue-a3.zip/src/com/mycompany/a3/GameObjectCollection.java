package com.mycompany.a3;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import com.mycompany.a3.GameObjects.GameObject;

/**
 * <h1>GameObjectCollection</h1>
 * Implements Iterator Design Pattern and holds a collection of game objects. 
 * Only supports basic Collection's methods such as
 * add, remove and iterate. 
 * @author Chun Yue LEUNG
 * @version 3.0
 */
public class GameObjectCollection implements ICollection{

	private ArrayList<GameObject> theCollection;
	
	/**
	 * Constructor
	 */
	public GameObjectCollection() {
		theCollection = new ArrayList<GameObject>();
	}
	
	/**
	 * 	add
	 *  @param object 
	 */
	public boolean add(GameObject object) {
		return theCollection.add((GameObject)object);
	}
	
	/**
	 * get size of the collection.
	 */
	public int size() {
		return theCollection.size();
	}
	
	/**
	 * Get GameObject at position t.
	 * @param t
	 * @return the GameObject at position t.
	 */
	public GameObject elementAt(int t) {
		return theCollection.get(t);
	}
	
	/**
	 * return if the Collection is empty.
	 */
	public boolean isEmpty() {
		return theCollection.isEmpty();
	}
	
	/**
	 *  Get Collection Iterator.
	 */
	public Iterator<GameObject> iterator() {
		return new GameObjectIterator();
	}
	
	// private inner class for Iterator
	private class GameObjectIterator implements Iterator<GameObject>{
		private int index;
		public GameObjectIterator() {
			index = -1;
		}
		
		public boolean hasNext() {
			return theCollection.size() > 0 && index < theCollection.size() -1;
		}

		public GameObject next() {
			index ++;
			return (theCollection.get(index));
		}

		public void remove() {
			theCollection.remove(index);
			index--;
		}	
	}
	/////////////////////// below methods are not supported /////////////////////////
	public boolean addAll(Collection<? extends GameObject> collection) {
		// TODO Auto-generated method stub
		return false;
	}


	public void clear() {
		// TODO Auto-generated method stub
		
	}


	public boolean contains(Object object) {
		// TODO Auto-generated method stub
		return false;
	}


	public boolean containsAll(Collection<?> collection) {
		// TODO Auto-generated method stub
		return false;
	}


	public boolean remove(Object object) {
		// TODO Auto-generated method stub
		return false;
	}


	public boolean removeAll(Collection<?> collection) {
		// TODO Auto-generated method stub
		return false;
	}


	public boolean retainAll(Collection<?> collection) {
		// TODO Auto-generated method stub
		return false;
	}


	public Object[] toArray() {
		// TODO Auto-generated method stub
		return null;
	}


	public <T> T[] toArray(T[] array) {
		// TODO Auto-generated method stub
		return null;
	}
}
