package com.mycompany.a1.GameObjects;

/**
 * <h1>Point</h1>
 * cartesian point with x and y value
 * @see com.mycompany.a1.GameObject.GameObject
 * @author Chun Yue LEUNG
 * @version 1.0
 */
public class Point {
	private double x;
	private double y;
	
	/**
	 * get this Point's x-coordinate
	 * @return x-coordinate
	 */
	public double getX() {
		return x;
	}
	/**
	 * get this Point's y-coordinate
	 * @return y-coordinate
	 */
	public double getY() {
		return y;
	}
	/**
	 * Set this point's x-coordinate
	 * @param x x-coordinate
	 */
	public void setX(double x) {
		this.x = x;
	}
	/**
	 * Set this point's y-coordinate
	 * @param y y-coordinate
	 */
	public void setY(double y) {
		this.y = y;
	}
	/**
	 * Constructor of Point
	 * @param x 
	 * @param y y-coordinate
	 */
	public Point(double x, double y) {
		setX(x);
		setY(y);
	}
	
	/**
	 * Set this point's x and y-coordinate
	 * @param x x-coordinate
	 * @param y y-coordinate
	 */
	public void setXY(double x, double y) {
		this.x = x;
		this.y = y;
	}

	/**
	 * return this Point's x and y values with 1 decimal place
	 */
	@Override
	public String toString() {
		return "loc=" + Math.round(x*10.0)/10.0 + "," + Math.round(y*10.0)/10.0;
	} 
} // class Point
