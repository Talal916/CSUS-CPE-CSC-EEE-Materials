package com.mycompany.a1.GameObjects;

import java.util.Random;

import com.codename1.charts.util.ColorUtil;

/**
 * <h1>Astronaut</h1>
 * An Game Character with additional attributes such as health and speedConstant
 * the speed of an Astronaut is equal to health * speedConstant
 * if an Astronaut got attacked, it health value will be minus by one
 * and its color will be faded.
 * @author Chun Yue LEUNG
 * @version 1.0
 */
public class Astronaut extends Opponent{

	private int health;
	private int speedConstant;
	
	/**
	 * Get this Astronaut's health
	 * @return health
	 */
	public int getHealth() {
		return health;
	}
	
	/**
	 * Set this Astronaut's health
	 * @param h health
	 */
	public void setHealth(int h) {
		health = h;
	}
	
	/**
	 * Get the this Astronaut's speed constant
	 * @return speedConstant
	 */
	public int getSpeedConstant() {
		return speedConstant;
	}
	
	/**
	 * the size of an Astronaut cannot be changed after initialized
	 */
	@Override 
	public void setSize(int x) {} 
	
	/**
	 * the size of an Astronaut cannot be changed after initialized
	 */
	@Override
	public void setRandomSize(int min, int max) {}
	
	/**
	 * return the location, Color by Red, Green, Blue seperate value, size, direction, speed, health of this Astronaut in String 
	 */
	@Override
	public String toString() {
		String parentDesc = super.toString();
		String myDesc1 = "Astronaut: ";
		String myDesc2 = " health=" + health;
		return myDesc1 + parentDesc + myDesc2;
	}
	
	/**
	 * Initialize an Astronaut to random location, random size, random direction.
	 * Health, color and speed constant are also needed to be set
	 * @param maxX maximum possible x
	 * @param maxY maximum possible y
	 * @param minSize minimum possible size
	 * @param maxSzie maximum possible size
	 * @param color RGB int value
	 * @param health 
	 * @param speedConstant
	 */
	public Astronaut(double maxX, double maxY, int minSize, int maxSzie, int color, int health, int speedConstant) {
		Random r = new Random();
		this.setLocation(maxX * r.nextDouble(), maxY * r.nextDouble());
		super.setRandomSize(minSize, maxSzie);
		setHealth(health);
		setColor(color);
		this.setDirection(r.nextInt(360));
		this.speedConstant = speedConstant;
		this.setSpeed(health * speedConstant);
	}

	/**
	 * This Astronaut's got hit, if its health is greater than zero, it will minus by one and its color
	 * will be faded by one gradient. no change if this Astronaut's's health is zero.
	 */
	public void getHit() {
		if (health > 0) {
			health--;
			int c = this.getColor();
			this.setColor(ColorUtil.red(c), ColorUtil.green(c)+30, ColorUtil.blue(c)+30);
			this.setSpeed(health * speedConstant);
		}
	}
}
