package com.mycompany.a1.GameObjects;

/**
 * <h1>Rescuer</h1>
 * In addition to contain GameObject's attributes, it also contains movement's behaviors
 * @see com.mycompany.a1.GameObject.GameObject
 * @author Chun Yue LEUNG
 * @version 1.0
 */
public abstract class Rescuer extends GameObject implements IGuided{
	
	/**
	 * @see com.mycompany.a1.GameObject.IGuided#moveLeft()
	 * Move this Rescuer left.
	 */
	public void moveLeft(int distance) {
		this.setLocation(-1 * distance, 0);
	} 
	
	/**
	 * @see com.mycompany.a1.GameObject.IGuided#moveRight()
	 * Move this Rescuer right.
	 */
	public void moveRight(int distance) {
		this.setLocation(distance, 0);
	} 

	/**
	 * @see com.mycompany.a1.GameObject.IGuided#moveUp()
	 * Move this Rescuer up.
	 */
	public void moveUp(int distance) {
		this.setLocation(0, distance);
	} 
	
	/**
	 * @see com.mycompany.a1.GameObject.IGuided#moveDown()
	 * Move the this Rescuer down.
	 */
	public void moveDown(int distance) {
		this.setLocation(0, -1 * distance);
	} 
	
	/**
	 * @see com.mycompany.a1.GameObject.IGuided#JumpToLocation()
	 * Transfer this Rescuer to target GameObject's location
	 */
	public void JumpToLocation(GameObject gameObject) {
		this.setLocation(gameObject.getLocation().getX(), gameObject.getLocation().getY());
	} 
} //class Rescuer

