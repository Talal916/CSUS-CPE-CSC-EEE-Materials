package com.mycompany.a1;

import com.codename1.ui.Form;

import com.codename1.ui.events.ActionListener;
import com.codename1.ui.Label;
import com.codename1.ui.TextField;
import com.codename1.ui.events.ActionEvent;
import java.lang.String;

/**
 * <h1>Game</h1>
 * Space Fight Game. In this game, the human player controls the location of a
 * spaceship. The Game object has two components:
 * 1) GameWorld which holds a collection of game objects and other state variables.
 * 2) a play() method to accept and execute user commands as an controller.
 * @author Chun Yue LEUNG
 * @version 1.0
 */
public class Game extends Form{

	private GameWorld gw;
	
	private boolean waitForExitConfirm = false;
	
	/**
	 * Initialize an GameWorld and wait for the player to play.
	 */
	public Game() {
		gw = new GameWorld();
		gw.init();
		play();
	}
	
	/**
	 * Act as an controller which accept user commands in character:
	 * call the GameWorld's method depends no the user's input.
	 * @see com.mycompany.a1.GameWorld
	 */
	private void play(){
		Label myLabel=new Label("Enter a Command:");
		this.addComponent(myLabel);
		final TextField myTextField=new TextField();
		this.addComponent(myTextField);
		this.show();
		
		myTextField.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent evt) {
				String sCommand=myTextField.getText().toString();
				myTextField.clear();
				
				// check if the user want to quit
				if (sCommand.charAt(0) == 'x') {
					waitForExitConfirm = true;
				}
				if (waitForExitConfirm) {
					switch (sCommand.charAt(0)) {
					case 'y':
						System.exit(0); // exit program if user enter 'y' after 'x'
					case 'n':
						waitForExitConfirm = false;
						System.out.println("\nBack to the game.");
						break;
					default:
						System.out.println("\nConfirm Exit? (y/n)");
						
					} //switch
				} //if
				else {
					switch (sCommand.charAt(0)) {
						// move SpaceShip to a Random Alien
						case 'a':
							gw.moveSpaceShipToAlien();
							break;
						// move SpaceShip to a Random Astronaut
						case 'o':
							gw.moveSpaceShipToAstronaut();
							break;
						case 'r':
							gw.moveSpaceShipRight();
							break;
						case 'l':
							gw.moveSpaceShipLeft();
							break;
						case 'u':
							gw.moveSpaceShipUp();
							break;
						case 'd':
							gw.moveSpaceShipDown();
							break;
						case 'e':
							gw.expandSpaceShipDoor();
							break;
						case 'c':
							gw.contractSpaceShipDoor();
							break;
						// Game Objects with IMove Interface move one time per tick
						case 't':
							gw.tickTime();
							break;
						// open door same size as SpaceShip size and let Alien and Astronaut to get in
						// score will be updated
						case 's':
							gw.openSpaceShipDoor();
							break;
						// create new alien around an random alien if there are two or more aliens left
						case 'w':
							gw.makeNewAlien();
							break;
						// pretend as Astronaut got hit by 1 and update its attributes
						case 'f':
							gw.fight();
							break;
						// print score, alien and astronaut's left and removed
						case 'p':
							gw.printStatus();
							break;
						// show all Game Object's attributes
						case 'm':
							gw.showMap();
							break;
						default:
							System.out.println("Invalid input");
						//add code to handle rest of the commands
						} //switch
					}//else
				} //actionPerformed
			} //new ActionListener()
		); //addActionListener
	} //play
}
