package com.mycompany.a1.GameObjects;

import java.util.Random;

/**
 * <h1> SpaceShip </h1>
 * <p>
 * Main Role Character with color cannot be changed after initialized.
 * The character size can be changed by user thru expandDoor() and contractDoor()
 * </p>
 * @author Chun Yue LEUNG
 * @version 1.0
 */
public class SpaceShip extends Rescuer{
	
	public SpaceShip(double maxX, double maxY, int size, int color){
		Random r = new Random();
		this.setLocation(maxX * r.nextDouble(), maxY * r.nextDouble());
		this.setSize(size);
		super.setColor(color);
	} // SpaceShip
	
	public void expandDoor(int increment, int maxSize) {
		this.setSize(this.getSize() + increment);
		if (this.getSize() > maxSize)
			this.setSize(maxSize);
	} // expandDoor
	
	public void contractDoor(int decrementint, int minSize) {
		this.setSize(this.getSize() - decrementint);
		if (this.getSize() < minSize)
			this.setSize(minSize);
	} // contractDoor
	
	@Override // Spaceship color cannot be changed after initialized
	public void setColor(int x) {}
	@Override // Spaceship color cannot be changed after initialized
	public void setColor(int r, int g, int b) {}
	
	@Override
	public String toString() {
		String parentDesc = super.toString();
		String myDesc1 = "SpaceShip: ";
		return myDesc1 + parentDesc;
	} //toString

} //class SpaceShip
