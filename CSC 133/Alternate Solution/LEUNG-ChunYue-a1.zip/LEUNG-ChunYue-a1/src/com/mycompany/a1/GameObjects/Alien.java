package com.mycompany.a1.GameObjects;

import java.util.Random;


/**
 * <h1>Alien</h1>
 * An Game Character with fixed color, fixed size and fixed speed after initialized
 * @author Chun Yue LEUNG
 * @version 1.0
 */
public class Alien extends Opponent{
	
	/**
	 * Initialize an Alien to random location, random size.
	 * Color and speed are also needed to be set.
	 * @param maxX maximum possible x
	 * @param maxY maximum possible y
	 * @param minSize minimum possible size
	 * @param maxSzie maximum possible size
	 * @param color RGB int value
	 * @param speed speed
	 */
	public Alien(double maxX, double maxY, int minSize, int maxSzie, int color, int speed) {
		super.setColor(0, 255, 0);
		Random r = new Random();
		this.setLocation(maxX, maxY);
		super.setRandomSize(minSize, maxSzie);
		setColor(color);
		this.setDirection(r.nextInt(360));
		super.setSpeed(speed);
	}
	
	/**
	 * The color of an Alien cannot be changed after initialized
	 */
	@Override // Alien's color cannot be changed after initialized
	public void setColor(int x) {}
	
	/**
	 * The color of an Alien cannot be changed after initialized
	 */
	@Override // Alien's color cannot be changed after initialized
	public void setColor(int r, int g, int b) {}
	
	/**
	 * The speed of an Alien cannot be changed after initialized
	 */
	@Override
	public void setSpeed(int s) {}
	
	/**
	 * The size of an Alien cannot be changed after initialized
	 */
	@Override
	public void setSize(int s) {}
	
	/**
	 * The size of an Alien cannot be changed after initialized
	 */
	@Override
	public void setRandomSize(int min, int max) {}
	
	@Override
	public String toString(){
		String parentDesc = super.toString();
		String myDesc1 = "Alien: ";
		return myDesc1 + parentDesc;
	}
	
}
