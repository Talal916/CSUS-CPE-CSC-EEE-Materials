package com.mycompany.a1.GameObjects;

import java.util.Random;

/**
 * <h1>Opponent</h1>
 * In addition to contain GameObject's attributes, it also contains speed and direction.
 * Direction is the heading direction of an Opponent. 
 * Moreover, it has an move's behavior.
 * @see com.mycompany.a1.GameObject.GameObject
 * @author Chun Yue LEUNG
 * @version 1.0
 */
public abstract class Opponent extends GameObject implements IMove{

	private int speed;
	private int direction;
	
	/**
	 * Set random size of this Opponent between minimum and maximum size (inclusive)
	 * @param min minimum size of this Opponent
	 * @param max maximum size of this Opponent
	 */
	public void setRandomSize(int min, int max) { 
		if (getSize() == 0) {
			Random r = new Random();
			super.setSize(min + r.nextInt(max-min+1));
		}
	} 
	
	/**
	 * get this Opponent's speed
	 * @return speed
	 */
	public int getSpeed() {
		return speed;
	} 
	
	/**
	 * get this Opponent's direction
	 * @return direction
	 */
	public int getDirection() {
		return direction;
	} 
	
	/**
	 * set this Opponent's direction in degree with range between 0 to 359, adjust back to the range if the value out of range 
	 * @param d
	 */
	public void setDirection(int d) {
		if (d < 0)
			d += 360;
		if (d >= 360)
			d -= 360;
		direction = d;
	} 
	
	/**
	 * set this Opponent's speed
	 * @param s
	 */
	public void setSpeed(int s) {
		speed = s;
	} 
	
	/**
	 *  return the location, Color by Red, Green, Blue seperate value, size, direction and speed of this Opponent in String
	 */
	@Override
	public String toString() {
		String parentDesc = super.toString();
		String myDesc = " speed=" + speed + " dir=" + direction;
		return parentDesc + myDesc;
	} //toString
	
	/**
	 * @see com.mycompany.a1.GameObject.IMove#move()
	 * Move this Opponent subject to its speed and direction. If it hit the boundary, 
	 * its direction will be changed according to the reflection angle. After each move, the direction
	 * will be sightly changed random so that this Opponent does not move as a straight line.
	 */
	public void move(double maxX, double maxY) {
		double theta = Math.toRadians(90 - this.getDirection());
		this.setLocation(Math.cos(theta) * this.getSpeed(),  Math.sin(theta) * this.getSpeed());

		// rebound to opposite direction when hit the boundary
		if (this.getLocation().getX() <= 0 || this.getLocation().getX() >= maxX)
			this.setDirection(360 - getDirection());
		else if (this.getLocation().getY() <= 0 || this.getLocation().getY() >= maxY)
			this.setDirection(180 - getDirection());
		Random r = new Random();
		this.setDirection(getDirection() -5 + r.nextInt(11));	
	} //move

} // class Opponent
