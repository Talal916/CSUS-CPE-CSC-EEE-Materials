package com.mycompany.a1.GameObjects;
/**
 * <h1>IGuided</h1>
 * Interface for movement's behavior contolled by player
 * @author Chun Yue LEUNG
 * @version 1.0
 */
public interface IGuided {
	public void moveLeft(int distance);
	public void moveRight(int distance);
	public void moveUp(int distance);
	public void moveDown(int distance);
	public void JumpToLocation(GameObject target);
}

