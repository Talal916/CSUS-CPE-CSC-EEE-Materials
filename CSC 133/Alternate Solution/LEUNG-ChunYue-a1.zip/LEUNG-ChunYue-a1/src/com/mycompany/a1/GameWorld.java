package com.mycompany.a1;

import java.util.Random;
import java.util.Vector;

import com.codename1.charts.util.ColorUtil;
import com.mycompany.a1.GameObjects.*;

/**
 * <h1>Game</h1>
 Holds a collection of game objects and other state variables such as score and how many different Opponents removed and left.
 * @author Chun Yue LEUNG
 * @version 1.0
 */
public class GameWorld {
	
	private Vector<GameObject> go;
	private int numOfAlienIn;
	private int numOfAlienLeft; 
	private int numOfAstronautIn; 
	private int numOfAstronautLeft;
	private int score;
	SpaceShip mainRole;
	
	public static final double X_MAX = 1024.0;
	public static final double Y_MAX = 768.0;
	public static final int OPPENENT_MIN_SIZE = 20;
	public static final int OPPENENT_MAX__SIZE = 50;
	public static final int OPPENENT_SPEED_CONSTANT = 1;
	
	public static final int ASTRONAUT_INITIAL_HEALTH = 5;
	public static final int ASTRONAUT_INITIAL_COLOR = ColorUtil.rgb(255, 0, 0);
	public static final int ASTRONAUT_INITIAL_NUM = 4;
	public static final int ASTRONAUT_MAX_SCORE = 10;

	public static final int ALIEN_INITIAL_COLOR = ColorUtil.rgb(0, 255, 0);
	public static final int ALIEN_SPEED_MULTIPLIER = 5;
	public static final int ALIEN_INITIAL_NUM = 3;
	public static final int ALIEN_PENALTY = 10;
	
	public static final int RESCUER_MOVE_INCREMENT = 10;
	
	public static final int SPACESHIP_INITIAL_SIZE = 100;
	public static final int SPACESHIP_MIN_SIZE = 50;
	public static final int SPACESHIP_MAX_SIZE = 1024;
	public static final int SPACESHIP_SIZE_INCREMENT = 50;
	public static final int SPACESHIP_INITIAL_COLOR = ColorUtil.rgb(0, 0, 255);
	
	/**
	 * Initialize this GameWorld. SpaceShip, Aliens, Astronauts will be placed randomly within the fixed size game world.
	 */
	public void init() {
		
		Random r = new Random();
		go = new Vector<GameObject>();
		mainRole = new SpaceShip(X_MAX*r.nextDouble(), Y_MAX*r.nextDouble(), SPACESHIP_INITIAL_SIZE, SPACESHIP_INITIAL_COLOR);
		go.add(mainRole);
		for (int i = 0; i< ALIEN_INITIAL_NUM; i++)
			go.add(new Alien(X_MAX*r.nextDouble(), Y_MAX*r.nextDouble(), OPPENENT_MIN_SIZE, OPPENENT_MAX__SIZE, ALIEN_INITIAL_COLOR , ALIEN_SPEED_MULTIPLIER * OPPENENT_SPEED_CONSTANT));
		for (int i = 0; i< ASTRONAUT_INITIAL_NUM; i++)
			go.add(new Astronaut(X_MAX*r.nextDouble(), Y_MAX*r.nextDouble(), OPPENENT_MIN_SIZE, OPPENENT_MAX__SIZE, ASTRONAUT_INITIAL_COLOR , ASTRONAUT_INITIAL_HEALTH, OPPENENT_SPEED_CONSTANT));
		numOfAlienIn = 0;
		numOfAlienLeft = ALIEN_INITIAL_NUM;
		numOfAstronautIn = 0;
		numOfAstronautLeft = ASTRONAUT_INITIAL_NUM;
		score = 0;
	}
	
	/**
	 * Get the Collection of GameObject
	 * @return Collection of GameObject
	 */
	Vector<GameObject> getGameObjects() {
		return go;
	}
	
	/**
	 * Get the player's score
	 * @return score
	 */
	public int getScore() {
		return score;
	}
	
	/**
	 * Set the player Score
	 * @param s score
	 */
	public void setScore(int s) {
		score = s;
	}
	
	/**
	 * Transfer the Spaceship to an random alien, print error message if there is no alien.
	 */
	public void moveSpaceShipToAlien() { 
		Vector<GameObject> alienVector = new Vector<GameObject>();
		for (GameObject x: go){
			if (x instanceof Alien)
				alienVector.add(x);
		} //for
		if (alienVector.size() == 0) {
			System.out.print("Error, no alien left!\n");
			return;
		} //if
		Random r = new Random();
		mainRole.JumpToLocation(alienVector.get(r.nextInt(alienVector.size())));
		System.out.print("Jumped to a random alien position.\n");
		
	} // moveSpaceShipToAlien
	
	/**
	 * Transfer the spaceship to a location of a randomly selected astronaut.
	 */
	public void moveSpaceShipToAstronaut() {
		if (numOfAstronautLeft > 0) {
			Vector<GameObject> astronautVector = new Vector<GameObject>();
			for (GameObject x: go){
				if (x instanceof Astronaut)
					astronautVector.add(x);
			} // for
			Random r = new Random();
			mainRole.JumpToLocation(astronautVector.get(r.nextInt(astronautVector.size())));
			System.out.print("Jumped to a random Astronaut position.\n");
		} // if
		else {
			System.out.print("Error, no astronaut left!\n");
		} //else
	} //moveSpaceShipToAstronaut
	
	/**
	 * Move the spaceship to the right.
	 */
	public void moveSpaceShipRight() {
		mainRole.moveRight(RESCUER_MOVE_INCREMENT);
		System.out.print("Moved right by " + RESCUER_MOVE_INCREMENT + "pixel(s).\n");
	} //spaceShipToRight
	
	/**
	 * Move the spaceship to the left.
	 */
	public void moveSpaceShipLeft() {
		mainRole.moveLeft(RESCUER_MOVE_INCREMENT);
		System.out.print("Moved left by " + RESCUER_MOVE_INCREMENT + "pixel(s).\n");
	} // spaceShipToLeft
	
	/**
	 * Move the spaceship up.
	 */
	public void moveSpaceShipUp() {
		mainRole.moveUp(RESCUER_MOVE_INCREMENT);
		System.out.print("Moved up by " + RESCUER_MOVE_INCREMENT + "pixel(s).\n");
	} //spaceShipToUp
	
	/**
	 * Move the spaceship down.
	 */
	public void moveSpaceShipDown() {
		mainRole.moveDown(RESCUER_MOVE_INCREMENT);
		System.out.print("Moved down by " + RESCUER_MOVE_INCREMENT + "pixel(s).\n");
	} //spaceShipToDown
	
	/**
	 * Expand the size of the spaceship door
	 */
	public void expandSpaceShipDoor() {
		mainRole.expandDoor(SPACESHIP_SIZE_INCREMENT, SPACESHIP_MAX_SIZE);
		if (mainRole.getSize() < SPACESHIP_MAX_SIZE)
			System.out.print("Door expanded.\n");
		else
			System.out.print("Door size is at max.\n");
	} //expandSpaceShipDoor
	
	/**
	 * Contract (decrease) the size of the spaceship door
	 */
	public void contractSpaceShipDoor() {
		mainRole.contractDoor(SPACESHIP_SIZE_INCREMENT, SPACESHIP_MIN_SIZE);
		if (mainRole.getSize() > SPACESHIP_MIN_SIZE)
			System.out.print("Door contracted.\n");
		else
			System.out.print("Door size is at min.\n");
	}
	
	/**
	 * Tell the game world that the �game clock� has ticked. All moving objects are told to update their positions according to their current direction and speed.
	 */
	public void tickTime() {
		for (GameObject x: go){
			if (x instanceof IMove)
				((IMove)x).move(X_MAX, Y_MAX);
		} // for
		System.out.print("Times is ticked.\n");
	} // tickTime
	
	// helper's function to check if the Oppenents in the SpaceShip's door.
	private static boolean withinDoor(GameObject o, double top, double bottom, double right, double left) {
		return o.getLocation().getY() <= top && o.getLocation().getY() >= bottom && o.getLocation().getX() >= left && o.getLocation().getX() <= right;
	} //withinBoundary

	/**
	 * Open the door and update the score according to the types and conditions of 
	 * opponents that are let in to the spaceship as described above in rules of play. This 
	 * causes all of the opponents whose centers are within the boundaries of the bounding 
	 * square of the door to be removed from the game world.
	 */
	public void openSpaceShipDoor() {

		double doorSize = mainRole.getSize();
		double topBound = mainRole.getLocation().getY() + doorSize/2;
		double bottomBound = mainRole.getLocation().getY() - doorSize/2;
		double rightBound = mainRole.getLocation().getX() + doorSize/2;
		double leftBound = mainRole.getLocation().getX() - doorSize/2;
		
		Vector<GameObject> toBeRemoved = new Vector<GameObject>();
		for (int i = 0; i < go.size(); i++) {
			if (go.elementAt(i) instanceof Alien) {
				if (withinDoor(go.elementAt(i), topBound, bottomBound, rightBound, leftBound)) {
					score -= ALIEN_PENALTY;
					numOfAlienIn++;
					numOfAlienLeft--;
					toBeRemoved.add(go.elementAt(i));
				} //if
			} //if
			else if(go.elementAt(i) instanceof Astronaut){
				if (withinDoor(go.elementAt(i), topBound, bottomBound, rightBound, leftBound)) {
					score += ASTRONAUT_MAX_SCORE - (ASTRONAUT_INITIAL_HEALTH - ((Astronaut)go.elementAt(i)).getHealth());
					numOfAstronautIn++;
					numOfAstronautLeft --;
					toBeRemoved.add(go.elementAt(i));
				} //if
			} //if
		} //for
		System.out.print("Door is opened and then closed.\n");
		for (GameObject x: toBeRemoved)
			go.remove(x);
		if (numOfAstronautLeft == 0) {
			System.out.print("\n<<<<<<<Game Over>>>>>>\n");
			printStatus();
		} //if
	} //method openSpaceShipdoor
	
	/**
	 * If there are at least two aliens. If so, it randomly picks an alien and produces a 
	 * new alien in a location that is close to the chosen alien. If the number of aliens in the 
	 * world is less than two, print an error message without producing a new alien.
	 */
	public void makeNewAlien() {
		if (numOfAlienLeft >= 2) {
			Random r = new Random();
			while(true) {
				int t = r.nextInt(go.size());
				if (go.elementAt(t) instanceof Alien) {
					Alien oldGuy = (Alien) go.elementAt(t);
					Alien newGuy = new Alien(X_MAX*r.nextDouble(), Y_MAX*r.nextDouble(), OPPENENT_MIN_SIZE, OPPENENT_MAX__SIZE, ALIEN_INITIAL_COLOR , ALIEN_SPEED_MULTIPLIER * OPPENENT_SPEED_CONSTANT);
					newGuy.setLocation(oldGuy.getLocation().getX() + 5 , oldGuy.getLocation().getY() +5);
					go.add(newGuy);
					numOfAlienLeft++;
					break;
				} // if
			} // while
			System.out.print("An new aliean is creadted.\n");
		} // if
		else
			System.out.println("Error, needs at least two aliens to make a new one.");
	} // makeNewAlien
	
	/**
	 * Randomly picks an astronaut and decrements its health value, updates its 
	 * speed, and changes its color. If there are no aliens, print an error message instead.
	 */
	public void fight() {
		if (numOfAlienLeft > 0) {
			Random r = new Random();
			while(true) {
				int t = r.nextInt(go.size());
				if (go.elementAt(t) instanceof Astronaut) {
					((Astronaut)go.elementAt(t)).getHit();
					break;
				} //if
			} // while
			System.out.print("An fight occurred\n");
		}else
			System.out.print("Error, no alien left.\n");
	} //fight
	
	/**
	 * print the points of game state values: (1) current score, (2) number of astronauts 
	 * rescued, (3) number of aliens sneaked in to the spaceship, and (4) number of 
	 * astronauts left in the world, (5) number of aliens left in the world.
	 */
	public void printStatus() {
		System.out.println("**** Status *****");
		System.out.println("Score: " + score);
		System.out.println("Astronaut rescured: " + numOfAstronautIn);
		System.out.println("Alien sneaked in: " + numOfAlienIn);
		System.out.println("Astronaut left: " + numOfAstronautLeft);
		System.out.println("Alien left: " + numOfAlienLeft);
		System.out.println("*****************");
	} // printStatus
	
	/**
	 * print a �map� showing the current world state.
	 * All the attributes of the GameObject will be shown.
	 */
	public void showMap() {
		for (GameObject i : go) {
			System.out.println(i);
		} //for
	} // showMap
} // class GameWorld
