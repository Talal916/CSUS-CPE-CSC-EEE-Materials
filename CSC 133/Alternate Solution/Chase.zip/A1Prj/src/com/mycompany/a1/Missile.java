package com.mycompany.a1;

import com.codename1.ui.geom.Point2D;

public class Missile extends MoveableGameObject
{
	public enum MissileType { PLAYER, ENEMY }
	private int fuelLevel;
	private MissileType type;
	
	public Missile(int missileLauncherDir, Point2D loc, MissileType type)
	{
		fuelLevel = 10;
		SetDirection(missileLauncherDir);
		SetLocation(loc);
		this.type = type;
		switch (type)
		{
			case PLAYER:
				SetColor(0, 255, 255);
				break;
				
			case ENEMY:
				SetColor(255, 0, 0);
				break;
		}
	}
	
	public int GetFuel()
	{
		return fuelLevel;
	}
	
	public MissileType GetType()
	{
		return type;
	}

	@Override
	public void Move() 
	{
		fuelLevel--;
		super.Move();
	}
	
	public String toString()
	{
		String parentString = super.toString();
		String thisString = " fuel = " + fuelLevel;
		if (type == MissileType.PLAYER)
		{
			return "PS's Missile: " + parentString + thisString;			
		}
		else
		{
			return "NPS's Missile: " + parentString + thisString;
		}
	}
}
