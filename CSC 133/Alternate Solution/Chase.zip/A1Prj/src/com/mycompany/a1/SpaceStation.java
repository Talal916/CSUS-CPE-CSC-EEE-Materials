package com.mycompany.a1;

public class SpaceStation extends FixedGameObject
{
	private int thisId;
	private int blinkRate;
	private int timeSinceBlink;
	private boolean lightsOn;
	
	public SpaceStation()
	{
		thisId = GetId();
		blinkRate = rng.nextInt(4) + 1;
		lightsOn = true;
		timeSinceBlink = 0;
		SetColor(255, 0, 255);	
	}
	
	public int GetRate()
	{
		return blinkRate;
	}
	
	public void IncreaseBlinkTime()
	{
		timeSinceBlink++;
		if (timeSinceBlink == blinkRate)
		{
			lightsOn = !lightsOn;
			timeSinceBlink = 0;
		}
	}
	
	public String toString()
	{
		String parentString = super.toString();
		String thisString = " rate = " + blinkRate;
		return "Station: " + parentString + thisString;
	}
}
