package com.mycompany.a1;
import java.util.Random;
import com.codename1.charts.util.ColorUtil;
import com.codename1.ui.geom.Point2D;

public class GameObject 
{
	public Random rng = new Random();
	private Point2D location;
	private int rgb;
	
	public GameObject()
	{
		double x = Math.round((1025.0 * rng.nextDouble() * 10.0)) / 10.0;
		double y = Math.round((769.0 * rng.nextDouble() * 10.0)) / 10.0;
		
		//These two tests are only for the EXTREMELY rare instances where x or y will be greater than the max values
		//of 1024 and 768 respectively. 
		if (x > 1024.0) { x = 1024.0; }
		if (y > 768.0) { y = 768.0; }
		
		location = new Point2D(x, y);
	}
	
	public int GetColor()
	{
		return rgb;
	}
	
	public void SetColor(int r, int g, int b)
	{
		rgb = ColorUtil.rgb(r, g, b);
	}
	
	public double GetLocationX()
	{
		return location.getX();
	}
	
	public double GetLocationY()
	{
		return location.getY();
	}
	
	public Point2D GetFullLocation()
	{
		return location;
	}
	
	public void SetLocation(double x, double y)
	{
		location.setX(Math.round((x * 10.0)) / 10.0);
		location.setY(Math.round((y * 10.0)) / 10.0);
	}
	
	public void SetLocation(Point2D loc)
	{
		location.setX(Math.round((loc.getX() * 10.0)) / 10.0);
		location.setY(Math.round((loc.getY() * 10.0)) / 10.0);
	}
	
	public String toString()
	{
		return "loc = " + location.getX() + ", " + location.getY() +  
				" color = [" + ColorUtil.red(rgb) + ", " +  
							   ColorUtil.green(rgb) + ", " +
							   ColorUtil.blue(rgb) + "] ";
	}
}
