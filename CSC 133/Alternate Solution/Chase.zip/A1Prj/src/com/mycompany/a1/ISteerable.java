package com.mycompany.a1;

public interface ISteerable 
{
	public void ChangeDir(int amount);
}
