package com.mycompany.a1;

public class EnemyShip extends MoveableGameObject
{
	private int size;
	private int missileCount;
	
	public EnemyShip()
	{
		size = (rng.nextInt(2) + 1) * 10;
		missileCount = 2;
		SetColor(255, 0, 0);
	}
	
	public int GetSize()
	{
		return size;
	}
	
	public int GetMissileCount()
	{
		return missileCount;
	}
	
	public void Fire()
	{
		//Fire enemy missiles
		missileCount--;
	}

	@Override
	public void Move() 
	{
		super.Move();	
	}
	
	public String toString()
	{
		String parentString = super.toString();
		String thisString = " size = " + size;
		return "Non-Player Ship: " + parentString + thisString;
	}
}
