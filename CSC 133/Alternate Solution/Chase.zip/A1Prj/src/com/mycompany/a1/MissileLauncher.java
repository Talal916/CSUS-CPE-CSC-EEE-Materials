package com.mycompany.a1;

public class MissileLauncher extends MoveableGameObject implements ISteerable
{
	private int LauncherDirection;
	
	public MissileLauncher(int startDir)
	{
		LauncherDirection = startDir;
	}
	
	public int GetLauncherDir()
	{
		return LauncherDirection;
	}
	
	public void SetLauncherDir(int amount)
	{
		LauncherDirection = amount;
	}
	
	@Override
	public void Move() 
	{

	}
	
	@Override
	public void ChangeDir(int amount)
	{
		LauncherDirection += amount;
	}

	public String toString()
	{
		return " Missile Launcher Direction = " + LauncherDirection;
	}
}
