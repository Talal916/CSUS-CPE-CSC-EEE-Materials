package com.mycompany.a1;

public interface IMoveable 
{
	/**
	 * All moveable objects are required to move based on current speed and direciton
	 */
	public void Move();
}
