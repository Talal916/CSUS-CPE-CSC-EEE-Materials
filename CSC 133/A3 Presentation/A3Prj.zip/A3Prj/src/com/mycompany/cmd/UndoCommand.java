package com.mycompany.cmd;

import com.codename1.ui.Command;

public class UndoCommand extends Command 
{

	public UndoCommand() 
	{
		super("Undo");
	}
}
