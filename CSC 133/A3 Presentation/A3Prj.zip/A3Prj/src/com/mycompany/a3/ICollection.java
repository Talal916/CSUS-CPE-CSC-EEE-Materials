package com.mycompany.a3;

public interface ICollection {

	public IIterator getIterator();
	
	public int getSize();
	
	public void add(GameObject gameObj);
	
	
}
