package com.mycompany.sampleui;
import com.codename1.ui.*;
import com.codename1.ui.layouts.BorderLayout;
import com.codename1.ui.layouts.BoxLayout;
/** This class creates a "Form" that has a title specified by the user
 *  User types the title on a
 */
public class SimpleForm extends Form {
public SimpleForm() {  
	this.show();
	}
}
