package com.mycompany.a3;

import com.codename1.ui.geom.Point2D;

public class Missile extends MoveableGameObject {

	private int fuelLevel;
	private boolean isFriendly;
	private boolean selected = false;
	private final int MISSILE_FUEL = 100;
	
	public Missile(int missileDirection, Point2D shotLocation, boolean friendly)
	{
		fuelLevel = MISSILE_FUEL;
		setDirection(missileDirection);
		setLocation(shotLocation);
		if(friendly)
		{
			setColor(255,102,178); //friendly missiles are pink
			isFriendly = true;
		}
		else
		{
			setColor(255,128,0); //enemy missiles are orange
			isFriendly = false;
		}
		
	}
	
	
	public boolean getisFriendly()
	{
		return isFriendly;
		
	}
	public int getFuel()
	{
		
		return fuelLevel;
	}
	

	
	public String toString()
	{
		String parentDesc = super.toString();
		String myDesc = " fuel = " + fuelLevel;
		String retval = "";
		if(isFriendly)
			retval = " PS Missile: " + parentDesc + myDesc;
		else
			retval = " Enemy Missile: " + parentDesc + myDesc;
		
		
		return retval;
	}


	public boolean isSelected() {
		// TODO Auto-generated method stub
		return selected ;
	}


	public void resetFuel() {
		fuelLevel = MISSILE_FUEL;
	}
}
