package com.mycompany.a3;

public interface IMoveable {
	
	public void Move(double mapWidth,double mapHeight, double time);

}
