package com.mycompany.cmd;

import com.codename1.ui.Command;

public class NewGameCommand extends Command 
{

	public NewGameCommand() 
	{
		super("New");
	}
}
