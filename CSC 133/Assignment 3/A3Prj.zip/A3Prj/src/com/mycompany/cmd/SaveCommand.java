package com.mycompany.cmd;

import com.codename1.ui.Command;

public class SaveCommand extends Command 
{

	public SaveCommand()
	{
		super("Save");
	}
}
