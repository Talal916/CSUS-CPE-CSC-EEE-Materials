Changes made to official Asteroids a1 specifications: NONE

