package com.mycompany.a1;

public interface ISteerable 
{

	public void turn();
	
}
