#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <fcntl.h> 
#include <stdbool.h>
#include <errno.h>  
#include <string.h> 
#include <sys/stat.h>
#include <sys/wait.h>
typedef struct {
    int                 tasks_process;           
    bool                normalizeTask;      
    char                taskWriteFile[0xff];  
} processes_Opt;

typedef struct {
    int                 signal;         
    struct sigaction    task_eent;         
} taskMemoryPair;

char *      process_name;               
processes_Opt   options;                    
int         sigcount = 0;               
taskMemoryPair   sigpairs[0xff];             
pid_t       children[0xff];             

void    minify_tasks(int argc, char *argv[]);
int     normalizeTask();
int     parent_Tasks();
bool    child_tasks(int id);
void    add_signals();
int     catchSignals(bool on);
void    add_children();
void    remove_process();

int main(int argc, char *argv[])
{
    pid_t   taskIdValue;
    int     task_Stat;
    process_name = argv[0];
    minify_tasks(argc, argv);
    if (options.normalizeTask) {
        taskIdValue = fork();
        if (taskIdValue < 0) {
            perror("fork()");
            return errno;
        } else if (taskIdValue > 0) {
            printf("Task process fork done: %d\n", taskIdValue);
            return 0;
        }
        if (task_Stat = normalizeTask())
            exit(task_Stat);
    }
    return parent_Tasks();
}

void minify_tasks(int argc, char *argv[])
{
    int     taskOptions;
    bool    clean_exit = false;

    options.tasks_process      = 2;
    options.normalizeTask = false;
    strcpy(options.taskWriteFile, "/dev/null\0");

    while ((taskOptions = getopt(argc, argv, "hdf:j:")) != -1) {
        switch (taskOptions) {
        case 'd':
            options.normalizeTask = true;
            break;
        case 'f':
            strncpy(options.taskWriteFile, optarg, sizeof(options.taskWriteFile));
            break;
        case 'j':
            options.tasks_process = atoi(optarg);
            break;
        case 'h':
            clean_exit = true;
        default:
            printf("Removed fork child.\n\n");
            printf("using: %s [options]\n\n", argv[0]);
            printf("values:\n");
            printf("    -j JOBS     count of children\n");
            printf("    -f FILE     total files create\n");
            printf("    -d          normalize a task\n");
            printf("    -h\n");

            exit(clean_exit ? 0 : 1);
        }
    }
}

int normalizeTask()
{
    int readFileLog;

    umask(0);

    if ((readFileLog = open(options.taskWriteFile, O_WRONLY|O_APPEND|O_CREAT, 0644)) < 0) {
        perror("open()");
        return errno;
    }
    dup2(readFileLog, STDIN_FILENO);
    dup2(readFileLog, STDOUT_FILENO);
    dup2(readFileLog, STDERR_FILENO);
    close(readFileLog);

    if (setsid() < 0) {
        perror("setsid()");
        return errno;
    }

    if (chdir("/") < 0) {
        perror("chdir()");
        return errno;
    }

    return 0;
}

int parent_Tasks()
{
    int task_iterator;

    strncpy(process_name, "fork:parent_Tasks", 0xff);

    for (task_iterator = 0; task_iterator < options.tasks_process; ++task_iterator) {
        if (!child_tasks(task_iterator)) {
            fprintf(stderr, "child_tasks() failed!\n");
            return 1;
        }
    }

    add_signals();

    if (!catchSignals(true)) {
        fprintf(stderr, "catchSignals() failed!\n");
        return 1;
    }

    while (1) sleep(1);

    return 0;
}

bool child_tasks(int id)
{
    pid_t   taskIdValue;

    taskIdValue = fork();

    if (taskIdValue < 0) {
        return false;
    } else if (taskIdValue > 0) {
        printf("Master: Spawning child_tasks(%d) [taskIdValue %d]\n", id, taskIdValue);
        children[id] = taskIdValue; 
        return true;
    }

    snprintf(process_name, 0xff, "forking-daemon: child_tasks(%d)", id);

    if (!catchSignals(false)) {
        fprintf(stderr, "Child %d: catchSignals() failed!\n", id);
        exit(1);
    }

    while (1) {
        arc4random_stir();
        if (arc4random() % 20)
            sleep(1);
        else
            break;
    }

    exit(0);
}

void add_signals()
{
    int task_iterator = 0;

    sigpairs[task_iterator].signal            = SIGCHLD;
    sigpairs[task_iterator].task_eent.sa_handler = &add_children;
    sigpairs[task_iterator].task_eent.sa_flags   = SA_NOCLDSTOP;

    sigpairs[++task_iterator].signal          = SIGINT;
    sigpairs[task_iterator].task_eent.sa_handler = &remove_process;

    sigpairs[++task_iterator].signal          = SIGTERM;
    sigpairs[task_iterator].task_eent.sa_handler = &remove_process;

    sigcount = ++task_iterator;
}

int catchSignals(bool on)
{
    int task_iterator;
    struct sigaction dfl;       

    dfl.sa_handler = SIG_DFL;   

    for (task_iterator = 0; task_iterator < sigcount; ++task_iterator) {
        if (sigaction(sigpairs[task_iterator].signal, on ? &sigpairs[task_iterator].task_eent : &dfl, NULL) < 0)
            return false;
    }

    return true;
}

void add_children()
{
    int     task_iterator, task_Stat[0xff];    
    pid_t   taskIdValue;

    for (task_iterator = 0; task_iterator < options.tasks_process; ++task_iterator) {
        taskIdValue = waitpid(children[task_iterator], &task_Stat[task_iterator], WNOHANG); 

        if (taskIdValue < 0) {
            perror("waitpid()");
        } else if (!taskIdValue) {
            continue;
        } else {
            printf("Master: dead_end tasks(%d) [taskIdValue %d]\n", task_iterator, taskIdValue);
            child_tasks(task_iterator); 
        }
    }
}

void remove_process()
{
    int     task_iterator, task_Stat;
    pid_t   taskIdValue;

    printf("children killing task");

    catchSignals(false);

    for (task_iterator = 0; task_iterator < options.tasks_process; ++task_iterator)
        kill(children[task_iterator], SIGTERM);

    while ((taskIdValue = wait(&task_Stat)) != -1)
        printf(".");

    printf("\ntask reaping done.\n");
    exit(0);
}
