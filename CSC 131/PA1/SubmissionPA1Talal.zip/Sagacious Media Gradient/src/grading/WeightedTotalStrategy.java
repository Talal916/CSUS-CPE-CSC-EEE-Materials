package grading;
import java.util.*;
public class WeightedTotalStrategy {
	private Map<java.lang.String,java.lang.Double> weights;
	
	public WeightedTotalStrategy()
	{
		
	}
	
	public WeightedTotalStrategy(Map<java.lang.String,java.lang.Double> weights)
	{
		
	}
	

}
