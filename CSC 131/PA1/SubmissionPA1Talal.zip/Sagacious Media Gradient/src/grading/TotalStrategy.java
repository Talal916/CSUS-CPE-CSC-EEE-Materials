package grading;
import java.util.*;

public class TotalStrategy implements GradingStrategy {

	public TotalStrategy()
	{
		
	}

	@Override
	public Grade calculate(String key, List<Grade> grades) throws SizeException {
		// TODO Auto-generated method stub
		return null;
	}


}
