package grading;

public class SizeException extends Exception {


	public final long serialVersionUID = 1L;
	
}
