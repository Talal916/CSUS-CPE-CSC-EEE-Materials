# Sagacious-Media-Gradient
PA1 for CSC 131

Check Documentation folder for project specifications followed. 
