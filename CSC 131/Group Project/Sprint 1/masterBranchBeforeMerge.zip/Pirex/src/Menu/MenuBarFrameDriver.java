package Menu;

/**
 * Temp testing class for MenuBar
 * 
 */
public class MenuBarFrameDriver
{

    /**
     * The entry point of the example
     *
     * @param args   The command line arguments
     */

	
//	Old testing main
//    public static void main(String[] args)
//    {
//        MenuBar   f;
//
//        f = new MenuBar();
//        f.setSize(400,200);
//        f.setVisible(true);
//
//        
//    }
}
