#ifndef SLEEPYSTORY_H
#define SLEEPYSTORY_H


class SleepyStory
{
    public:
        SleepyStory();
        virtual ~SleepyStory();

    protected:

    private:
};

#endif // SLEEPYSTORY_H
