#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

void usageErrorHandling(int errorCode) {
  switch (errorCode){
  case 1:
    printf("Usage: talal [fcfs|sstf|look] { cylinder/tracks to be read } \n");
    exit(-1);
case 2:
  printf("Enter a valid Algorithm!\n");
  exit(-1);
}
}

int getAlgorithmSelected(char *algorithm) {
  if (strcmp(algorithm, "fcfs") == 0)
    {
      return 1;
    }
    else if (strcmp(algorithm, "sstf") == 0)
    {
      return 2;
    }
    else if (strcmp(algorithm, "look") == 0)
    {
      return 3;
    }
    else
    {
      usageErrorHandling(1);
    }
}

int * convertCharArrayToInt(int numberOfTracks,char *tracks[], bool print) {
  int returnArray[numberOfTracks];
  returnArray[0] = 50;
  int intedChar;
  int i;
  for (i = 1; i < numberOfTracks; i++)
  {
    intedChar = atoi(tracks[i]);
    returnArray[i] = intedChar;
    if(print){
    printf("Return Distance: %d\n", intedChar);
    }
  }
  return returnArray;
}

void fcfs(int numberOfTracks,char *tracks[]) {
  int i;
  int* intedArr = convertCharArrayToInt(numberOfTracks, tracks, true);
  int totalDistance = 0;
  for (i = 0; i < numberOfTracks - 1; i++)
  {
    totalDistance = totalDistance + abs(intedArr[i + 1] - intedArr[i]);
  }
  printf("Total Distance: %d\n", totalDistance);
}

int sortingHelper (const void * a, const void * b) { //From TutorialsPoint.com qsort() tutorial
   return ( *(int*)a - *(int*)b );
}

void sstf(int numberOfTracks,int *intedArr) {
  int totalDistance = 0, i, lastPtr = 50, nextPtr;
  for (i = 1; i < numberOfTracks; i++)
  {
    nextPtr = intedArr[i];
    printf("Reading tracks %d\n", nextPtr); 
    if (lastPtr > nextPtr) {
      totalDistance = totalDistance + (lastPtr - nextPtr);
    }
    else {
      totalDistance = totalDistance + (nextPtr - lastPtr);
      }
    lastPtr = nextPtr;
  }
  printf("Total distance: %d\n", totalDistance); 
  return;
}

void look(int numberOfTracks,int *intedArr) {
  int totalDistance = 0, i, lastPtr = 50, nextPtr;
  printf("Testing");
  for (i = 1; i < numberOfTracks; i++)
  {
    nextPtr = intedArr[i];
    printf("Reading track: %d\n", nextPtr); 
    if (lastPtr > nextPtr) {
      totalDistance = totalDistance + (lastPtr - nextPtr);
    }
    else {
      totalDistance = totalDistance + (nextPtr - lastPtr);
      }
    lastPtr = nextPtr;
  }
  printf("Total distance: %d\n", totalDistance); 
  return;
  return;
}

int main(int argc, char ** argv) {
  int algorithmSelected = getAlgorithmSelected(argv[1]);
  int* intedArr = convertCharArrayToInt(argc, argv, false);
 // qsort(intedArr, argc, sizeof(int), sortingHelper);

  switch(algorithmSelected) {
    case 1:
      fcfs(argc, argv);
      break;
    case 2:
      sstf(argc, intedArr);
      break;
    case 3:
      look(argc, intedArr);
      break;
    }
}