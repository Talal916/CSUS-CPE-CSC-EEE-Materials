How to Compile:

gcc talal.c -o talal

Usage: talal [input_file] [FIFO|LRU|OPT] 

Make sure there is an input file in same folder as executable. 

