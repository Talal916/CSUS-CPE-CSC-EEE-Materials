#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>


void usageErrorHandling(int errorCode) {
  switch (errorCode){
  case 1:
    printf("Usage: talal [input_file] [FIFO|LRU|OPT] \n");
    exit(-1);
case 2:
  printf("Enter a file name and try again...\n");
  exit(-1);
case 3:
  printf("Enter a valid Page Request Algorithm!\n");
  exit(-1);
}
}

void printIntroMessage(char *algorithmName) {
    printf("Page Request Algorithm: %s\n\n", algorithmName);
}

void pageMessage(int page, int frame, int situation) {
  switch(situation) {
    case 1:
        printf("Page %d already in Frame %d\n", page, frame);
        break;
    case 2:
      printf("Page %d loaded in Frame %d\n", page, frame);
      break;
    case 3:
      printf("Page %d unloaded from Frame %d, ", page, frame);
      break;
    }
}

void pageFaultMessage(int faultNumber) {
			printf("\n%d Page Faults\n\n", faultNumber);
}

int getAlgorithmSelected(char *algorithm) {
  if (strcmp(algorithm, "FIFO") == 0)
    {
      return 1;
    }
    else if (strcmp(algorithm, "LRU") == 0)
    {
      return 2;
    }
    else if (strcmp(algorithm, "OPT") == 0)
    {
      return 3;
    }
    else
    {
      usageErrorHandling(1);
    }
}

  int main(int argc, char *argv[])
  {
    int numberOfPageRequests, numberOfPages;
    int temp, minimumNumberOfPageRequests, maximumNumberOfPageRequests, currentRequest, requestIndex;
    int holderVar, numberOfFrames;
    int tempflag = 0;
    int faultCount = 0;
    int increment4 = 0;
    int currentFrame = 0;
    int flag = 0;
    int faultNum = 0; 
    int i = 0;
    int j = 0;
    int k = 0;
    int f = 0;
    int s = 0;
    FILE *input;
    if (argv[2] == NULL)
    {
      usageErrorHandling(1);
    }
    else if (argc >= 2)
    {
      input = fopen(argv[1], "r");
      i = 0;
      fscanf(input, "%d %d %d", &numberOfPages, &numberOfFrames, &numberOfPageRequests);

    }
    if (argv[1] == NULL)
    {
      usageErrorHandling(2);
    }
    int pageAccessRequests[numberOfPageRequests], pageArray[numberOfPages], pageRequestsArray[numberOfPageRequests];
    while (!feof(input))
    {
      fscanf(input, "%d", &pageAccessRequests[i]);
      i++;
    }
    fclose(input);
    printIntroMessage(argv[2]);
    int algorithmSelected = getAlgorithmSelected(argv[2]);
    holderVar = numberOfPageRequests;
    switch (algorithmSelected)
    {
      case 1:
        for (i = 0; i < numberOfFrames; i++)
        {
          pageArray[i] = -1;
        }
        while (s < numberOfPageRequests)
        {
          flag = 0;
          holderVar = pageAccessRequests[s];
          for (i = 0; i < numberOfFrames; i++)
          {
            if (holderVar == pageArray[i])
            {
              s++;
              flag = 1;
              pageMessage(pageArray[i], i, 1);
              break;
            }
          }
          if (flag == 0)
          {
            if (currentFrame < numberOfFrames)
            {
              pageArray[currentFrame] = pageAccessRequests[s];
              pageMessage(pageAccessRequests[s], currentFrame, 2);
              currentFrame++;
              s++;
              faultNum++;
            }
            else
            {
              if (f < numberOfFrames)
              {
                pageMessage(pageArray[f], f, 3);
                pageArray[f] = pageAccessRequests[s];
                pageMessage(pageAccessRequests[s], f, 2);
                s++;
                f++;
                faultNum++;
              }
              else
                f = 0;
            }
          }
        }
        pageFaultMessage(faultNum);
        break;
      case 2:
        f = numberOfFrames;
        for (i = 0; i < f; i++)
        {
          pageRequestsArray[i] = 0;
          pageArray[i] = -1;
        }
        for (i = 0; i < numberOfPageRequests; i++)
        {
          flag = 0;
          temp = pageAccessRequests[i];
          for (j = 0; j < f; j++)
          {
            if (temp == pageArray[j])
            {
              flag = 1;
              pageRequestsArray[j] = i;
              pageMessage(pageArray[j], j, 1);
              break;
            }
          }
          if ((flag == 0) && (k < f))
          {
            faultCount++;
            pageArray[k] = temp;
            pageRequestsArray[k] = i;
            pageMessage(pageArray[k], k, 2);
            k++;
          }
          else if ((flag == 0) && (k == f))
          {
            faultCount++;
            minimumNumberOfPageRequests = pageRequestsArray[0];
            for (currentRequest = 0; currentRequest < f; currentRequest++)
            {
              if (pageRequestsArray[currentRequest] < minimumNumberOfPageRequests)
              {
                minimumNumberOfPageRequests = pageRequestsArray[currentRequest];
                requestIndex = currentRequest;
              }
            }
            pageArray[requestIndex] = temp;
            pageRequestsArray[requestIndex] = i;
            pageMessage(pageAccessRequests[minimumNumberOfPageRequests], requestIndex, 3);
            pageMessage(pageArray[requestIndex], requestIndex, 2);
            requestIndex = 0;
          }
        }
        pageFaultMessage(faultCount);
        break;
      case 3:
        for (i = 0; i < numberOfFrames; i++)
        {
          pageRequestsArray[i] = 0;
          pageArray[i] = -1;
        }
        for (i = 0; i < numberOfPageRequests; i++)
        {
          flag = 0;
          temp = pageAccessRequests[i];
          for (j = 0; j < numberOfFrames; j++)
          {
            if (temp == pageArray[j])
            {
              flag = 1;
              pageMessage(pageArray[j], j, 1);
              break;
            }
          }
          if ((flag == 0) && (k < numberOfFrames))
          {
            faultCount++;
            pageArray[k] = temp;
            pageMessage(pageArray[k], k, 2);
            k++;
          }
          else if ((flag == 0) && (k == numberOfFrames))
          {
            faultCount++;
            for (increment4 = 0; increment4 < numberOfFrames; increment4++)
            {
              pageRequestsArray[increment4] = 0;
            }
            for (currentRequest = 0; currentRequest < numberOfFrames; currentRequest++)
            {
              tempflag = 0;
              for (currentFrame = i + 1; currentFrame < numberOfPageRequests; currentFrame++)
              {
                if (pageArray[currentRequest] == pageAccessRequests[currentFrame])
                {
                  if (pageRequestsArray[currentRequest] == 0)
                    pageRequestsArray[currentRequest] = currentFrame;
                  tempflag = 1;
                }
              }
              if (tempflag != 1)
              {
                pageRequestsArray[currentRequest] = numberOfPageRequests + 1;
              }
            }
            requestIndex = 0;
            maximumNumberOfPageRequests = pageRequestsArray[0];
            for (increment4 = 0; increment4 < numberOfFrames; increment4++)
            {
              if (pageRequestsArray[increment4] > maximumNumberOfPageRequests)
              {
                maximumNumberOfPageRequests = pageRequestsArray[increment4];
                pageMessage(pageArray[increment4], increment4, 3);
                requestIndex = increment4;
              }
            }
            pageArray[requestIndex] = temp;
            pageMessage(pageArray[requestIndex], requestIndex, 2);
          }
        }
        pageFaultMessage(faultCount);
        break;
      default:
        usageErrorHandling(3);
        break;
  }
	return -1;
}