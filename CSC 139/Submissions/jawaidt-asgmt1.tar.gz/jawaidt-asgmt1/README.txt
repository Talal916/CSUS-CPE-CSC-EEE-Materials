To Compile:
gcc observer.c -o observer

Run by calling observer from command line.

Usages:
observer
observer -s
observer -l [int interval][int duration]