#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>
#define LB_SIZE 1000

void printPartB(void);
void printPartC(void);
void printPartD(void);
void printGreeting(void);
void sampleLoadAvg(int interval,int duration);

char repTypeName[16];

int main(int argc, char *argv[])
{
int interval = 0;
int duration = 0;
char c1[1];
char c2[1];

    strcpy(repTypeName, "Standard");
    printGreeting();
    printPartB();
    if (argc > 1)
{
    sscanf(argv[1], "%s", c1);
    if (c1[0] != '-' || c1[1] != 's' && c1[1] != 'l')
    {
      fprintf(stderr, "usage: observer [-s][-l int dur]\n");
      exit(1);
    }
    if (c1[1] == 's')
	  {
      strcpy(repTypeName, "Short");
      printPartC();
      printPartD();
    }
    else if (c1[1] == 'l')
    {
      if (argv[2] == NULL || argv[3] == NULL)
      {
        fprintf(stderr, "usage: observer [-s][-l int dur]\n");
        exit(1);
      }
      else
      {
        strcpy(repTypeName, "Long");
        printPartC();
        printPartD();
        interval = atoi(argv[2]);
        duration = atoi(argv[3]);
        sampleLoadAvg(interval,duration);
      }
    }
}

return (0);
}

void printPartB(void) {
/* print Part B info */
    system("cat /proc/cpuinfo | grep \"model name\" | uniq");
    system("hostnamectl | grep \"Kernel Name\" ");
    system("uptime | awk '{print $1}'");
    system("date");
    system("hostname");
}

void printPartC(void) {
/* print Part C info */
    fprintf(stderr, "Amount of time in seconds spent in User mode: ");
    system("cat /proc/stat | grep cpu -m 1 | awk '{print $2}'");

    fprintf(stderr, "Amount of time in seconds spent in System mode: ");
    system("cat /proc/stat | grep cpu -m 1 | awk '{print $4}'");

    fprintf(stderr, "Amount of time in seconds spent in Idle mode: ");
    system("cat /proc/stat | grep cpu -m 1 | awk '{print $5}'");

    fprintf(stderr, "Number of disk reads: ");
    system("cat /proc/diskstats | grep nvme0n1 -m 1 | awk '{print $6}'");
    
    fprintf(stderr, "Number of disk writes: ");
    system("cat /proc/diskstats | grep nvme0n1 -m 1 | awk '{print $10}'");
    
    fprintf(stderr, "Number of context switches: ");
    system("cat /proc/stat | grep ctxt | awk '{print $2}'");
    
    fprintf(stderr, "Time when last booted: ");
    system("who -b | awk '{print $3 " " $4}'");

    system("cat /proc/stat | grep processes");
}

void printPartD(void) {
    /* Part D */
    fprintf(stderr, "Amount of memory configured: ");
    system("free | grep Mem: | awk '{print $2}'");

    fprintf(stderr, "Amount of memory currently available: ");
    system("free | grep Mem: | awk '{print $4}'");

    fprintf(stderr, "Load averages over the last minute: ");
    system("cat /proc/loadavg | awk '{print $1}'");
}

void printGreeting(void) {
    printf("Status report type %s",repTypeName);
    fprintf(stderr,"Current time: ");
    system("uptime | awk '{print $1}'");
    fprintf(stderr, "Machine Hostname: ");
    system("hostname");
    printf("\n\n\n");
    fflush(stdout);
}

	void sampleLoadAvg(int interval,int duration)
	{
        char *lineBuf; 
        lineBuf = (char *)malloc(LB_SIZE + 1);
		double intervalDbl = interval;		
		double durationDbl = duration;		
		unsigned int iteration = 0;
		FILE *fp;
		unsigned int seconds = 0;
		unsigned int remaining = 0;
			remaining= (unsigned int)(duration);
			fp = fopen("/proc/loadavg","r");
			duration = remaining-seconds;
			printf("\nPlease wait. \nRunning for %d seconds\nSampling every %d seconds\n--------------\n", duration, interval); 
			while (duration > 0)
			{
					fgets(lineBuf,LB_SIZE + 1,fp);
					printf("%s",lineBuf);
					fclose(fp);
					fp = fopen("/proc/loadavg","r");
					iteration+=(unsigned int)(intervalDbl);		
					sleep(interval);
					duration-= interval;
		
			}

	}