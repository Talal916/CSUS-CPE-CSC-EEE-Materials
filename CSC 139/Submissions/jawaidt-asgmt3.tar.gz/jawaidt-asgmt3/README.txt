README.txt 

Run command “gcc Talal.c buffer.h -lpthread -lrt -o Talal”.
 to compile.

USAGE:./Talal {Sleep Duration} {Number of Producers} {Number of Consumers}