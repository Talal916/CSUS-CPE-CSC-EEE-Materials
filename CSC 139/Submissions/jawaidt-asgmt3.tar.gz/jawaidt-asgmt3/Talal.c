/*
* Talal Jawaid
* CSC 139
* 11/6/2019
* No grace days used.
*/

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <semaphore.h>
#include "buffer.h"
#include <pthread.h>

#define RANDCAP 5

pthread_mutex_t mutex;
sem_t full, empty;

buffer_item buffer[BUFFER_SIZE];

int sleepTime;
int first, last;
int c;
pthread_t tid;  
pthread_attr_t attr; 
void *producer(void *param); 
void *consumer(void *param); 

int insert_item(buffer_item item) {
/* inserts item into buffer
 * returns 0 if successful, otherwise
 * return -1 indicating and error condition  */  
   if(c < BUFFER_SIZE) {
      buffer[c] = item;
      last = (last + 1) % BUFFER_SIZE;
      c++;
      return 0;
   } else {
      return -1;
   }
}

int remove_item(buffer_item *item) {
/* remove an object from buffer
 * placing it in item
 * return 0 if succesfull, otherwise
 * return -1 indicating an error condition     */
   if(c > 0) {
      *item = buffer[(c-1)];
      first = (first + 1) % BUFFER_SIZE;
      c--;
      return 0;
   } else {
      return -1;
   }
}
void initializeBuffer() {
   pthread_mutex_init(&mutex, NULL);
   sem_init(&full, 0, 0);
   sem_init(&empty, 0, BUFFER_SIZE);
   pthread_attr_init(&attr);
   c = 0;
}

int main(int argc, char *argv[]) {
/*1. Get command line arguments argv[1],argv[2],argv[3]*/
/* 1. How long to sleep before terminating */
/* 2. Number of producer threads */
/* 3. Number of consumer threads */
   int i;
   sleepTime = atoi(argv[1]);
   int numberOfProducers = atoi(argv[2]);
   int numberOfConsumers = atoi(argv[3]);
   printf("numberOfProducers: %d\n",numberOfProducers);
   printf("numberOfConsumers: %d\n",numberOfConsumers);
   if (argc != 4)
   {
      fprintf(stderr, "USAGE:./Talal {Sleep Duration} {Number of Producers} {Number of Consumers}\n");
   }
   initializeBuffer();
   for(i = 0; i < numberOfProducers; i++) {
      pthread_create(&tid,&attr,producer,NULL);
    }
   for(i = 0; i < numberOfConsumers; i++) {
      pthread_create(&tid,&attr,consumer,NULL);
   }
   sleep(sleepTime);
   printf("Exit the program\n");
   exit(0);
}

void *producer(void *param) {
   buffer_item item;
   srand(time(0));
while(1)
{
      fflush(stdin); 
      /*sleep for a random period of time*/
      int rNum = rand() % RANDCAP+1;
      sleep(rNum);
      /*generate a random number*/
         item = rand() % 10000;
         sem_wait(&empty);
         pthread_mutex_lock(&mutex);
         if (insert_item(item) == -1){
            fprintf(stderr, "report error condition\n");
         } else {
            printf("Producer Produced: %d\n",item);
         }
         pthread_mutex_unlock(&mutex);
         sem_post(&full);
   }
}

void *consumer(void *param) {
   srand(time(0)); 
   buffer_item item;
   while(1){
   fflush(stdin);
      int rNum = rand() % RANDCAP+1;
      /* sleep for a random period of time */
      sleep(rNum);
      sem_wait(&full);

   /* acquire the mutex lock */
      pthread_mutex_lock(&mutex);
      if(remove_item(&item) == -1) {
              fprintf(stderr, "report error condition\n");
      } else {
              printf("Consumer Consumed: %d\n", item);
      }
   /*release the mutex lock*/
      pthread_mutex_unlock(&mutex);
      sem_post(&empty);

   }

}
