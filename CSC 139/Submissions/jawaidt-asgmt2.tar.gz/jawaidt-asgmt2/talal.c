/*
Author: Talal Jawaid
10/22/2019
Using 1 grace day
CSC 139
Assignment 2
*/

#include <stdio.h>
#include <string.h>
#include <sys/queue.h>

int pid[20], arrivalTime[20], burstTime[20];
int processCount=0, arrival_time=0, countB=0;

void schedule(int pid[], int run[], int arrival[]);

void fcfs();
void srtf();
void rr(int);


int main(int argc, char *argv[]){
	if(argc >=2 && argc <3) {
      fprintf(stderr, "USAGE: proj2 input_file [FCFS | RR | SRTF] [time_quantum]\n");
		   return -1;
   }
   int u;
    char fileName[] = "input_file";
    char inputString[256];
    char *p;
    FILE * f = fopen(fileName, "r");
    while(p = fgets(inputString, sizeof(inputString), f)) {
        int x, i = 0, n = 0;
        while (sscanf(p+=n, "%d%n", &x, &n) > 0){
            if (i >= 0){
				i++;
			}
			switch(i) {
				case 1: {
				pid[processCount]=x;
				processCount++;
				}
				case 2: {
					arrivalTime[arrival_time]=x;
					arrival_time++;
				}
				case 3: {
					burstTime[countB]=x;
					countB++;
				}
			}
		}
    }

	printf("Total %d processes have been read from %s.",processCount,argv[1]);
	if(processCount == 0)
	{
		printf("\nProcess queue is empty. End of run.\n");
	} else {
		if (strcmp(argv[2],"FCFS")==0){
			fcfs();
		} else if (strcmp(argv[2],"SRTF")==0){
			srtf();
		} else 	if (strcmp(argv[2],"RR")==0){
			rr(atoi(argv[3]));
	}
	}
}

void fcfs()
{
	int result;
	float waitingTimeAverage=0;
	float turnaroundTimeAverage=0.0f;
	int arrival[processCount];
	int burst[processCount];
	int waiting[processCount];
    int turn_around_time[processCount];
	waiting[0] = 0;
	for(int i=0; i < processCount; i++)
	{
		arrival[i]=arrivalTime[i];
		burst[i]=burstTime[i];
	}
	for(int i=1; i < processCount; i++) {
		result=0;
		for(int j=0; j < i; j++)	{
			result+= burst[j];
		}
		waiting[i]=result - arrival[i];
	}

	for(int i = 0; i < processCount; i++){
		result+=waiting[i];
		waitingTimeAverage=waitingTimeAverage+(double)waiting[i];
		turn_around_time[i]= burst[i] + waiting[i];
		turnaroundTimeAverage+=turn_around_time[i];
	}
		waitingTimeAverage= waitingTimeAverage/(double)processCount;
	printf("\nWaiting Time:%f\t\n", waitingTimeAverage);
	printf("\nScheduling algorithm: FCFS \n");
	printf("============================================");

	int count=0;
	int z=0;
	int l=0;
	char run[15] = "Running...";
	char fin[15] ="Finished...";

	printf("\n");

	for(int k=0; k<processCount; k++){
		for(int i=0; i<=burst[k]; i++){
			printf("<System time %d > Process\t %d is %s\n", count,pid[z], run);
			if(l){
				count--;
				l=0;
			}
			if(burst[k]==i+1)
			{
				memcpy(run,fin, sizeof(fin));
				l=1;
			}
			count++;
		}
		memcpy(run,"running", sizeof(fin));
		z++;
	}

	printf("<System time %d All Processes Finished...\n",count );
	printf("\nCPU Usage:\t 100%c",'%' );
	printf("\nAverage Waiting Time:\t%.2f", waitingTimeAverage);
	printf("\nAverage Response Time:\t%.2f", waitingTimeAverage);
	printf("\nAverage Turn Around Time:%.2f \t\n",turnaroundTimeAverage/processCount);

}


void srtf(){
	 int n = processCount;
	 int burst[processCount];
	 int oldtime[processCount];
	 int bursttimetozero[processCount];
	 int arrival[processCount];
	 int tat[processCount];
	 int wt[processCount];
	 int rt[processCount];
	 int finish[processCount];
	 int twt=0;
	 int ttat=0;
	 int total=0;

	 int response_time =0;
	 float average_response_time=0;
	 char run[15] = "Running...";
	 char fin[15] ="Finished...";

	for(int i=0; i<n; i++){
		arrival[i]=arrivalTime[i];
		burst[i]=burstTime[i];
		rt[i]=burst[i];
	    finish[i]=0;
	    wt[i]=0;
        tat[i]=0;
		total+=burst[i];
		oldtime[i]=0;
		bursttimetozero[i]=burstTime[i];
	}

	printf("Total:%d\n", total);

	int time;
	int next=0;
	int old;

	for(time=0;time<total;time++)
	{
        old=next;
		int low;
		int bursts=0, j=0;
 		for(int i=0;i < n;i++){
        if(finish[i]==0){
			low=i;
			break;
		}
	}
        for(int i=0;i<n;i++){
        if(finish[i]!=1){
            if(rt[i]<rt[low] && arrival[i]<=time){
        	    low=i;
				oldtime[next]=time;
				}
			}
		}
		next=low;

	if(old!=next&&time!=0) {
	if(finish[old]==1){
		memcpy(run,"Finish...", sizeof(fin));
		}
	} else {
		memcpy(run,"Running...", sizeof(fin));
	}
    rt[next]=rt[next]-1;
	if(rt[next]==0) {
		finish[next]=1;
	}
        for(int i=0;i<n;i++){
            if(i!=next && finish[i]==0 && arrival[i]<=time){
                wt[i]++;
			}
		}
		if(run[0]=='f')
		{
			printf("<System time: (%d)> Process %d is %s\n",time, old+1,run);
			printf("<System time: (%d)> Process %d is %s\n",time, next+1,"running");
		} else{
				printf("<System time: (%d)> Process %d is %s\n",time, next+1, run);
			}
		}
		printf("<System time: (%d)> All Processes finished...\n",time);

    	for(int i=0;i<n;i++){
			if(!finish[i]) {
				printf("Scheduling successful, end of program!\n");
				return;
			}
		}

      for(int i=0;i<n;i++)
    {   twt+=wt[i];
		tat[i]=wt[i]+burst[i];
		ttat+=tat[i];
      }

      printf("\nCPU Usage: 100%c\n",'%' );
	  printf("Average Waiting Time  =%0.2f\navgTurnaround time =%0.2f\n",(float)twt/processCount,(float)ttat/processCount);

}
struct process
{
    int no;
    int at,et,wt,tt;
    int tet;
    int t;
};

void rr(int initialTimeQuantumInput){
	struct process p[100];
    int i,j,k;
    int numberOfProcesses=processCount;

    for (i=0;i<numberOfProcesses;i++)
    {
		p[i].et=burstTime[i];
        p[i].tet+=p[i].et;
        p[i].at=arrivalTime[i];
        p[i].no=i+1;
		  p[i].t=0;
    }


    int quantum = initialTimeQuantumInput;

    int totaltime=0;

    for(i=0;i<numberOfProcesses;i++)
    {
        totaltime+=p[i].et;
    }

    i=0;
    k=0;

    int rrg[99];
    for(j=0;j<totaltime;j++)
    {
        if((k==0)&&(p[i].et!=0))
        {
            p[i].wt=j;
            if((p[i].t!=0))
            {
                p[i].wt-=quantum*p[i].t;

            }
        }
        if((p[i].et!=0)&&(k!=quantum))
        {
            rrg[j]=p[i].no;
            p[i].et-=1;
            k++;
        }
        else
        {
            if((k==quantum)&&(p[i].et!=0))
                p[i].t+=1;

            i=i+1;
            if(i==numberOfProcesses)
                i=0;

            k=0;
            j=j-1;
        }
    }
	int twt=0;
    int ttt=0;

    for(i=0;i<numberOfProcesses;i++)
    {
        p[i].tt=p[i].wt+p[i].tet;
        ttt+=p[i].tt;
        twt+=p[i].wt;

    }
    printf("\n Average Waiting Time:%0.2f",(float)twt/numberOfProcesses);
	printf("\n Average Turn Around Time:%0.2f\n",(float)ttt/numberOfProcesses);
}
