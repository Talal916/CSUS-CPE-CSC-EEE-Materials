You compile talal.c using command: gcc talal.c -o proj2

USAGE: ./proj2 input_file [FCFS | RR | SRTF] [time_quantum]